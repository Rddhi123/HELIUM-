/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.util.HashMap
 */
package a.a.a.a;

import a.a.a.a.b;
import java.util.HashMap;

public class a<K, V>
extends b<K, V> {
    private HashMap<K, b.c<K, V>> e = new HashMap();

    public boolean a(K k2) {
        return this.e.containsKey(k2);
    }
}


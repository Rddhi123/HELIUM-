/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Boolean
 *  java.lang.Iterable
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.WeakHashMap
 */
package a.a.a.a;

import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;

public class b<K, V>
implements Iterable<Map.Entry<K, V>> {
    c<K, V> a;
    private c<K, V> b;
    private WeakHashMap<f<K, V>, Boolean> c = new WeakHashMap();
    private int d = 0;

    public Iterator<Map.Entry<K, V>> a() {
        b<K, V> b2 = new b<K, V>(this.b, this.a);
        this.c.put(b2, (Object)false);
        return b2;
    }

    public Map.Entry<K, V> b() {
        return this.a;
    }

    public b<K, V> c() {
        d d2 = new d();
        this.c.put((Object)d2, (Object)false);
        return d2;
    }

    public Map.Entry<K, V> d() {
        return this.b;
    }

    public int e() {
        return this.d;
    }

    public boolean equals(Object object) {
        if (object == this) {
            return true;
        }
        if (!(object instanceof b)) {
            return false;
        }
        b b2 = (b)object;
        if (this.e() != b2.e()) {
            return false;
        }
        Iterator<Map.Entry<K, V>> iterator = this.iterator();
        Iterator<Map.Entry<K, V>> iterator2 = b2.iterator();
        while (iterator.hasNext() && iterator2.hasNext()) {
            Map.Entry entry = (Map.Entry)iterator.next();
            Object object2 = iterator2.next();
            if ((entry != null || object2 == null) && (entry == null || entry.equals(object2))) continue;
            return false;
        }
        return !iterator.hasNext() && !iterator2.hasNext();
    }

    public int hashCode() {
        Iterator<Map.Entry<K, V>> iterator = this.iterator();
        int n2 = 0;
        while (iterator.hasNext()) {
            n2 += ((Map.Entry)iterator.next()).hashCode();
        }
        return n2;
    }

    public Iterator<Map.Entry<K, V>> iterator() {
        a<K, V> a2 = new a<K, V>(this.a, this.b);
        this.c.put(a2, (Object)false);
        return a2;
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("[");
        Iterator<Map.Entry<K, V>> iterator = this.iterator();
        while (iterator.hasNext()) {
            stringBuilder.append(((Map.Entry)iterator.next()).toString());
            if (!iterator.hasNext()) continue;
            stringBuilder.append(", ");
        }
        stringBuilder.append("]");
        return stringBuilder.toString();
    }

    static class a<K, V>
    extends e<K, V> {
        a(c<K, V> c2, c<K, V> c3) {
            super(c2, c3);
        }

        @Override
        c<K, V> a(c<K, V> c2) {
            return c2.a;
        }
    }

    private static class b<K, V>
    extends e<K, V> {
        b(c<K, V> c2, c<K, V> c3) {
            super(c2, c3);
        }

        @Override
        c<K, V> a(c<K, V> c2) {
            return c2.b;
        }
    }

    static class c<K, V>
    implements Map.Entry<K, V> {
        c<K, V> a;
        c<K, V> b;
    }

    private class d
    implements Iterator<Map.Entry<K, V>>,
    f<K, V> {
        private c<K, V> a;
        private boolean b = true;

        d() {
        }

        public boolean hasNext() {
            if (this.b) {
                return b.this.a != null;
            }
            c<K, V> c2 = this.a;
            return c2 != null && c2.a != null;
        }

        /*
         * Enabled aggressive block sorting
         */
        public Map.Entry<K, V> next() {
            c c2;
            if (this.b) {
                this.b = false;
                c2 = b.this.a;
            } else {
                c<K, V> c3 = this.a;
                c2 = c3 != null ? c3.a : null;
            }
            this.a = c2;
            return this.a;
        }
    }

    private static abstract class e<K, V>
    implements Iterator<Map.Entry<K, V>>,
    f<K, V> {
        c<K, V> a;
        c<K, V> b;

        e(c<K, V> c2, c<K, V> c3) {
            this.a = c3;
            this.b = c2;
        }

        private c<K, V> a() {
            c<K, V> c2 = this.b;
            c<K, V> c3 = this.a;
            if (c2 != c3 && c3 != null) {
                return this.a(c2);
            }
            return null;
        }

        abstract c<K, V> a(c<K, V> var1);

        public boolean hasNext() {
            return this.b != null;
        }

        public Map.Entry<K, V> next() {
            c<K, V> c2 = this.b;
            this.b = this.a();
            return c2;
        }
    }

    static interface f<K, V> {
    }

}


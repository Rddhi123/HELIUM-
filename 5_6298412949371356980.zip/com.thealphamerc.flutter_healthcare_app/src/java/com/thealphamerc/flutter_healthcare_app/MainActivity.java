/*
 * Decompiled with CFR 0.0.
 */
package com.thealphamerc.flutter_healthcare_app;

import b.a.b.a.d;
import io.flutter.embedding.engine.a;
import io.flutter.plugins.GeneratedPluginRegistrant;

public class MainActivity
extends d {
    @Override
    public void a(a a2) {
        GeneratedPluginRegistrant.registerWith(a2);
    }
}


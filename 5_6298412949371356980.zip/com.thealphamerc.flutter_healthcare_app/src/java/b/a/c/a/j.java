/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.nio.ByteBuffer
 */
package b.a.c.a;

import b.a.c.a.h;
import java.nio.ByteBuffer;

public interface j {
    public h a(ByteBuffer var1);

    public ByteBuffer a(h var1);

    public ByteBuffer a(Object var1);

    public ByteBuffer a(String var1, String var2, Object var3);

    public Object b(ByteBuffer var1);
}


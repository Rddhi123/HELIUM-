/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.nio.ByteBuffer
 */
package b.a.c.a;

import android.util.Log;
import b.a.c.a.b;
import b.a.c.a.g;
import java.nio.ByteBuffer;

public final class a<T> {
    private final b.a.c.a.b a;
    private final String b;
    private final g<T> c;

    public a(b.a.c.a.b b2, String string, g<T> g2) {
        this.a = b2;
        this.b = string;
        this.c = g2;
    }

    public void a(d<T> d2) {
        b.a.c.a.b b2 = this.a;
        String string = this.b;
        b b3 = d2 == null ? null : new b(d2);
        b2.a(string, b3);
    }

    public void a(T t) {
        this.a(t, null);
    }

    public void a(T t, e<T> e2) {
        b.a.c.a.b b2 = this.a;
        String string = this.b;
        ByteBuffer byteBuffer = this.c.a(t);
        c c2 = e2 == null ? null : new c(e2);
        b2.a(string, byteBuffer, c2);
    }

    private final class b
    implements b.a {
        private final d<T> a;

        private b(d<T> d2) {
            this.a = d2;
        }

        @Override
        public void a(ByteBuffer byteBuffer, final b.b b2) {
            try {
                this.a.a(a.this.c.a(byteBuffer), new e<T>(){

                    @Override
                    public void a(T t) {
                        b2.a(a.this.c.a(t));
                    }
                });
                return;
            }
            catch (RuntimeException runtimeException) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("BasicMessageChannel#");
                stringBuilder.append(a.this.b);
                Log.e((String)stringBuilder.toString(), (String)"Failed to handle message", (Throwable)runtimeException);
                b2.a(null);
                return;
            }
        }

    }

    private final class c
    implements b.b {
        private final e<T> a;

        private c(e<T> e2) {
            this.a = e2;
        }

        @Override
        public void a(ByteBuffer byteBuffer) {
            try {
                this.a.a(a.this.c.a(byteBuffer));
                return;
            }
            catch (RuntimeException runtimeException) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("BasicMessageChannel#");
                stringBuilder.append(a.this.b);
                Log.e((String)stringBuilder.toString(), (String)"Failed to handle message reply", (Throwable)runtimeException);
                return;
            }
        }
    }

    public static interface d<T> {
        public void a(T var1, e<T> var2);
    }

    public static interface e<T> {
        public void a(T var1);
    }

}


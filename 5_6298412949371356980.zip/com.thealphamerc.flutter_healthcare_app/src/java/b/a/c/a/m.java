/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package b.a.c.a;

public interface m {
    public boolean a(int var1, String[] var2, int[] var3);
}


/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.nio.ByteBuffer
 */
package b.a.c.a;

import java.nio.ByteBuffer;

public interface g<T> {
    public T a(ByteBuffer var1);

    public ByteBuffer a(T var1);
}


/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.nio.ByteBuffer
 *  java.nio.charset.Charset
 */
package b.a.c.a;

import b.a.c.a.g;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;

public final class q
implements g<String> {
    private static final Charset a = Charset.forName((String)"UTF8");
    public static final q b = new q();

    private q() {
    }

    @Override
    public String a(ByteBuffer byteBuffer) {
        byte[] arrby;
        int n2;
        if (byteBuffer == null) {
            return null;
        }
        int n3 = byteBuffer.remaining();
        if (byteBuffer.hasArray()) {
            arrby = byteBuffer.array();
            n2 = byteBuffer.arrayOffset();
        } else {
            arrby = new byte[n3];
            byteBuffer.get(arrby);
            n2 = 0;
        }
        return new String(arrby, n2, n3, a);
    }

    @Override
    public ByteBuffer a(String string) {
        if (string == null) {
            return null;
        }
        byte[] arrby = string.getBytes(a);
        ByteBuffer byteBuffer = ByteBuffer.allocateDirect((int)arrby.length);
        byteBuffer.put(arrby);
        return byteBuffer;
    }
}


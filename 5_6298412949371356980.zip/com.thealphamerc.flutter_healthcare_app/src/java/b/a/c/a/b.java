/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.nio.ByteBuffer
 */
package b.a.c.a;

import java.nio.ByteBuffer;

public interface b {
    public void a(String var1, a var2);

    public void a(String var1, ByteBuffer var2, b var3);

    public static interface a {
        public void a(ByteBuffer var1, b var2);
    }

    public static interface b {
        public void a(ByteBuffer var1);
    }

}


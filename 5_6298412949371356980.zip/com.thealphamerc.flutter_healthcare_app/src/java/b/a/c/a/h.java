/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package b.a.c.a;

public final class h {
    public final String a;
    public final Object b;

    public h(String string, Object object) {
        this.a = string;
        this.b = object;
    }

    public <T> T a() {
        return (T)this.b;
    }
}


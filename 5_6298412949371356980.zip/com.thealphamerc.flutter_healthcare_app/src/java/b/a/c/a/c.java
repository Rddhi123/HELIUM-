/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 */
package b.a.c.a;

public class c
extends RuntimeException {
    public final String a;
    public final Object b;

    c(String string, String string2, Object object) {
        super(string2);
        this.a = string;
        this.b = object;
    }
}


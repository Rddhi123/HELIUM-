/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  java.lang.Object
 */
package b.a.c.a;

import android.content.Intent;

public interface l {
    public boolean a(Intent var1);
}


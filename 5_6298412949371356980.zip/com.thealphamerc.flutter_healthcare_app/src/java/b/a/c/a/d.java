/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.nio.ByteBuffer
 *  org.json.JSONException
 *  org.json.JSONObject
 *  org.json.JSONTokener
 */
package b.a.c.a;

import b.a.c.a.f;
import b.a.c.a.g;
import b.a.c.a.q;
import java.nio.ByteBuffer;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

public final class d
implements g<Object> {
    public static final d a = new d();

    private d() {
    }

    @Override
    public Object a(ByteBuffer byteBuffer) {
        block4 : {
            if (byteBuffer == null) {
                return null;
            }
            try {
                JSONTokener jSONTokener = new JSONTokener((String)q.b.a(byteBuffer));
                Object object = jSONTokener.nextValue();
                if (jSONTokener.more()) break block4;
                return object;
            }
            catch (JSONException jSONException) {
                throw new IllegalArgumentException("Invalid JSON", (Throwable)jSONException);
            }
        }
        throw new IllegalArgumentException("Invalid JSON");
    }

    /*
     * Enabled force condition propagation
     * Lifted jumps to return sites
     */
    @Override
    public ByteBuffer a(Object object) {
        q q2;
        String string;
        if (object == null) {
            return null;
        }
        Object object2 = f.a(object);
        if (object2 instanceof String) {
            q2 = q.b;
            string = JSONObject.quote((String)((String)object2));
            do {
                return q2.a(string);
                break;
            } while (true);
        }
        q2 = q.b;
        string = object2.toString();
        return q2.a(string);
    }
}


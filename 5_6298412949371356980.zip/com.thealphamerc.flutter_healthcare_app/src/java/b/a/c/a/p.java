/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.ByteArrayOutputStream
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.nio.ByteBuffer
 *  java.nio.ByteOrder
 */
package b.a.c.a;

import b.a.c.a.c;
import b.a.c.a.h;
import b.a.c.a.j;
import b.a.c.a.o;
import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public final class p
implements j {
    public static final p b = new p(o.a);
    private final o a;

    public p(o o2) {
        this.a = o2;
    }

    @Override
    public h a(ByteBuffer byteBuffer) {
        byteBuffer.order(ByteOrder.nativeOrder());
        Object object = this.a.b(byteBuffer);
        Object object2 = this.a.b(byteBuffer);
        if (object instanceof String && !byteBuffer.hasRemaining()) {
            return new h((String)object, object2);
        }
        throw new IllegalArgumentException("Method call corrupted");
    }

    @Override
    public ByteBuffer a(h h2) {
        o.a a2 = new o.a();
        this.a.a(a2, h2.a);
        this.a.a(a2, h2.b);
        ByteBuffer byteBuffer = ByteBuffer.allocateDirect((int)a2.size());
        byteBuffer.put(a2.a(), 0, a2.size());
        return byteBuffer;
    }

    @Override
    public ByteBuffer a(Object object) {
        o.a a2 = new o.a();
        a2.write(0);
        this.a.a(a2, object);
        ByteBuffer byteBuffer = ByteBuffer.allocateDirect((int)a2.size());
        byteBuffer.put(a2.a(), 0, a2.size());
        return byteBuffer;
    }

    @Override
    public ByteBuffer a(String string, String string2, Object object) {
        o.a a2 = new o.a();
        a2.write(1);
        this.a.a(a2, string);
        this.a.a(a2, string2);
        this.a.a(a2, object);
        ByteBuffer byteBuffer = ByteBuffer.allocateDirect((int)a2.size());
        byteBuffer.put(a2.a(), 0, a2.size());
        return byteBuffer;
    }

    @Override
    public Object b(ByteBuffer byteBuffer) {
        block3 : {
            block4 : {
                block2 : {
                    byteBuffer.order(ByteOrder.nativeOrder());
                    byte by = byteBuffer.get();
                    if (by == 0) break block2;
                    if (by != 1) break block3;
                    break block4;
                }
                Object object = this.a.b(byteBuffer);
                if (!byteBuffer.hasRemaining()) {
                    return object;
                }
            }
            Object object = this.a.b(byteBuffer);
            Object object2 = this.a.b(byteBuffer);
            Object object3 = this.a.b(byteBuffer);
            if (object instanceof String && (object2 == null || object2 instanceof String) && !byteBuffer.hasRemaining()) {
                throw new c((String)object, (String)object2, object3);
            }
        }
        throw new IllegalArgumentException("Envelope corrupted");
    }
}


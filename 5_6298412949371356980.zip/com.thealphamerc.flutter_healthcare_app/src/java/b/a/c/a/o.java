/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.ByteArrayOutputStream
 *  java.lang.Boolean
 *  java.lang.Byte
 *  java.lang.Class
 *  java.lang.Double
 *  java.lang.Float
 *  java.lang.IllegalArgumentException
 *  java.lang.Integer
 *  java.lang.Long
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Short
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.math.BigInteger
 *  java.nio.Buffer
 *  java.nio.ByteBuffer
 *  java.nio.ByteOrder
 *  java.nio.DoubleBuffer
 *  java.nio.IntBuffer
 *  java.nio.LongBuffer
 *  java.nio.charset.Charset
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package b.a.c.a;

import b.a.c.a.g;
import java.io.ByteArrayOutputStream;
import java.math.BigInteger;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.DoubleBuffer;
import java.nio.IntBuffer;
import java.nio.LongBuffer;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class o
implements g<Object> {
    public static final o a = new o();
    private static final boolean b;
    private static final Charset c;

    static {
        boolean bl = ByteOrder.nativeOrder() == ByteOrder.LITTLE_ENDIAN;
        b = bl;
        c = Charset.forName((String)"UTF8");
    }

    protected static final void a(ByteArrayOutputStream byteArrayOutputStream, double d2) {
        o.a(byteArrayOutputStream, Double.doubleToLongBits((double)d2));
    }

    protected static final void a(ByteArrayOutputStream byteArrayOutputStream, int n2) {
        int n3 = byteArrayOutputStream.size() % n2;
        if (n3 != 0) {
            for (int i2 = 0; i2 < n2 - n3; ++i2) {
                byteArrayOutputStream.write(0);
            }
        }
    }

    protected static final void a(ByteArrayOutputStream byteArrayOutputStream, long l2) {
        if (b) {
            byteArrayOutputStream.write((int)((byte)l2));
            byteArrayOutputStream.write((int)((byte)(l2 >>> 8)));
            byteArrayOutputStream.write((int)((byte)(l2 >>> 16)));
            byteArrayOutputStream.write((int)((byte)(l2 >>> 24)));
            byteArrayOutputStream.write((int)((byte)(l2 >>> 32)));
            byteArrayOutputStream.write((int)((byte)(l2 >>> 40)));
            byteArrayOutputStream.write((int)((byte)(l2 >>> 48)));
            l2 >>>= 56;
        } else {
            byteArrayOutputStream.write((int)((byte)(l2 >>> 56)));
            byteArrayOutputStream.write((int)((byte)(l2 >>> 48)));
            byteArrayOutputStream.write((int)((byte)(l2 >>> 40)));
            byteArrayOutputStream.write((int)((byte)(l2 >>> 32)));
            byteArrayOutputStream.write((int)((byte)(l2 >>> 24)));
            byteArrayOutputStream.write((int)((byte)(l2 >>> 16)));
            byteArrayOutputStream.write((int)((byte)(l2 >>> 8)));
        }
        byteArrayOutputStream.write((int)((byte)l2));
    }

    protected static final void a(ByteArrayOutputStream byteArrayOutputStream, byte[] arrby) {
        o.d(byteArrayOutputStream, arrby.length);
        byteArrayOutputStream.write(arrby, 0, arrby.length);
    }

    protected static final void a(ByteBuffer byteBuffer, int n2) {
        int n3 = byteBuffer.position() % n2;
        if (n3 != 0) {
            byteBuffer.position(n2 + byteBuffer.position() - n3);
        }
    }

    protected static final void b(ByteArrayOutputStream byteArrayOutputStream, int n2) {
        if (b) {
            byteArrayOutputStream.write(n2);
            n2 >>>= 8;
        } else {
            byteArrayOutputStream.write(n2 >>> 8);
        }
        byteArrayOutputStream.write(n2);
    }

    protected static final void c(ByteArrayOutputStream byteArrayOutputStream, int n2) {
        if (b) {
            byteArrayOutputStream.write(n2);
            byteArrayOutputStream.write(n2 >>> 8);
            byteArrayOutputStream.write(n2 >>> 16);
            n2 >>>= 24;
        } else {
            byteArrayOutputStream.write(n2 >>> 24);
            byteArrayOutputStream.write(n2 >>> 16);
            byteArrayOutputStream.write(n2 >>> 8);
        }
        byteArrayOutputStream.write(n2);
    }

    protected static final byte[] c(ByteBuffer byteBuffer) {
        byte[] arrby = new byte[o.d(byteBuffer)];
        byteBuffer.get(arrby);
        return arrby;
    }

    protected static final int d(ByteBuffer byteBuffer) {
        if (byteBuffer.hasRemaining()) {
            int n2 = 255 & byteBuffer.get();
            if (n2 < 254) {
                return n2;
            }
            if (n2 == 254) {
                return byteBuffer.getChar();
            }
            return byteBuffer.getInt();
        }
        throw new IllegalArgumentException("Message corrupted");
    }

    protected static final void d(ByteArrayOutputStream byteArrayOutputStream, int n2) {
        if (n2 < 254) {
            byteArrayOutputStream.write(n2);
            return;
        }
        if (n2 <= 65535) {
            byteArrayOutputStream.write(254);
            o.b(byteArrayOutputStream, n2);
            return;
        }
        byteArrayOutputStream.write(255);
        o.c(byteArrayOutputStream, n2);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    protected Object a(byte var1_1, ByteBuffer var2_2) {
        var3_3 = 0;
        switch (var1_1) {
            default: {
                throw new IllegalArgumentException("Message corrupted");
            }
            case 13: {
                var16_4 = o.d(var2_2);
                var4_5 = new HashMap();
                while (var3_3 < var16_4) {
                    var4_5.put(this.b(var2_2), this.b(var2_2));
                    ++var3_3;
                }
                return var4_5;
            }
            case 12: {
                var14_6 = o.d(var2_2);
                var4_5 = new ArrayList(var14_6);
                while (var3_3 < var14_6) {
                    var4_5.add(this.b(var2_2));
                    ++var3_3;
                }
                return var4_5;
            }
            case 11: {
                var9_7 = o.d(var2_2);
                var10_8 = new double[var9_7];
                o.a(var2_2, 8);
                var2_2.asDoubleBuffer().get(var10_8);
                ** GOTO lbl32
            }
            case 10: {
                var9_7 = o.d(var2_2);
                var10_8 = new long[var9_7];
                o.a(var2_2, 8);
                var2_2.asLongBuffer().get((long[])var10_8);
lbl32: // 2 sources:
                var2_2.position(var2_2.position() + var9_7 * 8);
                return var10_8;
            }
            case 9: {
                var5_9 = o.d(var2_2);
                var6_10 = new int[var5_9];
                o.a(var2_2, 4);
                var2_2.asIntBuffer().get(var6_10);
                var2_2.position(var2_2.position() + var5_9 * 4);
                return var6_10;
            }
            case 8: {
                return o.c(var2_2);
            }
            case 7: {
                return new String(o.c(var2_2), o.c);
            }
            case 6: {
                o.a(var2_2, 8);
                return var2_2.getDouble();
            }
            case 5: {
                return new BigInteger(new String(o.c(var2_2), o.c), 16);
            }
            case 4: {
                return var2_2.getLong();
            }
            case 3: {
                return var2_2.getInt();
            }
            case 2: {
                return false;
            }
            case 1: {
                return true;
            }
            case 0: 
        }
        return null;
    }

    @Override
    public Object a(ByteBuffer byteBuffer) {
        if (byteBuffer == null) {
            return null;
        }
        byteBuffer.order(ByteOrder.nativeOrder());
        Object object = this.b(byteBuffer);
        if (!byteBuffer.hasRemaining()) {
            return object;
        }
        throw new IllegalArgumentException("Message corrupted");
    }

    @Override
    public ByteBuffer a(Object object) {
        if (object == null) {
            return null;
        }
        a a2 = new a();
        this.a(a2, object);
        ByteBuffer byteBuffer = ByteBuffer.allocateDirect((int)a2.size());
        byteBuffer.put(a2.a(), 0, a2.size());
        return byteBuffer;
    }

    /*
     * Enabled aggressive block sorting
     */
    protected void a(ByteArrayOutputStream byteArrayOutputStream, Object object) {
        block24 : {
            int n2;
            block27 : {
                int n3;
                block26 : {
                    block25 : {
                        if (object == null || object.equals(null)) break block24;
                        if (object != Boolean.TRUE) break block25;
                        n3 = 1;
                        break block26;
                    }
                    if (object != Boolean.FALSE) break block27;
                    n3 = 2;
                }
                byteArrayOutputStream.write(n3);
                return;
            }
            if (object instanceof Number) {
                if (!(object instanceof Integer || object instanceof Short || object instanceof Byte)) {
                    if (object instanceof Long) {
                        byteArrayOutputStream.write(4);
                        o.a(byteArrayOutputStream, (Long)object);
                        return;
                    }
                    if (!(object instanceof Float) && !(object instanceof Double)) {
                        if (object instanceof BigInteger) {
                            byteArrayOutputStream.write(5);
                            o.a(byteArrayOutputStream, ((BigInteger)object).toString(16).getBytes(c));
                            return;
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Unsupported Number type: ");
                        stringBuilder.append((Object)object.getClass());
                        throw new IllegalArgumentException(stringBuilder.toString());
                    }
                    byteArrayOutputStream.write(6);
                    o.a(byteArrayOutputStream, 8);
                    o.a(byteArrayOutputStream, ((Number)object).doubleValue());
                    return;
                }
                byteArrayOutputStream.write(3);
                o.c(byteArrayOutputStream, ((Number)object).intValue());
                return;
            }
            if (object instanceof String) {
                byteArrayOutputStream.write(7);
                o.a(byteArrayOutputStream, ((String)object).getBytes(c));
                return;
            }
            if (object instanceof byte[]) {
                byteArrayOutputStream.write(8);
                o.a(byteArrayOutputStream, (byte[])object);
                return;
            }
            if (object instanceof int[]) {
                byteArrayOutputStream.write(9);
                int[] arrn = (int[])object;
                o.d(byteArrayOutputStream, arrn.length);
                o.a(byteArrayOutputStream, 4);
                int n4 = arrn.length;
                for (n2 = 0; n2 < n4; ++n2) {
                    o.c(byteArrayOutputStream, arrn[n2]);
                }
                return;
            } else if (object instanceof long[]) {
                byteArrayOutputStream.write(10);
                long[] arrl = (long[])object;
                o.d(byteArrayOutputStream, arrl.length);
                o.a(byteArrayOutputStream, 8);
                int n5 = arrl.length;
                while (n2 < n5) {
                    o.a(byteArrayOutputStream, arrl[n2]);
                    ++n2;
                }
                return;
            } else if (object instanceof double[]) {
                byteArrayOutputStream.write(11);
                double[] arrd = (double[])object;
                o.d(byteArrayOutputStream, arrd.length);
                o.a(byteArrayOutputStream, 8);
                int n6 = arrd.length;
                while (n2 < n6) {
                    o.a(byteArrayOutputStream, arrd[n2]);
                    ++n2;
                }
                return;
            } else if (object instanceof List) {
                byteArrayOutputStream.write(12);
                List list = (List)object;
                o.d(byteArrayOutputStream, list.size());
                Iterator iterator = list.iterator();
                while (iterator.hasNext()) {
                    this.a(byteArrayOutputStream, iterator.next());
                }
                return;
            } else {
                if (!(object instanceof Map)) {
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Unsupported value: ");
                    stringBuilder.append(object);
                    throw new IllegalArgumentException(stringBuilder.toString());
                }
                byteArrayOutputStream.write(13);
                Map map = (Map)object;
                o.d(byteArrayOutputStream, map.size());
                for (Map.Entry entry : map.entrySet()) {
                    this.a(byteArrayOutputStream, entry.getKey());
                    this.a(byteArrayOutputStream, entry.getValue());
                }
            }
            return;
        }
        byteArrayOutputStream.write(0);
    }

    protected final Object b(ByteBuffer byteBuffer) {
        if (byteBuffer.hasRemaining()) {
            return this.a(byteBuffer.get(), byteBuffer);
        }
        throw new IllegalArgumentException("Message corrupted");
    }

    static final class a
    extends ByteArrayOutputStream {
        a() {
        }

        byte[] a() {
            return this.buf;
        }
    }

}


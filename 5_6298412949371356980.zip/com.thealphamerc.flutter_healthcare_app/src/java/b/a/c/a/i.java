/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.nio.ByteBuffer
 */
package b.a.c.a;

import android.util.Log;
import b.a.c.a.b;
import b.a.c.a.h;
import b.a.c.a.j;
import java.nio.ByteBuffer;

public final class i {
    private final b.a.c.a.b a;
    private final String b;
    private final j c;

    public i(b.a.c.a.b b2, String string, j j2) {
        this.a = b2;
        this.b = string;
        this.c = j2;
    }

    public void a(c c2) {
        b.a.c.a.b b2 = this.a;
        String string = this.b;
        a a2 = c2 == null ? null : new a(c2);
        b2.a(string, a2);
    }

    public void a(String string, Object object) {
        this.a(string, object, null);
    }

    public void a(String string, Object object, d d2) {
        b.a.c.a.b b2 = this.a;
        String string2 = this.b;
        ByteBuffer byteBuffer = this.c.a(new h(string, object));
        b b3 = d2 == null ? null : new b(d2);
        b2.a(string2, byteBuffer, b3);
    }

    private final class b.a.c.a.i$a
    implements b.a {
        private final c a;

        b.a.c.a.i$a(c c2) {
            this.a = c2;
        }

        @Override
        public void a(ByteBuffer byteBuffer, final b.b b2) {
            h h2 = i.this.c.a(byteBuffer);
            try {
                this.a.a(h2, new d(){

                    @Override
                    public void a() {
                        b2.a(null);
                    }

                    @Override
                    public void a(Object object) {
                        b2.a(i.this.c.a(object));
                    }

                    @Override
                    public void a(String string, String string2, Object object) {
                        b2.a(i.this.c.a(string, string2, object));
                    }
                });
                return;
            }
            catch (RuntimeException runtimeException) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("MethodChannel#");
                stringBuilder.append(i.this.b);
                Log.e((String)stringBuilder.toString(), (String)"Failed to handle method call", (Throwable)runtimeException);
                b2.a(i.this.c.a("error", runtimeException.getMessage(), null));
                return;
            }
        }

    }

    private final class b
    implements b.b {
        private final d a;

        b(d d2) {
            this.a = d2;
        }

        /*
         * Unable to fully structure code
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         * Lifted jumps to return sites
         */
        @Override
        public void a(ByteBuffer var1_1) {
            block4 : {
                if (var1_1 != null) ** GOTO lbl6
                try {
                    this.a.a();
                    return;
lbl6: // 2 sources:
                    this.a.a(i.a(i.this).b(var1_1));
                    return;
                }
                catch (RuntimeException var3_2) {
                    break block4;
                }
                catch (b.a.c.a.c var2_3) {
                    this.a.a(var2_3.a, var2_3.getMessage(), var2_3.b);
                    return;
                }
            }
            var4_4 = new StringBuilder();
            var4_4.append("MethodChannel#");
            var4_4.append(i.b(i.this));
            Log.e((String)var4_4.toString(), (String)"Failed to handle method call result", (Throwable)var3_2);
        }
    }

    public static interface c {
        public void a(h var1, d var2);
    }

    public static interface d {
        public void a();

        public void a(Object var1);

        public void a(String var1, String var2, Object var3);
    }

}


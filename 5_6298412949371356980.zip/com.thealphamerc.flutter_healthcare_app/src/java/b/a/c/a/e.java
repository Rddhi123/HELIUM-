/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.IllegalArgumentException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Throwable
 *  java.nio.ByteBuffer
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package b.a.c.a;

import b.a.c.a.c;
import b.a.c.a.d;
import b.a.c.a.f;
import b.a.c.a.h;
import b.a.c.a.j;
import java.nio.ByteBuffer;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class e
implements j {
    public static final e a = new e();

    private e() {
    }

    @Override
    public h a(ByteBuffer byteBuffer) {
        try {
            Object object = d.a.a(byteBuffer);
            if (object instanceof JSONObject) {
                JSONObject jSONObject = (JSONObject)object;
                Object object2 = jSONObject.get("method");
                Object object3 = this.b(jSONObject.opt("args"));
                if (object2 instanceof String) {
                    return new h((String)object2, object3);
                }
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid method call: ");
            stringBuilder.append(object);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        catch (JSONException jSONException) {
            throw new IllegalArgumentException("Invalid JSON", (Throwable)jSONException);
        }
    }

    @Override
    public ByteBuffer a(h h2) {
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("method", (Object)h2.a);
            jSONObject.put("args", f.a(h2.b));
            ByteBuffer byteBuffer = d.a.a((Object)jSONObject);
            return byteBuffer;
        }
        catch (JSONException jSONException) {
            throw new IllegalArgumentException("Invalid JSON", (Throwable)jSONException);
        }
    }

    @Override
    public ByteBuffer a(Object object) {
        return d.a.a((Object)new JSONArray().put(f.a(object)));
    }

    @Override
    public ByteBuffer a(String string, String string2, Object object) {
        return d.a.a((Object)new JSONArray().put((Object)string).put(f.a(string2)).put(f.a(object)));
    }

    Object b(Object object) {
        if (object == JSONObject.NULL) {
            object = null;
        }
        return object;
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public Object b(ByteBuffer byteBuffer) {
        try {
            Object object = d.a.a(byteBuffer);
            if (object instanceof JSONArray) {
                JSONArray jSONArray = (JSONArray)object;
                if (jSONArray.length() == 1) {
                    return this.b(jSONArray.opt(0));
                }
                if (jSONArray.length() == 3) {
                    Object object2 = jSONArray.get(0);
                    Object object3 = this.b(jSONArray.opt(1));
                    Object object4 = this.b(jSONArray.opt(2));
                    if (object2 instanceof String && (object3 == null || object3 instanceof String)) {
                        throw new c((String)object2, (String)object3, object4);
                    }
                }
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Invalid envelope: ");
            stringBuilder.append(object);
            throw new IllegalArgumentException(stringBuilder.toString());
        }
        catch (JSONException jSONException) {
            throw new IllegalArgumentException("Invalid JSON", (Throwable)jSONException);
        }
    }
}


/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.IBinder
 *  android.provider.Settings
 *  android.provider.Settings$Secure
 *  android.text.Editable
 *  android.text.Editable$Factory
 *  android.text.Selection
 *  android.text.Spannable
 *  android.view.View
 *  android.view.inputmethod.BaseInputConnection
 *  android.view.inputmethod.EditorInfo
 *  android.view.inputmethod.InputConnection
 *  android.view.inputmethod.InputMethodManager
 *  android.view.inputmethod.InputMethodSubtype
 *  java.lang.CharSequence
 *  java.lang.Enum
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 */
package b.a.c.b;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Context;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.text.Editable;
import android.text.Selection;
import android.text.Spannable;
import android.view.View;
import android.view.inputmethod.BaseInputConnection;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.view.inputmethod.InputMethodSubtype;
import io.flutter.embedding.engine.i.j;
import io.flutter.plugin.platform.i;

public class b {
    private final View a;
    private final InputMethodManager b;
    private final j c;
    private b d = new b(b.a.a, 0);
    private j.b e;
    private Editable f;
    private boolean g;
    private InputConnection h;
    private i i;
    private final boolean j;
    private boolean k;

    public b(View view, io.flutter.embedding.engine.e.a a2, i i2) {
        this.a = view;
        this.b = (InputMethodManager)view.getContext().getSystemService("input_method");
        this.c = new j(a2);
        this.c.a(new j.f(){

            @Override
            public void a() {
                b b2 = b.this;
                b2.a(b2.a);
            }

            @Override
            public void a(int n2) {
                b.this.b(n2);
            }

            @Override
            public void a(int n2, j.b b2) {
                b.this.a(n2, b2);
            }

            @Override
            public void a(j.e e2) {
                b b2 = b.this;
                b2.a(b2.a, e2);
            }

            @Override
            public void b() {
                b.this.f();
            }

            @Override
            public void c() {
                b b2 = b.this;
                b2.b(b2.a);
            }
        });
        this.c.a();
        this.i = i2;
        this.i.a(this);
        this.j = this.g();
    }

    private static int a(j.c c2, boolean bl, boolean bl2, boolean bl3, j.d d2) {
        j.g g2 = c2.a;
        if (g2 == j.g.c) {
            return 4;
        }
        if (g2 == j.g.d) {
            int n2 = 2;
            if (c2.b) {
                n2 = 4098;
            }
            if (c2.c) {
                n2 |= 8192;
            }
            return n2;
        }
        if (g2 == j.g.e) {
            return 3;
        }
        int n3 = 1;
        if (g2 == j.g.f) {
            n3 = 131073;
        } else if (g2 == j.g.g) {
            n3 = 33;
        } else if (g2 == j.g.h) {
            n3 = 17;
        } else if (g2 == j.g.i) {
            n3 = 145;
        }
        if (bl) {
            n3 = 128 | (n3 | 524288);
        } else {
            if (bl2) {
                n3 |= 32768;
            }
            if (!bl3) {
                n3 |= 524288;
            }
        }
        if (d2 == j.d.b) {
            return n3 | 4096;
        }
        if (d2 == j.d.c) {
            return n3 | 8192;
        }
        if (d2 == j.d.d) {
            n3 |= 16384;
        }
        return n3;
    }

    private void a(View view) {
        this.b.hideSoftInputFromWindow(view.getApplicationWindowToken(), 0);
    }

    private void a(j.e e2) {
        int n2 = e2.b;
        int n3 = e2.c;
        if (n2 >= 0 && n2 <= this.f.length() && n3 >= 0 && n3 <= this.f.length()) {
            Selection.setSelection((Spannable)this.f, (int)n2, (int)n3);
            return;
        }
        Selection.removeSelection((Spannable)this.f);
    }

    private void b(int n2) {
        this.a.requestFocus();
        this.d = new b(b.a.c, n2);
        this.b.restartInput(this.a);
        this.g = false;
    }

    private void b(View view) {
        view.requestFocus();
        this.b.showSoftInput(view, 0);
    }

    private void f() {
        if (this.d.a == b.a.c) {
            return;
        }
        this.d = new b(b.a.a, 0);
        this.e();
    }

    @SuppressLint(value={"NewApi"})
    private boolean g() {
        if (this.b.getCurrentInputMethodSubtype() != null && Build.VERSION.SDK_INT >= 21 && Build.MANUFACTURER.equals((Object)"samsung")) {
            return Settings.Secure.getString((ContentResolver)this.a.getContext().getContentResolver(), (String)"default_input_method").contains((CharSequence)"Samsung");
        }
        return false;
    }

    public InputConnection a(View view, EditorInfo editorInfo) {
        b b2 = this.d;
        b.a a2 = b2.a;
        if (a2 == b.a.a) {
            this.h = null;
            return null;
        }
        if (a2 == b.a.c) {
            if (this.k) {
                return this.h;
            }
            this.h = this.i.a((Integer)b2.b).onCreateInputConnection(editorInfo);
            return this.h;
        }
        j.b b3 = this.e;
        editorInfo.inputType = b.a(b3.e, b3.a, b3.b, b3.c, b3.d);
        editorInfo.imeOptions = 33554432;
        Integer n2 = this.e.f;
        int n3 = n2 == null ? ((131072 & editorInfo.inputType) != 0 ? 1 : 6) : n2;
        String string = this.e.g;
        if (string != null) {
            editorInfo.actionLabel = string;
            editorInfo.actionId = n3;
        }
        editorInfo.imeOptions = n3 | editorInfo.imeOptions;
        b.a.c.b.a a3 = new b.a.c.b.a(view, this.d.b, this.c, this.f);
        editorInfo.initialSelStart = Selection.getSelectionStart((CharSequence)this.f);
        editorInfo.initialSelEnd = Selection.getSelectionEnd((CharSequence)this.f);
        this.h = a3;
        return this.h;
    }

    public void a() {
        this.i.d();
    }

    public void a(int n2) {
        b b2 = this.d;
        if (b2.a == b.a.c && b2.b == n2) {
            this.d = new b(b.a.a, 0);
            this.a(this.a);
            this.b.restartInput(this.a);
            this.g = false;
        }
    }

    void a(int n2, j.b b2) {
        this.d = new b(b.a.b, n2);
        this.e = b2;
        this.f = Editable.Factory.getInstance().newEditable((CharSequence)"");
        this.g = true;
        this.e();
    }

    void a(View view, j.e e2) {
        if (!this.j && !this.g && e2.a.equals((Object)this.f.toString())) {
            this.a(e2);
            this.b.updateSelection(this.a, Math.max((int)Selection.getSelectionStart((CharSequence)this.f), (int)0), Math.max((int)Selection.getSelectionEnd((CharSequence)this.f), (int)0), BaseInputConnection.getComposingSpanStart((Spannable)this.f), BaseInputConnection.getComposingSpanEnd((Spannable)this.f));
            return;
        }
        Editable editable = this.f;
        editable.replace(0, editable.length(), (CharSequence)e2.a);
        this.a(e2);
        this.b.restartInput(view);
        this.g = false;
    }

    public InputMethodManager b() {
        return this.b;
    }

    public InputConnection c() {
        return this.h;
    }

    public void d() {
        if (this.d.a == b.a.c) {
            this.k = true;
        }
    }

    public void e() {
        this.k = false;
    }

    private static class b {
        a a;
        int b;

        public b(a a2, int n2) {
            this.a = a2;
            this.b = n2;
        }

        static final class a
        extends Enum<a> {
            public static final /* enum */ a a = new a();
            public static final /* enum */ a b = new a();
            public static final /* enum */ a c = new a();
            private static final /* synthetic */ a[] d;

            static {
                a[] arra = new a[]{a, b, c};
                d = arra;
            }

            public static a valueOf(String string) {
                return (a)Enum.valueOf(a.class, (String)string);
            }

            public static a[] values() {
                return (a[])d.clone();
            }
        }

    }

}


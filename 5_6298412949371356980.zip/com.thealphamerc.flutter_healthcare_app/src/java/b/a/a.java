/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.util.Log
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 */
package b.a;

import android.util.Log;

public class a {
    public static void a(String string, String string2) {
    }

    public static void a(String string, String string2, Throwable throwable) {
        Log.e((String)string, (String)string2, (Throwable)throwable);
    }

    public static void b(String string, String string2) {
        Log.e((String)string, (String)string2);
    }

    public static void c(String string, String string2) {
    }

    public static void d(String string, String string2) {
        Log.w((String)string, (String)string2);
    }
}


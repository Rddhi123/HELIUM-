/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.InputDevice
 *  android.view.InputDevice$MotionRange
 *  android.view.MotionEvent
 *  java.lang.AssertionError
 *  java.lang.Object
 *  java.nio.ByteBuffer
 *  java.nio.ByteOrder
 */
package b.a.b.a;

import android.os.Build;
import android.view.InputDevice;
import android.view.MotionEvent;
import io.flutter.embedding.engine.h.a;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class b {
    private final a a;

    public b(a a2) {
        this.a = a2;
    }

    private int a(int n2) {
        if (n2 == 0) {
            return 4;
        }
        if (n2 == 1) {
            return 6;
        }
        if (n2 == 5) {
            return 4;
        }
        if (n2 == 6) {
            return 6;
        }
        if (n2 == 2) {
            return 5;
        }
        if (n2 == 7) {
            return 3;
        }
        if (n2 == 3) {
            return 0;
        }
        if (n2 == 8) {
            return 3;
        }
        return -1;
    }

    private void a(MotionEvent motionEvent, int n2, int n3, int n4, ByteBuffer byteBuffer) {
        long l2;
        InputDevice.MotionRange motionRange;
        double d2;
        double d3;
        double d4;
        if (n3 == -1) {
            return;
        }
        int n5 = this.b(motionEvent.getToolType(n2));
        int n6 = motionEvent.getActionMasked() == 8 ? 1 : 0;
        byteBuffer.putLong(1000L * motionEvent.getEventTime());
        byteBuffer.putLong((long)n3);
        byteBuffer.putLong((long)n5);
        byteBuffer.putLong((long)n6);
        byteBuffer.putLong((long)motionEvent.getPointerId(n2));
        byteBuffer.putLong(0L);
        byteBuffer.putDouble((double)motionEvent.getX(n2));
        byteBuffer.putDouble((double)motionEvent.getY(n2));
        byteBuffer.putDouble(0.0);
        byteBuffer.putDouble(0.0);
        if (n5 == 1) {
            l2 = 31 & motionEvent.getButtonState();
            if (l2 == 0L && motionEvent.getSource() == 8194 && (n3 == 4 || n3 == 5)) {
                l2 = 1L;
            }
        } else {
            l2 = n5 == 2 ? (long)(15 & motionEvent.getButtonState() >> 4) : 0L;
        }
        byteBuffer.putLong(l2);
        byteBuffer.putLong(0L);
        byteBuffer.putLong(0L);
        byteBuffer.putDouble((double)motionEvent.getPressure(n2));
        double d5 = 1.0;
        if (motionEvent.getDevice() != null && (motionRange = motionEvent.getDevice().getMotionRange(2)) != null) {
            d3 = motionRange.getMin();
            d5 = motionRange.getMax();
        } else {
            d3 = 0.0;
        }
        byteBuffer.putDouble(d3);
        byteBuffer.putDouble(d5);
        if (n5 == 2) {
            byteBuffer.putDouble((double)motionEvent.getAxisValue(24, n2));
            d4 = 0.0;
        } else {
            d4 = 0.0;
            byteBuffer.putDouble(d4);
        }
        byteBuffer.putDouble(d4);
        byteBuffer.putDouble((double)motionEvent.getSize(n2));
        byteBuffer.putDouble((double)motionEvent.getToolMajor(n2));
        byteBuffer.putDouble((double)motionEvent.getToolMinor(n2));
        byteBuffer.putDouble(d4);
        byteBuffer.putDouble(d4);
        byteBuffer.putDouble((double)motionEvent.getAxisValue(8, n2));
        if (n5 == 2) {
            byteBuffer.putDouble((double)motionEvent.getAxisValue(25, n2));
        } else {
            byteBuffer.putDouble(d4);
        }
        byteBuffer.putLong((long)n4);
        if (n6 == 1) {
            byteBuffer.putDouble((double)(-motionEvent.getAxisValue(10)));
            d2 = -motionEvent.getAxisValue(9);
        } else {
            d2 = 0.0;
            byteBuffer.putDouble(d2);
        }
        byteBuffer.putDouble(d2);
    }

    private int b(int n2) {
        if (n2 != 1) {
            if (n2 != 2) {
                if (n2 != 3) {
                    if (n2 != 4) {
                        return 4;
                    }
                    return 3;
                }
                return 1;
            }
            return 2;
        }
        return 0;
    }

    public boolean a(MotionEvent motionEvent) {
        boolean bl = Build.VERSION.SDK_INT >= 18 && motionEvent.isFromSource(2);
        boolean bl2 = motionEvent.getActionMasked() == 7 || motionEvent.getActionMasked() == 8;
        if (bl) {
            if (!bl2) {
                return false;
            }
            int n2 = this.a(motionEvent.getActionMasked());
            ByteBuffer byteBuffer = ByteBuffer.allocateDirect((int)(8 * (28 * motionEvent.getPointerCount())));
            byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
            this.a(motionEvent, motionEvent.getActionIndex(), n2, 0, byteBuffer);
            if (byteBuffer.position() % 224 == 0) {
                this.a.a(byteBuffer, byteBuffer.position());
                return true;
            }
            throw new AssertionError((Object)"Packet position is not on field boundary.");
        }
        return false;
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean b(MotionEvent motionEvent) {
        ByteBuffer byteBuffer;
        block6 : {
            int n2;
            int n3;
            int n4;
            block5 : {
                block4 : {
                    n4 = motionEvent.getPointerCount();
                    byteBuffer = ByteBuffer.allocateDirect((int)(8 * (n4 * 28)));
                    byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
                    int n5 = motionEvent.getActionMasked();
                    n2 = this.a(motionEvent.getActionMasked());
                    boolean bl = n5 == 0 || n5 == 5;
                    boolean bl2 = !bl && (n5 == 1 || n5 == 6);
                    if (bl) break block4;
                    if (bl2) {
                        for (n3 = 0; n3 < n4; ++n3) {
                            if (n3 == motionEvent.getActionIndex() || motionEvent.getToolType(n3) != 1) continue;
                            this.a(motionEvent, n3, 5, 1, byteBuffer);
                        }
                    }
                    break block5;
                }
                this.a(motionEvent, motionEvent.getActionIndex(), n2, 0, byteBuffer);
                break block6;
            }
            while (n3 < n4) {
                this.a(motionEvent, n3, n2, 0, byteBuffer);
                ++n3;
            }
        }
        if (byteBuffer.position() % 224 == 0) {
            this.a.a(byteBuffer, byteBuffer.position());
            return true;
        }
        AssertionError assertionError = new AssertionError((Object)"Packet position is not on field boundary");
        throw assertionError;
    }
}


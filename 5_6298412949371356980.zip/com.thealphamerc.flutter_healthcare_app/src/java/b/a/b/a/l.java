/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.annotation.TargetApi
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.content.res.Configuration
 *  android.content.res.Resources
 *  android.graphics.Insets
 *  android.graphics.Rect
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.LocaleList
 *  android.text.format.DateFormat
 *  android.util.AttributeSet
 *  android.util.DisplayMetrics
 *  android.view.KeyEvent
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.WindowInsets
 *  android.view.accessibility.AccessibilityManager
 *  android.view.accessibility.AccessibilityNodeProvider
 *  android.view.inputmethod.EditorInfo
 *  android.view.inputmethod.InputConnection
 *  android.view.inputmethod.InputMethodManager
 *  android.widget.FrameLayout
 *  java.lang.Enum
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Locale
 *  java.util.Set
 */
package b.a.b.a;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.ContentResolver;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Insets;
import android.graphics.Rect;
import android.os.Build;
import android.os.LocaleList;
import android.text.format.DateFormat;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeProvider;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import b.a.b.a.j;
import b.a.b.a.k;
import io.flutter.embedding.engine.h.a;
import io.flutter.embedding.engine.i.h;
import io.flutter.plugin.platform.i;
import io.flutter.view.c;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class l
extends FrameLayout {
    private e a;
    private f b;
    private io.flutter.embedding.engine.h.c c;
    private final Set<io.flutter.embedding.engine.h.b> d = new HashSet();
    private boolean e;
    private io.flutter.embedding.engine.a f;
    private final Set<d> g = new HashSet();
    private b.a.c.b.b h;
    private b.a.b.a.a i;
    private b.a.b.a.b j;
    private io.flutter.view.c k;
    private final a.c l = new a.c();
    private final c.i m = new c.i(){

        @Override
        public void a(boolean bl, boolean bl2) {
            l.this.a(bl, bl2);
        }
    };
    private final io.flutter.embedding.engine.h.b n = new io.flutter.embedding.engine.h.b(){

        @Override
        public void a() {
            l.this.e = true;
            Iterator iterator = l.this.d.iterator();
            while (iterator.hasNext()) {
                ((io.flutter.embedding.engine.h.b)iterator.next()).a();
            }
        }

        @Override
        public void b() {
            l.this.e = false;
            Iterator iterator = l.this.d.iterator();
            while (iterator.hasNext()) {
                ((io.flutter.embedding.engine.h.b)iterator.next()).b();
            }
        }
    };

    private l(Context context, AttributeSet attributeSet, e e2, f f2) {
        super(context, attributeSet);
        if (e2 == null) {
            e2 = e.a;
        }
        this.a = e2;
        if (f2 == null) {
            f2 = f.a;
        }
        this.b = f2;
        this.e();
    }

    public l(Context context, e e2, f f2) {
        this(context, null, e2, f2);
    }

    private void a(Configuration configuration) {
        ArrayList arrayList = new ArrayList();
        if (Build.VERSION.SDK_INT >= 24) {
            LocaleList localeList = configuration.getLocales();
            int n2 = localeList.size();
            for (int i2 = 0; i2 < n2; ++i2) {
                arrayList.add((Object)localeList.get(i2));
            }
        } else {
            arrayList.add((Object)configuration.locale);
        }
        this.f.g().a((List<Locale>)arrayList);
    }

    private void a(boolean bl, boolean bl2) {
        boolean bl3 = this.f.k().c();
        boolean bl4 = false;
        if (!bl3) {
            bl4 = false;
            if (!bl) {
                bl4 = false;
                if (!bl2) {
                    bl4 = true;
                }
            }
        }
        this.setWillNotDraw(bl4);
    }

    /*
     * Enabled aggressive block sorting
     */
    private void e() {
        block1 : {
            void var4_3;
            block2 : {
                block0 : {
                    b.a.a.c("FlutterView", "Initializing FlutterView");
                    int n2 = c.a[this.a.ordinal()];
                    if (n2 == 1) break block0;
                    if (n2 != 2) break block1;
                    b.a.a.c("FlutterView", "Internally using a FlutterTextureView.");
                    k k2 = new k(this.getContext());
                    break block2;
                }
                b.a.a.c("FlutterView", "Internally using a FlutterSurfaceView.");
                Context context = this.getContext();
                boolean bl = this.b == f.b;
                j j2 = new j(context, bl);
            }
            this.c = var4_3;
            this.addView((View)var4_3);
        }
        this.setFocusable(true);
        this.setFocusableInTouchMode(true);
    }

    private void f() {
        if (!this.c()) {
            b.a.a.d("FlutterView", "Tried to send viewport metrics from Android to Flutter but this FlutterView was not attached to a FlutterEngine.");
            return;
        }
        this.l.a = this.getResources().getDisplayMetrics().density;
        this.f.k().a(this.l);
    }

    public void a() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Detaching from a FlutterEngine: ");
        stringBuilder.append((Object)this.f);
        b.a.a.a("FlutterView", stringBuilder.toString());
        if (!this.c()) {
            b.a.a.a("FlutterView", "Not attached to an engine. Doing nothing.");
            return;
        }
        Iterator iterator = this.g.iterator();
        while (iterator.hasNext()) {
            ((d)iterator.next()).a();
        }
        this.f.j().c();
        this.f.j().a();
        this.k.c();
        this.k = null;
        this.h.b().restartInput((View)this);
        this.h.a();
        io.flutter.embedding.engine.h.a a2 = this.f.k();
        this.e = false;
        a2.b(this.n);
        a2.d();
        a2.a(false);
        this.c.a();
        this.f = null;
    }

    public void a(d d2) {
        this.g.add((Object)d2);
    }

    public void a(io.flutter.embedding.engine.a a2) {
        io.flutter.view.c c2;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Attaching to a FlutterEngine: ");
        stringBuilder.append((Object)a2);
        b.a.a.a("FlutterView", stringBuilder.toString());
        if (this.c()) {
            if (a2 == this.f) {
                b.a.a.a("FlutterView", "Already attached to this engine. Doing nothing.");
                return;
            }
            b.a.a.a("FlutterView", "Currently attached to a different engine. Detaching and then attaching to new engine.");
            this.a();
        }
        this.f = a2;
        io.flutter.embedding.engine.h.a a3 = this.f.k();
        this.e = a3.b();
        this.c.a(a3);
        a3.a(this.n);
        this.h = new b.a.c.b.b((View)this, this.f.d(), this.f.j());
        this.i = new b.a.b.a.a(this.f.e(), this.h);
        this.j = new b.a.b.a.b(this.f.k());
        this.k = c2 = new io.flutter.view.c((View)this, a2.b(), (AccessibilityManager)this.getContext().getSystemService("accessibility"), this.getContext().getContentResolver(), this.f.j());
        this.k.a(this.m);
        this.a(this.k.a(), this.k.b());
        this.f.j().a(this.k);
        this.h.b().restartInput((View)this);
        this.d();
        this.a(this.getResources().getConfiguration());
        this.f();
        a2.j().a((View)this);
        Iterator iterator = this.g.iterator();
        while (iterator.hasNext()) {
            ((d)iterator.next()).a(a2);
        }
        if (this.e) {
            this.n.a();
        }
    }

    public void a(io.flutter.embedding.engine.h.b b2) {
        this.d.add((Object)b2);
    }

    public void b(d d2) {
        this.g.remove((Object)d2);
    }

    public void b(io.flutter.embedding.engine.h.b b2) {
        this.d.remove((Object)b2);
    }

    public boolean b() {
        return this.e;
    }

    public boolean c() {
        io.flutter.embedding.engine.a a2 = this.f;
        return a2 != null && a2.k() == this.c.getAttachedRenderer();
    }

    public boolean checkInputConnectionProxy(View view) {
        io.flutter.embedding.engine.a a2 = this.f;
        if (a2 != null) {
            return a2.j().b(view);
        }
        return super.checkInputConnectionProxy(view);
    }

    void d() {
        boolean bl = (48 & this.getResources().getConfiguration().uiMode) == 32;
        h.b b2 = bl ? h.b.c : h.b.b;
        h.a a2 = this.f.l().a();
        a2.a(this.getResources().getConfiguration().fontScale);
        a2.a(DateFormat.is24HourFormat((Context)this.getContext()));
        a2.a(b2);
        a2.a();
    }

    protected boolean fitSystemWindows(Rect rect) {
        if (Build.VERSION.SDK_INT <= 19) {
            a.c c2 = this.l;
            c2.d = rect.top;
            c2.e = rect.right;
            c2.f = 0;
            c2.g = rect.left;
            c2.h = 0;
            c2.i = 0;
            c2.j = rect.bottom;
            c2.k = 0;
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Updating window insets (fitSystemWindows()):\nStatus bar insets: Top: ");
            stringBuilder.append(this.l.d);
            stringBuilder.append(", Left: ");
            stringBuilder.append(this.l.g);
            stringBuilder.append(", Right: ");
            stringBuilder.append(this.l.e);
            stringBuilder.append("\nKeyboard insets: Bottom: ");
            stringBuilder.append(this.l.j);
            stringBuilder.append(", Left: ");
            stringBuilder.append(this.l.k);
            stringBuilder.append(", Right: ");
            stringBuilder.append(this.l.i);
            b.a.a.c("FlutterView", stringBuilder.toString());
            this.f();
            return true;
        }
        return super.fitSystemWindows(rect);
    }

    public AccessibilityNodeProvider getAccessibilityNodeProvider() {
        io.flutter.view.c c2 = this.k;
        if (c2 != null && c2.a()) {
            return this.k;
        }
        return null;
    }

    public io.flutter.embedding.engine.a getAttachedFlutterEngine() {
        return this.f;
    }

    @SuppressLint(value={"InlinedApi", "NewApi"})
    @TargetApi(value=20)
    public final WindowInsets onApplyWindowInsets(WindowInsets windowInsets) {
        WindowInsets windowInsets2 = super.onApplyWindowInsets(windowInsets);
        this.l.d = windowInsets.getSystemWindowInsetTop();
        this.l.e = windowInsets.getSystemWindowInsetRight();
        a.c c2 = this.l;
        c2.f = 0;
        c2.g = windowInsets.getSystemWindowInsetLeft();
        a.c c3 = this.l;
        c3.h = 0;
        c3.i = 0;
        c3.j = windowInsets.getSystemWindowInsetBottom();
        this.l.k = 0;
        if (Build.VERSION.SDK_INT >= 29) {
            Insets insets = windowInsets.getSystemGestureInsets();
            this.l.l = insets.top;
            this.l.m = insets.right;
            this.l.n = insets.bottom;
            this.l.o = insets.left;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Updating window insets (onApplyWindowInsets()):\nStatus bar insets: Top: ");
        stringBuilder.append(this.l.d);
        stringBuilder.append(", Left: ");
        stringBuilder.append(this.l.g);
        stringBuilder.append(", Right: ");
        stringBuilder.append(this.l.e);
        stringBuilder.append("\nKeyboard insets: Bottom: ");
        stringBuilder.append(this.l.j);
        stringBuilder.append(", Left: ");
        stringBuilder.append(this.l.k);
        stringBuilder.append(", Right: ");
        stringBuilder.append(this.l.i);
        stringBuilder.append("System Gesture Insets - Left: ");
        stringBuilder.append(this.l.o);
        stringBuilder.append(", Top: ");
        stringBuilder.append(this.l.l);
        stringBuilder.append(", Right: ");
        stringBuilder.append(this.l.m);
        stringBuilder.append(", Bottom: ");
        stringBuilder.append(this.l.j);
        b.a.a.c("FlutterView", stringBuilder.toString());
        this.f();
        return windowInsets2;
    }

    protected void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        if (this.f != null) {
            b.a.a.c("FlutterView", "Configuration changed. Sending locales and user settings to Flutter.");
            this.a(configuration);
            this.d();
        }
    }

    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        if (!this.c()) {
            return super.onCreateInputConnection(editorInfo);
        }
        return this.h.a((View)this, editorInfo);
    }

    public boolean onGenericMotionEvent(MotionEvent motionEvent) {
        boolean bl = this.c() && this.j.a(motionEvent);
        if (bl) {
            return true;
        }
        return super.onGenericMotionEvent(motionEvent);
    }

    public boolean onHoverEvent(MotionEvent motionEvent) {
        if (!this.c()) {
            return super.onHoverEvent(motionEvent);
        }
        return this.k.a(motionEvent);
    }

    public boolean onKeyDown(int n2, KeyEvent keyEvent) {
        if (!this.c()) {
            return super.onKeyDown(n2, keyEvent);
        }
        this.i.a(keyEvent);
        return super.onKeyDown(n2, keyEvent);
    }

    public boolean onKeyUp(int n2, KeyEvent keyEvent) {
        if (!this.c()) {
            return super.onKeyUp(n2, keyEvent);
        }
        this.i.b(keyEvent);
        return super.onKeyUp(n2, keyEvent);
    }

    protected void onSizeChanged(int n2, int n3, int n4, int n5) {
        super.onSizeChanged(n2, n3, n4, n5);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Size changed. Sending Flutter new viewport metrics. FlutterView was ");
        stringBuilder.append(n4);
        stringBuilder.append(" x ");
        stringBuilder.append(n5);
        stringBuilder.append(", it is now ");
        stringBuilder.append(n2);
        stringBuilder.append(" x ");
        stringBuilder.append(n3);
        b.a.a.c("FlutterView", stringBuilder.toString());
        a.c c2 = this.l;
        c2.b = n2;
        c2.c = n3;
        this.f();
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (!this.c()) {
            return super.onTouchEvent(motionEvent);
        }
        if (Build.VERSION.SDK_INT >= 21) {
            this.requestUnbufferedDispatch(motionEvent);
        }
        return this.j.b(motionEvent);
    }

    public static interface d {
        public void a();

        public void a(io.flutter.embedding.engine.a var1);
    }

    public static final class e
    extends Enum<e> {
        public static final /* enum */ e a = new e();
        public static final /* enum */ e b = new e();
        private static final /* synthetic */ e[] c;

        static {
            e[] arre = new e[]{a, b};
            c = arre;
        }

        public static e valueOf(String string) {
            return (e)Enum.valueOf(e.class, (String)string);
        }

        public static e[] values() {
            return (e[])c.clone();
        }
    }

    public static final class f
    extends Enum<f> {
        public static final /* enum */ f a = new f();
        public static final /* enum */ f b = new f();
        private static final /* synthetic */ f[] c;

        static {
            f[] arrf = new f[]{a, b};
            c = arrf;
        }

        public static f valueOf(String string) {
            return (f)Enum.valueOf(f.class, (String)string);
        }

        public static f[] values() {
            return (f[])c.clone();
        }
    }

}


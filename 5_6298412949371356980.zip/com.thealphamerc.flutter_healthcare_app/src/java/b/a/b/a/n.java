/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.content.Context
 *  android.os.Bundle
 *  android.view.View
 *  java.lang.Object
 *  java.lang.Runnable
 */
package b.a.b.a;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.View;

public interface n {
    public View a(Context var1, Bundle var2);

    public void a(Runnable var1);

    @SuppressLint(value={"NewApi"})
    public boolean a();

    @SuppressLint(value={"NewApi"})
    public Bundle b();
}


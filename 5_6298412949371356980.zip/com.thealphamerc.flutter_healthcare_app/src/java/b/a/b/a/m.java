/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.os.Bundle
 *  java.lang.Object
 */
package b.a.b.a;

import android.annotation.SuppressLint;
import android.os.Bundle;
import b.a.b.a.n;

public final class m {
    @SuppressLint(value={"NewApi"})
    public static boolean a(n n2) {
        return false;
    }

    @SuppressLint(value={"NewApi"})
    public static Bundle b(n n2) {
        return null;
    }
}


/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.IBinder
 *  android.util.AttributeSet
 *  android.view.Surface
 *  android.view.SurfaceHolder
 *  android.view.SurfaceHolder$Callback
 *  android.view.SurfaceView
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package b.a.b.a;

import android.content.Context;
import android.os.IBinder;
import android.util.AttributeSet;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import io.flutter.embedding.engine.h.c;

public class j
extends SurfaceView
implements c {
    private final boolean a;
    private boolean b = false;
    private boolean c = false;
    private io.flutter.embedding.engine.h.a d;
    private final SurfaceHolder.Callback e = new SurfaceHolder.Callback(){

        public void surfaceChanged(SurfaceHolder surfaceHolder, int n2, int n3, int n4) {
            b.a.a.c("FlutterSurfaceView", "SurfaceHolder.Callback.surfaceChanged()");
            if (j.this.c) {
                j.this.a(n3, n4);
            }
        }

        public void surfaceCreated(SurfaceHolder surfaceHolder) {
            b.a.a.c("FlutterSurfaceView", "SurfaceHolder.Callback.startRenderingToSurface()");
            j.this.b = true;
            if (j.this.c) {
                j.this.b();
            }
        }

        public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
            b.a.a.c("FlutterSurfaceView", "SurfaceHolder.Callback.stopRenderingToSurface()");
            j.this.b = false;
            if (j.this.c) {
                j.this.c();
            }
        }
    };
    private final io.flutter.embedding.engine.h.b f = new io.flutter.embedding.engine.h.b(){

        @Override
        public void a() {
            b.a.a.c("FlutterSurfaceView", "onFlutterUiDisplayed()");
            j.this.setAlpha(1.0f);
            if (j.this.d != null) {
                j.this.d.b(this);
            }
        }

        @Override
        public void b() {
        }
    };

    private j(Context context, AttributeSet attributeSet, boolean bl) {
        super(context, attributeSet);
        this.a = bl;
        this.d();
    }

    public j(Context context, boolean bl) {
        this(context, null, bl);
    }

    private void a(int n2, int n3) {
        if (this.d != null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Notifying FlutterRenderer that Android surface size has changed to ");
            stringBuilder.append(n2);
            stringBuilder.append(" x ");
            stringBuilder.append(n3);
            b.a.a.c("FlutterSurfaceView", stringBuilder.toString());
            this.d.a(n2, n3);
            return;
        }
        throw new IllegalStateException("changeSurfaceSize() should only be called when flutterRenderer is non-null.");
    }

    private void b() {
        if (this.d != null && this.getHolder() != null) {
            this.d.a(this.getHolder().getSurface());
            return;
        }
        throw new IllegalStateException("connectSurfaceToRenderer() should only be called when flutterRenderer and getHolder() are non-null.");
    }

    private void c() {
        io.flutter.embedding.engine.h.a a2 = this.d;
        if (a2 != null) {
            a2.d();
            return;
        }
        throw new IllegalStateException("disconnectSurfaceFromRenderer() should only be called when flutterRenderer is non-null.");
    }

    private void d() {
        if (this.a) {
            this.getHolder().setFormat(-2);
            this.setZOrderOnTop(true);
        }
        this.getHolder().addCallback(this.e);
        this.setAlpha(0.0f);
    }

    @Override
    public void a() {
        if (this.d != null) {
            if (this.getWindowToken() != null) {
                b.a.a.c("FlutterSurfaceView", "Disconnecting FlutterRenderer from Android surface.");
                this.c();
            }
            this.setAlpha(0.0f);
            this.d.b(this.f);
            this.d = null;
            this.c = false;
            return;
        }
        b.a.a.d("FlutterSurfaceView", "detachFromRenderer() invoked when no FlutterRenderer was attached.");
    }

    @Override
    public void a(io.flutter.embedding.engine.h.a a2) {
        b.a.a.c("FlutterSurfaceView", "Attaching to FlutterRenderer.");
        if (this.d != null) {
            b.a.a.c("FlutterSurfaceView", "Already connected to a FlutterRenderer. Detaching from old one and attaching to new one.");
            this.d.d();
            this.d.b(this.f);
        }
        this.d = a2;
        this.c = true;
        this.d.a(this.f);
        if (this.b) {
            b.a.a.c("FlutterSurfaceView", "Surface is available for rendering. Connecting FlutterRenderer to Android surface.");
            this.b();
        }
    }

    @Override
    public io.flutter.embedding.engine.h.a getAttachedRenderer() {
        return this.d;
    }

}


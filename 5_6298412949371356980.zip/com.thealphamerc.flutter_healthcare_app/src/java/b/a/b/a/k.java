/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.graphics.SurfaceTexture
 *  android.os.IBinder
 *  android.util.AttributeSet
 *  android.view.Surface
 *  android.view.TextureView
 *  android.view.TextureView$SurfaceTextureListener
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package b.a.b.a;

import android.content.Context;
import android.graphics.SurfaceTexture;
import android.os.IBinder;
import android.util.AttributeSet;
import android.view.Surface;
import android.view.TextureView;
import io.flutter.embedding.engine.h.c;

public class k
extends TextureView
implements c {
    private boolean a = false;
    private boolean b = false;
    private io.flutter.embedding.engine.h.a c;
    private final TextureView.SurfaceTextureListener d = new TextureView.SurfaceTextureListener(){

        public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int n2, int n3) {
            b.a.a.c("FlutterTextureView", "SurfaceTextureListener.onSurfaceTextureAvailable()");
            k.this.a = true;
            if (k.this.b) {
                k.this.b();
            }
        }

        public boolean onSurfaceTextureDestroyed(SurfaceTexture surfaceTexture) {
            b.a.a.c("FlutterTextureView", "SurfaceTextureListener.onSurfaceTextureDestroyed()");
            k.this.a = false;
            if (k.this.b) {
                k.this.c();
            }
            return true;
        }

        public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int n2, int n3) {
            b.a.a.c("FlutterTextureView", "SurfaceTextureListener.onSurfaceTextureSizeChanged()");
            if (k.this.b) {
                k.this.a(n2, n3);
            }
        }

        public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {
        }
    };

    public k(Context context) {
        this(context, null);
    }

    public k(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.d();
    }

    private void a(int n2, int n3) {
        if (this.c != null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Notifying FlutterRenderer that Android surface size has changed to ");
            stringBuilder.append(n2);
            stringBuilder.append(" x ");
            stringBuilder.append(n3);
            b.a.a.c("FlutterTextureView", stringBuilder.toString());
            this.c.a(n2, n3);
            return;
        }
        throw new IllegalStateException("changeSurfaceSize() should only be called when flutterRenderer is non-null.");
    }

    private void b() {
        if (this.c != null && this.getSurfaceTexture() != null) {
            this.c.a(new Surface(this.getSurfaceTexture()));
            return;
        }
        throw new IllegalStateException("connectSurfaceToRenderer() should only be called when flutterRenderer and getSurfaceTexture() are non-null.");
    }

    private void c() {
        io.flutter.embedding.engine.h.a a2 = this.c;
        if (a2 != null) {
            a2.d();
            return;
        }
        throw new IllegalStateException("disconnectSurfaceFromRenderer() should only be called when flutterRenderer is non-null.");
    }

    private void d() {
        this.setSurfaceTextureListener(this.d);
    }

    @Override
    public void a() {
        if (this.c != null) {
            if (this.getWindowToken() != null) {
                b.a.a.c("FlutterTextureView", "Disconnecting FlutterRenderer from Android surface.");
                this.c();
            }
            this.c = null;
            this.b = false;
            return;
        }
        b.a.a.d("FlutterTextureView", "detachFromRenderer() invoked when no FlutterRenderer was attached.");
    }

    @Override
    public void a(io.flutter.embedding.engine.h.a a2) {
        b.a.a.c("FlutterTextureView", "Attaching to FlutterRenderer.");
        if (this.c != null) {
            b.a.a.c("FlutterTextureView", "Already connected to a FlutterRenderer. Detaching from old one and attaching to new one.");
            this.c.d();
        }
        this.c = a2;
        this.b = true;
        if (this.a) {
            b.a.a.c("FlutterTextureView", "Surface is available for rendering. Connecting FlutterRenderer to Android surface.");
            this.b();
        }
    }

    @Override
    public io.flutter.embedding.engine.h.a getAttachedRenderer() {
        return this.c;
    }

}


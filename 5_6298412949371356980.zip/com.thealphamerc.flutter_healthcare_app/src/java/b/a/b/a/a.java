/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.KeyCharacterMap
 *  android.view.KeyEvent
 *  android.view.inputmethod.InputConnection
 *  android.view.inputmethod.InputMethodManager
 *  java.lang.Character
 *  java.lang.Object
 */
package b.a.b.a;

import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.inputmethod.InputConnection;
import android.view.inputmethod.InputMethodManager;
import io.flutter.embedding.engine.i.b;

public class a {
    private final b a;
    private final b.a.c.b.b b;
    private int c;

    public a(b b2, b.a.c.b.b b3) {
        this.a = b2;
        this.b = b3;
    }

    private Character a(int n2) {
        if (n2 == 0) {
            return null;
        }
        Character c2 = Character.valueOf((char)((char)n2));
        boolean bl = (Integer.MIN_VALUE & n2) != 0;
        if (bl) {
            int n3 = n2 & Integer.MAX_VALUE;
            int n4 = this.c;
            if (n4 != 0) {
                n3 = KeyCharacterMap.getDeadChar((int)n4, (int)n3);
            }
            this.c = n3;
            return c2;
        }
        int n5 = this.c;
        if (n5 != 0) {
            int n6 = KeyCharacterMap.getDeadChar((int)n5, (int)n2);
            if (n6 > 0) {
                c2 = Character.valueOf((char)((char)n6));
            }
            this.c = 0;
        }
        return c2;
    }

    public void a(KeyEvent keyEvent) {
        if (this.b.c() != null && this.b.b().isAcceptingText()) {
            this.b.c().sendKeyEvent(keyEvent);
        }
        Character c2 = this.a(keyEvent.getUnicodeChar());
        this.a.a(new b.a(keyEvent, c2));
    }

    public void b(KeyEvent keyEvent) {
        Character c2 = this.a(keyEvent.getUnicodeChar());
        this.a.b(new b.a(keyEvent, c2));
    }
}


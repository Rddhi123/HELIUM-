/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.animation.Animator
 *  android.animation.Animator$AnimatorListener
 *  android.annotation.SuppressLint
 *  android.content.Context
 *  android.graphics.drawable.Drawable
 *  android.os.Bundle
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.ViewPropertyAnimator
 *  android.widget.ImageView
 *  android.widget.ImageView$ScaleType
 *  java.lang.Object
 *  java.lang.Runnable
 */
package b.a.b.a;

import android.animation.Animator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewPropertyAnimator;
import android.widget.ImageView;
import b.a.b.a.m;
import b.a.b.a.n;

public final class c
implements n {
    private final Drawable a;
    private final ImageView.ScaleType b;
    private final long c;
    private b d;

    public c(Drawable drawable) {
        this(drawable, ImageView.ScaleType.FIT_XY, 500L);
    }

    public c(Drawable drawable, ImageView.ScaleType scaleType, long l2) {
        this.a = drawable;
        this.b = scaleType;
        this.c = l2;
    }

    @Override
    public View a(Context context, Bundle bundle) {
        this.d = new b(context);
        this.d.a(this.a, this.b);
        return this.d;
    }

    @Override
    public void a(final Runnable runnable) {
        b b2 = this.d;
        if (b2 == null) {
            runnable.run();
            return;
        }
        b2.animate().alpha(0.0f).setDuration(this.c).setListener(new Animator.AnimatorListener(this){

            public void onAnimationCancel(Animator animator) {
                runnable.run();
            }

            public void onAnimationEnd(Animator animator) {
                runnable.run();
            }

            public void onAnimationRepeat(Animator animator) {
            }

            public void onAnimationStart(Animator animator) {
            }
        });
    }

    @SuppressLint(value={"NewApi"})
    @Override
    public /* synthetic */ boolean a() {
        return m.a(this);
    }

    @SuppressLint(value={"NewApi"})
    @Override
    public /* synthetic */ Bundle b() {
        return m.b(this);
    }

    public static class b
    extends ImageView {
        public b(Context context) {
            this(context, null, 0);
        }

        public b(Context context, AttributeSet attributeSet, int n2) {
            super(context, attributeSet, n2);
        }

        public void a(Drawable drawable, ImageView.ScaleType scaleType) {
            this.setScaleType(scaleType);
            this.setImageDrawable(drawable);
        }

        public void setSplashDrawable(Drawable drawable) {
            this.a(drawable, ImageView.ScaleType.FIT_XY);
        }
    }

}


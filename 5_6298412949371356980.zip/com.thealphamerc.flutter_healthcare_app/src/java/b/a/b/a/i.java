/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.Bundle
 *  android.os.Parcel
 *  android.os.Parcelable
 *  android.os.Parcelable$Creator
 *  android.util.AttributeSet
 *  android.view.View
 *  android.view.View$BaseSavedState
 *  android.widget.FrameLayout
 *  java.lang.ClassLoader
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package b.a.b.a;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.widget.FrameLayout;
import b.a.b.a.l;
import b.a.b.a.n;

final class i
extends FrameLayout {
    private static String j = "FlutterSplashView";
    private n a;
    private l b;
    private View c;
    private Bundle d;
    private String e;
    private String f;
    private final l.d g = new l.d(){

        @Override
        public void a() {
        }

        @Override
        public void a(io.flutter.embedding.engine.a a2) {
            i.this.b.b(this);
            i i2 = i.this;
            i2.a(i2.b, i.this.a);
        }
    };
    private final io.flutter.embedding.engine.h.b h = new io.flutter.embedding.engine.h.b(){

        @Override
        public void a() {
            if (i.this.a != null) {
                i.this.d();
            }
        }

        @Override
        public void b() {
        }
    };
    private final Runnable i = new Runnable(){

        public void run() {
            i i2 = i.this;
            i2.removeView(i2.c);
            i i3 = i.this;
            i3.f = i3.e;
        }
    };

    public i(Context context) {
        this(context, null, 0);
    }

    public i(Context context, AttributeSet attributeSet, int n2) {
        super(context, attributeSet, n2);
        this.setSaveEnabled(true);
    }

    private boolean a() {
        l l2 = this.b;
        if (l2 != null) {
            if (l2.c()) {
                return this.b.getAttachedFlutterEngine().d().a() != null && this.b.getAttachedFlutterEngine().d().a().equals((Object)this.f);
            }
            throw new IllegalStateException("Cannot determine if splash has completed when no FlutterEngine is attached to our FlutterView. This question depends on an isolate ID to differentiate Flutter experiences.");
        }
        throw new IllegalStateException("Cannot determine if splash has completed when no FlutterView is set.");
    }

    private boolean b() {
        l l2 = this.b;
        return l2 != null && l2.c() && !this.b.b() && !this.a();
    }

    private boolean c() {
        n n2;
        l l2 = this.b;
        return l2 != null && l2.c() && (n2 = this.a) != null && n2.a() && this.e();
    }

    private void d() {
        this.e = this.b.getAttachedFlutterEngine().d().a();
        String string = j;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Transitioning splash screen to a Flutter UI. Isolate: ");
        stringBuilder.append(this.e);
        b.a.a.c(string, stringBuilder.toString());
        this.a.a(this.i);
    }

    private boolean e() {
        l l2 = this.b;
        if (l2 != null) {
            if (l2.c()) {
                return this.b.b() && !this.a();
            }
            throw new IllegalStateException("Cannot determine if previous splash transition was interrupted when no FlutterEngine is attached to our FlutterView. This question depends on an isolate ID to differentiate Flutter experiences.");
        }
        throw new IllegalStateException("Cannot determine if previous splash transition was interrupted when no FlutterView is set.");
    }

    public void a(l l2, n n2) {
        View view;
        l l3 = this.b;
        if (l3 != null) {
            l3.b(this.h);
            this.removeView((View)this.b);
        }
        if ((view = this.c) != null) {
            this.removeView(view);
        }
        this.b = l2;
        this.addView((View)l2);
        this.a = n2;
        if (n2 != null) {
            if (this.b()) {
                b.a.a.c(j, "Showing splash screen UI.");
                this.c = n2.a(this.getContext(), this.d);
                this.addView(this.c);
                l2.a(this.h);
                return;
            }
            if (this.c()) {
                b.a.a.c(j, "Showing an immediate splash transition to Flutter due to previously interrupted transition.");
                this.c = n2.a(this.getContext(), this.d);
                this.addView(this.c);
                this.d();
                return;
            }
            if (!l2.c()) {
                b.a.a.c(j, "FlutterView is not yet attached to a FlutterEngine. Showing nothing until a FlutterEngine is attached.");
                l2.a(this.g);
            }
        }
    }

    protected void onRestoreInstanceState(Parcelable parcelable) {
        d d2 = (d)parcelable;
        super.onRestoreInstanceState(d2.getSuperState());
        this.f = d2.a;
        this.d = d2.b;
    }

    protected Parcelable onSaveInstanceState() {
        d d2 = new d(super.onSaveInstanceState());
        d2.a = this.f;
        n n2 = this.a;
        Bundle bundle = n2 != null ? n2.b() : null;
        d2.b = bundle;
        return d2;
    }

    public static class d
    extends View.BaseSavedState {
        private String a;
        private Bundle b;

        static {
            new Parcelable.Creator(){

                public d createFromParcel(Parcel parcel) {
                    return new d(parcel);
                }

                public d[] newArray(int n2) {
                    return new d[n2];
                }
            };
        }

        d(Parcel parcel) {
            super(parcel);
            this.a = parcel.readString();
            this.b = parcel.readBundle(d.class.getClassLoader());
        }

        d(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int n2) {
            super.writeToParcel(parcel, n2);
            parcel.writeString(this.a);
            parcel.writeBundle(this.b);
        }

    }

}


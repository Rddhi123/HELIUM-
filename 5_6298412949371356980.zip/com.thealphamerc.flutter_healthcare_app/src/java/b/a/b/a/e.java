/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Handler
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  androidx.lifecycle.e
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Arrays
 */
package b.a.b.a;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import b.a.b.a.g;
import b.a.b.a.h;
import b.a.b.a.i;
import b.a.b.a.l;
import b.a.b.a.n;
import b.a.b.a.o;
import io.flutter.embedding.engine.d;
import io.flutter.embedding.engine.e.a;
import java.util.Arrays;

final class e {
    private c a;
    private io.flutter.embedding.engine.a b;
    private i c;
    private l d;
    private io.flutter.plugin.platform.c e;
    private boolean f;
    private final io.flutter.embedding.engine.h.b g = new io.flutter.embedding.engine.h.b(){

        @Override
        public void a() {
            e.this.a.a();
        }

        @Override
        public void b() {
            e.this.a.b();
        }
    };

    e(c c2) {
        this.a = c2;
    }

    private void l() {
        if (this.a.h() != null) {
            return;
        }
        if (this.b.d().b()) {
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Executing Dart entrypoint: ");
        stringBuilder.append(this.a.j());
        stringBuilder.append(", and sending initial route: ");
        stringBuilder.append(this.a.e());
        b.a.a.a("FlutterActivityAndFragmentDelegate", stringBuilder.toString());
        if (this.a.e() != null) {
            this.b.h().a(this.a.e());
        }
        a.b b2 = new a.b(this.a.i(), this.a.j());
        this.b.d().a(b2);
    }

    private void m() {
        if (this.a != null) {
            return;
        }
        throw new IllegalStateException("Cannot execute method on a destroyed FlutterActivityAndFragmentDelegate.");
    }

    View a(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        i i2;
        int n2;
        b.a.a.c("FlutterActivityAndFragmentDelegate", "Creating FlutterView.");
        this.m();
        this.d = new l((Context)this.a.d(), this.a.l(), this.a.f());
        this.d.a(this.g);
        this.c = new i(this.a.o());
        if (Build.VERSION.SDK_INT >= 17) {
            i2 = this.c;
            n2 = View.generateViewId();
        } else {
            i2 = this.c;
            n2 = 486947586;
        }
        i2.setId(n2);
        this.c.a(this.d, this.a.n());
        return this.c;
    }

    void a(int n2) {
        this.m();
        if (this.b != null) {
            if (n2 == 10) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Forwarding onTrimMemory() to FlutterEngine. Level: ");
                stringBuilder.append(n2);
                b.a.a.c("FlutterActivityAndFragmentDelegate", stringBuilder.toString());
                this.b.m().a();
                return;
            }
        } else {
            b.a.a.d("FlutterActivityAndFragmentDelegate", "onTrimMemory() invoked before FlutterFragment was attached to an Activity.");
        }
    }

    void a(int n2, int n3, Intent intent) {
        this.m();
        if (this.b != null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Forwarding onActivityResult() to FlutterEngine:\nrequestCode: ");
            stringBuilder.append(n2);
            stringBuilder.append("\nresultCode: ");
            stringBuilder.append(n3);
            stringBuilder.append("\ndata: ");
            stringBuilder.append((Object)intent);
            b.a.a.c("FlutterActivityAndFragmentDelegate", stringBuilder.toString());
            this.b.c().a(n2, n3, intent);
            return;
        }
        b.a.a.d("FlutterActivityAndFragmentDelegate", "onActivityResult() invoked before FlutterFragment was attached to an Activity.");
    }

    void a(int n2, String[] arrstring, int[] arrn) {
        this.m();
        if (this.b != null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Forwarding onRequestPermissionsResult() to FlutterEngine:\nrequestCode: ");
            stringBuilder.append(n2);
            stringBuilder.append("\npermissions: ");
            stringBuilder.append(Arrays.toString((Object[])arrstring));
            stringBuilder.append("\ngrantResults: ");
            stringBuilder.append(Arrays.toString((int[])arrn));
            b.a.a.c("FlutterActivityAndFragmentDelegate", stringBuilder.toString());
            this.b.c().a(n2, arrstring, arrn);
            return;
        }
        b.a.a.d("FlutterActivityAndFragmentDelegate", "onRequestPermissionResult() invoked before FlutterFragment was attached to an Activity.");
    }

    void a(Context context) {
        this.m();
        if (this.b == null) {
            this.k();
        }
        c c2 = this.a;
        this.e = c2.a(c2.d(), this.b);
        if (this.a.k()) {
            b.a.a.a("FlutterActivityAndFragmentDelegate", "Attaching FlutterEngine to the Activity that owns this Fragment.");
            this.b.c().a(this.a.d(), this.a.c());
        }
        this.a.a(this.b);
    }

    void a(Intent intent) {
        this.m();
        if (this.b != null) {
            b.a.a.c("FlutterActivityAndFragmentDelegate", "Forwarding onNewIntent() to FlutterEngine.");
            this.b.c().a(intent);
            return;
        }
        b.a.a.d("FlutterActivityAndFragmentDelegate", "onNewIntent() invoked before FlutterFragment was attached to an Activity.");
    }

    void a(Bundle bundle) {
        b.a.a.c("FlutterActivityAndFragmentDelegate", "onActivityCreated. Giving plugins an opportunity to restore state.");
        this.m();
        if (this.a.k()) {
            this.b.c().a(bundle);
        }
    }

    boolean a() {
        return this.f;
    }

    void b() {
        this.m();
        if (this.b != null) {
            b.a.a.c("FlutterActivityAndFragmentDelegate", "Forwarding onBackPressed() to FlutterEngine.");
            this.b.h().a();
            return;
        }
        b.a.a.d("FlutterActivityAndFragmentDelegate", "Invoked onBackPressed() before FlutterFragment was attached to an Activity.");
    }

    void b(Bundle bundle) {
        b.a.a.c("FlutterActivityAndFragmentDelegate", "onSaveInstanceState. Giving plugins an opportunity to save state.");
        this.m();
        if (this.a.k()) {
            this.b.c().b(bundle);
        }
    }

    void c() {
        b.a.a.c("FlutterActivityAndFragmentDelegate", "onDestroyView()");
        this.m();
        this.d.b(this.g);
    }

    void d() {
        io.flutter.plugin.platform.c c2;
        b.a.a.c("FlutterActivityAndFragmentDelegate", "onDetach()");
        this.m();
        this.a.b(this.b);
        if (this.a.k()) {
            b.a.a.a("FlutterActivityAndFragmentDelegate", "Detaching FlutterEngine from the Activity that owns this Fragment.");
            if (this.a.d().isChangingConfigurations()) {
                this.b.c().b();
            } else {
                this.b.c().c();
            }
        }
        if ((c2 = this.e) != null) {
            c2.a();
            this.e = null;
        }
        this.b.f().a();
        if (this.a.m()) {
            this.b.a();
            if (this.a.h() != null) {
                io.flutter.embedding.engine.b.a().b(this.a.h());
            }
            this.b = null;
        }
    }

    void e() {
        b.a.a.c("FlutterActivityAndFragmentDelegate", "onPause()");
        this.m();
        this.b.f().b();
    }

    void f() {
        b.a.a.c("FlutterActivityAndFragmentDelegate", "onPostResume()");
        this.m();
        if (this.b != null) {
            io.flutter.plugin.platform.c c2 = this.e;
            if (c2 != null) {
                c2.b();
                return;
            }
        } else {
            b.a.a.d("FlutterActivityAndFragmentDelegate", "onPostResume() invoked before FlutterFragment was attached to an Activity.");
        }
    }

    void g() {
        b.a.a.c("FlutterActivityAndFragmentDelegate", "onResume()");
        this.m();
        this.b.f().d();
    }

    void h() {
        b.a.a.c("FlutterActivityAndFragmentDelegate", "onStart()");
        this.m();
        new Handler().post(new Runnable(){

            public void run() {
                b.a.a.c("FlutterActivityAndFragmentDelegate", "Attaching FlutterEngine to FlutterView.");
                e.this.d.a(e.this.b);
                e.this.l();
            }
        });
    }

    void i() {
        b.a.a.c("FlutterActivityAndFragmentDelegate", "onStop()");
        this.m();
        this.b.f().c();
        this.d.a();
    }

    void j() {
        this.m();
        if (this.b != null) {
            b.a.a.c("FlutterActivityAndFragmentDelegate", "Forwarding onUserLeaveHint() to FlutterEngine.");
            this.b.c().a();
            return;
        }
        b.a.a.d("FlutterActivityAndFragmentDelegate", "onUserLeaveHint() invoked before FlutterFragment was attached to an Activity.");
    }

    void k() {
        b.a.a.a("FlutterActivityAndFragmentDelegate", "Setting up FlutterEngine.");
        String string = this.a.h();
        if (string != null) {
            this.b = io.flutter.embedding.engine.b.a().a(string);
            this.f = true;
            if (this.b != null) {
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("The requested cached FlutterEngine did not exist in the FlutterEngineCache: '");
            stringBuilder.append(string);
            stringBuilder.append("'");
            throw new IllegalStateException(stringBuilder.toString());
        }
        c c2 = this.a;
        this.b = c2.a(c2.o());
        if (this.b != null) {
            this.f = true;
            return;
        }
        b.a.a.a("FlutterActivityAndFragmentDelegate", "No preferred FlutterEngine was provided. Creating a new FlutterEngine for this FlutterFragment.");
        this.b = new io.flutter.embedding.engine.a(this.a.o(), this.a.g().a());
        this.f = false;
    }

    static interface c
    extends o,
    h,
    g {
        public io.flutter.embedding.engine.a a(Context var1);

        public io.flutter.plugin.platform.c a(Activity var1, io.flutter.embedding.engine.a var2);

        public void a();

        public void a(io.flutter.embedding.engine.a var1);

        public void b();

        public void b(io.flutter.embedding.engine.a var1);

        public androidx.lifecycle.e c();

        public Activity d();

        public String e();

        public l.f f();

        public d g();

        public String h();

        public String i();

        public String j();

        public boolean k();

        public l.e l();

        public boolean m();

        public n n();

        public Context o();
    }

}


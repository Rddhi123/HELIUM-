/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.content.pm.ApplicationInfo
 *  android.graphics.drawable.ColorDrawable
 *  android.graphics.drawable.Drawable
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.view.LayoutInflater
 *  android.view.View
 *  android.view.ViewGroup
 *  android.view.Window
 *  androidx.lifecycle.e
 *  androidx.lifecycle.e$a
 *  androidx.lifecycle.g
 *  androidx.lifecycle.h
 *  java.lang.Object
 *  java.lang.String
 */
package b.a.b.a;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import androidx.lifecycle.e;
import androidx.lifecycle.g;
import androidx.lifecycle.h;
import b.a.b.a.c;
import b.a.b.a.e;
import b.a.b.a.f;
import b.a.b.a.l;
import b.a.b.a.n;
import io.flutter.embedding.engine.a;

public class d
extends Activity
implements e.c,
g {
    protected e a;
    private h b = new h((g)this);

    private void q() {
        if (Build.VERSION.SDK_INT >= 21) {
            Window window = this.getWindow();
            window.addFlags(Integer.MIN_VALUE);
            window.setStatusBarColor(1073741824);
            window.getDecorView().setSystemUiVisibility(1280);
        }
    }

    private void r() {
        if (this.p() == f.b) {
            this.getWindow().setBackgroundDrawable((Drawable)new ColorDrawable(0));
            this.getWindow().setFlags(512, 512);
        }
    }

    private View s() {
        return this.a.a(null, null, null);
    }

    /*
     * Exception decompiling
     */
    private Drawable t() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    private boolean u() {
        return (2 & this.getApplicationInfo().flags) != 0;
    }

    /*
     * Exception decompiling
     */
    private void v() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl31 : RETURN : trying to set 1 previously set to 0
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public a a(Context context) {
        return null;
    }

    @Override
    public io.flutter.plugin.platform.c a(Activity activity, a a2) {
        if (activity != null) {
            return new io.flutter.plugin.platform.c(this.d(), a2.i());
        }
        return null;
    }

    @Override
    public void a() {
        if (Build.VERSION.SDK_INT >= 21) {
            this.reportFullyDrawn();
        }
    }

    @Override
    public void b() {
    }

    @Override
    public void b(a a2) {
    }

    @Override
    public androidx.lifecycle.e c() {
        return this.b;
    }

    @Override
    public Activity d() {
        return this;
    }

    /*
     * Exception decompiling
     */
    @Override
    public String e() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public l.f f() {
        if (this.p() == f.a) {
            return l.f.a;
        }
        return l.f.b;
    }

    @Override
    public io.flutter.embedding.engine.d g() {
        return io.flutter.embedding.engine.d.a(this.getIntent());
    }

    @Override
    public String h() {
        return this.getIntent().getStringExtra("cached_engine_id");
    }

    @Override
    public String i() {
        String string;
        if (this.u() && "android.intent.action.RUN".equals((Object)this.getIntent().getAction()) && (string = this.getIntent().getDataString()) != null) {
            return string;
        }
        return io.flutter.view.d.a();
    }

    /*
     * Exception decompiling
     */
    @Override
    public String j() {
        // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
        // org.benf.cfr.reader.util.ConfusedCFRException: Underrun type stack
        // org.benf.cfr.reader.b.a.c.e.a(StackSim.java:35)
        // org.benf.cfr.reader.b.b.af.a(OperationFactoryPop.java:20)
        // org.benf.cfr.reader.b.b.e.a(JVMInstr.java:315)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:195)
        // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
        // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
        // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
        // org.benf.cfr.reader.entities.g.p(Method.java:396)
        // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
        // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
        // org.benf.cfr.reader.b.a(Driver.java:128)
        // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
        // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
        // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
        // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
        // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
        // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
        // java.lang.Thread.run(Thread.java:1012)
        throw new IllegalStateException("Decompilation failed");
    }

    @Override
    public boolean k() {
        return true;
    }

    @Override
    public l.e l() {
        if (this.p() == f.a) {
            return l.e.a;
        }
        return l.e.b;
    }

    @Override
    public boolean m() {
        boolean bl = this.getIntent().getBooleanExtra("destroy_engine_with_activity", false);
        if (this.h() == null) {
            if (this.a.a()) {
                return bl;
            }
            bl = this.getIntent().getBooleanExtra("destroy_engine_with_activity", true);
        }
        return bl;
    }

    @Override
    public n n() {
        Drawable drawable = this.t();
        if (drawable != null) {
            return new c(drawable);
        }
        return null;
    }

    @Override
    public Context o() {
        return this;
    }

    protected void onActivityResult(int n2, int n3, Intent intent) {
        this.a.a(n2, n3, intent);
    }

    public void onBackPressed() {
        this.a.b();
    }

    protected void onCreate(Bundle bundle) {
        this.v();
        super.onCreate(bundle);
        this.b.a(e.a.ON_CREATE);
        this.a = new e(this);
        this.a.a((Context)this);
        this.a.a(bundle);
        this.r();
        this.setContentView(this.s());
        this.q();
    }

    protected void onDestroy() {
        super.onDestroy();
        this.a.c();
        this.a.d();
        this.b.a(e.a.ON_DESTROY);
    }

    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        this.a.a(intent);
    }

    protected void onPause() {
        super.onPause();
        this.a.e();
        this.b.a(e.a.ON_PAUSE);
    }

    public void onPostResume() {
        super.onPostResume();
        this.a.f();
    }

    public void onRequestPermissionsResult(int n2, String[] arrstring, int[] arrn) {
        this.a.a(n2, arrstring, arrn);
    }

    protected void onResume() {
        super.onResume();
        this.b.a(e.a.ON_RESUME);
        this.a.g();
    }

    protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        this.a.b(bundle);
    }

    protected void onStart() {
        super.onStart();
        this.b.a(e.a.ON_START);
        this.a.h();
    }

    protected void onStop() {
        super.onStop();
        this.a.i();
        this.b.a(e.a.ON_STOP);
    }

    public void onTrimMemory(int n2) {
        super.onTrimMemory(n2);
        this.a.a(n2);
    }

    public void onUserLeaveHint() {
        this.a.j();
    }

    protected f p() {
        if (this.getIntent().hasExtra("background_mode")) {
            return f.valueOf(this.getIntent().getStringExtra("background_mode"));
        }
        return f.a;
    }
}


/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package b.a.d;

public interface b<T> {
    public boolean a(T var1);
}


/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Application
 *  android.content.Context
 */
package io.flutter.app;

import android.app.Application;
import android.content.Context;
import io.flutter.view.d;

public class FlutterApplication
extends Application {
    public void onCreate() {
        super.onCreate();
        d.a((Context)this);
    }
}


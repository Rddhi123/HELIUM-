/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.flutter.view;

import io.flutter.view.c;

public final class b
implements b.a.d.b {
    public static final /* synthetic */ b a;

    static /* synthetic */ {
        a = new b();
    }

    private /* synthetic */ b() {
    }

    public final boolean a(Object object) {
        return c.a((c.j)object);
    }
}


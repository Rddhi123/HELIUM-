/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.Choreographer
 *  android.view.Choreographer$FrameCallback
 *  android.view.Display
 *  android.view.WindowManager
 *  java.lang.Double
 *  java.lang.Object
 */
package io.flutter.view;

import android.view.Choreographer;
import android.view.Display;
import android.view.WindowManager;
import io.flutter.embedding.engine.FlutterJNI;

public class f {
    private static f c;
    private final WindowManager a;
    private final FlutterJNI.b b = new FlutterJNI.b(){

        @Override
        public void a(final long l2) {
            Choreographer.getInstance().postFrameCallback(new Choreographer.FrameCallback(){

                public void doFrame(long l22) {
                    double d2 = f.this.a.getDefaultDisplay().getRefreshRate();
                    Double.isNaN((double)d2);
                    FlutterJNI.nativeOnVsync(l22, l22 + (long)(1.0E9 / d2), l2);
                }
            });
        }

    };

    private f(WindowManager windowManager) {
        this.a = windowManager;
    }

    public static f a(WindowManager windowManager) {
        if (c == null) {
            c = new f(windowManager);
        }
        return c;
    }

    public void a() {
        FlutterJNI.setAsyncWaitForVsyncDelegate(this.b);
        FlutterJNI.setRefreshRateFPS(this.a.getDefaultDisplay().getRefreshRate());
    }

}


/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.flutter.view;

import b.a.d.b;
import io.flutter.view.c;

public final class a
implements b {
    private final /* synthetic */ c.j a;

    public /* synthetic */ a(c.j j2) {
        this.a = j2;
    }

    public final boolean a(Object object) {
        return c.a(this.a, (c.j)object);
    }
}


/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Keep
 *  java.lang.Object
 *  java.lang.String
 */
package io.flutter.view;

import androidx.annotation.Keep;
import io.flutter.embedding.engine.FlutterJNI;

@Keep
public final class FlutterCallbackInformation {
    public final String callbackClassName;
    public final String callbackLibraryPath;
    public final String callbackName;

    private FlutterCallbackInformation(String string, String string2, String string3) {
        this.callbackName = string;
        this.callbackClassName = string2;
        this.callbackLibraryPath = string3;
    }

    public static FlutterCallbackInformation lookupCallbackInformation(long l2) {
        return FlutterJNI.nativeLookupCallbackInformation(l2);
    }
}


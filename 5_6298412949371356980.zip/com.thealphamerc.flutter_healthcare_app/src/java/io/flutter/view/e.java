/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.SurfaceTexture
 *  java.lang.Object
 */
package io.flutter.view;

import android.graphics.SurfaceTexture;

public interface e {
    public a a();

    public static interface a {
        public void a();

        public long b();

        public SurfaceTexture c();
    }

}


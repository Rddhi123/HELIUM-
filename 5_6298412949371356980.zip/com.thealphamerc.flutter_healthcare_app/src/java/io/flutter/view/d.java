/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Object
 *  java.lang.String
 */
package io.flutter.view;

import android.content.Context;
import io.flutter.embedding.engine.f.a;

public class d {
    private static boolean a;

    public static String a() {
        return a.b().a();
    }

    public static void a(Context context) {
        if (a) {
            return;
        }
        a.b().a(context);
    }
}


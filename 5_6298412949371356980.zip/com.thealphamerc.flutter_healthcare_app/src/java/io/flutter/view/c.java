/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.annotation.TargetApi
 *  android.content.ContentResolver
 *  android.content.Context
 *  android.database.ContentObserver
 *  android.graphics.Rect
 *  android.net.Uri
 *  android.opengl.Matrix
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Bundle
 *  android.os.Handler
 *  android.provider.Settings
 *  android.provider.Settings$Global
 *  android.util.Log
 *  android.view.MotionEvent
 *  android.view.View
 *  android.view.ViewParent
 *  android.view.WindowInsets
 *  android.view.accessibility.AccessibilityEvent
 *  android.view.accessibility.AccessibilityManager
 *  android.view.accessibility.AccessibilityManager$AccessibilityStateChangeListener
 *  android.view.accessibility.AccessibilityManager$TouchExplorationStateChangeListener
 *  android.view.accessibility.AccessibilityNodeInfo
 *  android.view.accessibility.AccessibilityNodeInfo$AccessibilityAction
 *  android.view.accessibility.AccessibilityNodeInfo$CollectionInfo
 *  android.view.accessibility.AccessibilityNodeProvider
 *  android.view.accessibility.AccessibilityRecord
 *  java.lang.CharSequence
 *  java.lang.Enum
 *  java.lang.Float
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.nio.ByteBuffer
 *  java.nio.ByteOrder
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.List
 *  java.util.Map
 *  java.util.Map$Entry
 *  java.util.Set
 */
package io.flutter.view;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.ContentResolver;
import android.content.Context;
import android.database.ContentObserver;
import android.graphics.Rect;
import android.net.Uri;
import android.opengl.Matrix;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import android.view.accessibility.AccessibilityRecord;
import io.flutter.embedding.engine.i.a;
import io.flutter.view.AccessibilityViewEmbedder;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class c
extends AccessibilityNodeProvider {
    private static int x = 267386881;
    private final View a;
    private final io.flutter.embedding.engine.i.a b;
    private final AccessibilityManager c;
    private final AccessibilityViewEmbedder d;
    private final io.flutter.plugin.platform.h e;
    private final ContentResolver f;
    private final Map<Integer, j> g = new HashMap();
    private final Map<Integer, g> h = new HashMap();
    private j i;
    private Integer j;
    private Integer k;
    private int l = 0;
    private j m;
    private j n;
    private j o;
    private final List<Integer> p = new ArrayList();
    private int q = 0;
    private Integer r = 0;
    private i s;
    private final a.b t = new a.b(){

        @Override
        public void a(int n2) {
            c.this.b(n2, 1);
        }

        @Override
        public void a(String string) {
            AccessibilityEvent accessibilityEvent = c.this.a(0, 32);
            accessibilityEvent.getText().add((Object)string);
            c.this.a(accessibilityEvent);
        }

        @Override
        public void a(ByteBuffer byteBuffer, String[] arrstring) {
            byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
            c.this.a(byteBuffer, arrstring);
        }

        @Override
        public void b(int n2) {
            c.this.b(n2, 2);
        }

        @Override
        public void b(String string) {
            c.this.a.announceForAccessibility((CharSequence)string);
        }

        @Override
        public void b(ByteBuffer byteBuffer, String[] arrstring) {
            byteBuffer.order(ByteOrder.LITTLE_ENDIAN);
            c.this.b(byteBuffer, arrstring);
        }
    };
    private final AccessibilityManager.AccessibilityStateChangeListener u = new AccessibilityManager.AccessibilityStateChangeListener(){

        public void onAccessibilityStateChanged(boolean bl) {
            io.flutter.embedding.engine.i.a a2 = c.this.b;
            if (bl) {
                a2.a(c.this.t);
                c.this.b.b();
            } else {
                a2.a(null);
                c.this.b.a();
            }
            if (c.this.s != null) {
                c.this.s.a(bl, c.this.c.isTouchExplorationEnabled());
            }
        }
    };
    @TargetApi(value=19)
    private final AccessibilityManager.TouchExplorationStateChangeListener v;
    private final ContentObserver w = new ContentObserver(new Handler()){

        public void onChange(boolean bl) {
            this.onChange(bl, null);
        }

        public void onChange(boolean bl, Uri uri) {
            int n2;
            c c2;
            String string = Build.VERSION.SDK_INT < 17 ? null : Settings.Global.getString((ContentResolver)c.this.f, (String)"transition_animation_scale");
            boolean bl2 = string != null && string.equals((Object)"0");
            if (bl2) {
                c2 = c.this;
                n2 = c2.l | e.d.a;
            } else {
                c2 = c.this;
                n2 = c2.l & (-1 ^ e.d.a);
            }
            c2.l = n2;
            c.this.f();
        }
    };

    public c(View view, io.flutter.embedding.engine.i.a a2, final AccessibilityManager accessibilityManager, ContentResolver contentResolver, io.flutter.plugin.platform.h h2) {
        this.a = view;
        this.b = a2;
        this.c = accessibilityManager;
        this.f = contentResolver;
        this.e = h2;
        this.u.onAccessibilityStateChanged(accessibilityManager.isEnabled());
        this.c.addAccessibilityStateChangeListener(this.u);
        if (Build.VERSION.SDK_INT >= 19) {
            this.v = new AccessibilityManager.TouchExplorationStateChangeListener(){

                public void onTouchExplorationStateChanged(boolean bl) {
                    int n2;
                    c c2 = c.this;
                    if (bl) {
                        n2 = c2.l | e.b.a;
                    } else {
                        c2.e();
                        c2 = c.this;
                        n2 = c2.l & (-1 ^ e.b.a);
                    }
                    c2.l = n2;
                    c.this.f();
                    if (c.this.s != null) {
                        c.this.s.a(accessibilityManager.isEnabled(), bl);
                    }
                }
            };
            this.v.onTouchExplorationStateChanged(accessibilityManager.isTouchExplorationEnabled());
            this.c.addTouchExplorationStateChangeListener(this.v);
        } else {
            this.v = null;
        }
        if (Build.VERSION.SDK_INT >= 17) {
            this.w.onChange(false);
            Uri uri = Settings.Global.getUriFor((String)"transition_animation_scale");
            this.f.registerContentObserver(uri, false, this.w);
        }
        if (h2 != null) {
            h2.a(this);
        }
        this.d = new AccessibilityViewEmbedder(view, 65536);
    }

    private AccessibilityEvent a(int n2, int n3) {
        AccessibilityEvent accessibilityEvent = AccessibilityEvent.obtain((int)n3);
        accessibilityEvent.setPackageName((CharSequence)this.a.getContext().getPackageName());
        accessibilityEvent.setSource(this.a, n2);
        return accessibilityEvent;
    }

    private AccessibilityEvent a(int n2, String string, String string2) {
        int n3;
        int n4;
        AccessibilityEvent accessibilityEvent = this.a(n2, 16);
        accessibilityEvent.setBeforeText((CharSequence)string);
        accessibilityEvent.getText().add((Object)string2);
        for (n3 = 0; n3 < string.length() && n3 < string2.length() && string.charAt(n3) == string2.charAt(n3); ++n3) {
        }
        if (n3 >= string.length() && n3 >= string2.length()) {
            return null;
        }
        accessibilityEvent.setFromIndex(n3);
        int n5 = -1 + string.length();
        for (n4 = -1 + string2.length(); n5 >= n3 && n4 >= n3 && string.charAt(n5) == string2.charAt(n4); --n5, --n4) {
        }
        accessibilityEvent.setRemovedCount(1 + (n5 - n3));
        accessibilityEvent.setAddedCount(1 + (n4 - n3));
        return accessibilityEvent;
    }

    private g a(int n2) {
        g g2 = (g)this.h.get((Object)n2);
        if (g2 == null) {
            g2 = new g();
            g2.b = n2;
            g2.a = n2 + c.x;
            this.h.put((Object)n2, (Object)g2);
        }
        return g2;
    }

    private void a(float f2, float f3) {
        if (this.g.isEmpty()) {
            return;
        }
        j j2 = this.d().a(new float[]{f2, f3, 0.0f, 1.0f});
        if (j2 != this.o) {
            j j3;
            if (j2 != null) {
                this.b(j2.b, 128);
            }
            if ((j3 = this.o) != null) {
                this.b(j3.b, 256);
            }
            this.o = j2;
        }
    }

    private void a(AccessibilityEvent accessibilityEvent) {
        if (!this.c.isEnabled()) {
            return;
        }
        this.a.getParent().requestSendAccessibilityEvent(this.a, accessibilityEvent);
    }

    static /* synthetic */ boolean a(j j2) {
        return j2.b(h.t);
    }

    /*
     * Enabled aggressive block sorting
     */
    @TargetApi(value=18)
    private boolean a(j j2, int n2, Bundle bundle, boolean bl) {
        io.flutter.embedding.engine.i.a a2;
        f f2;
        int n3 = bundle.getInt("ACTION_ARGUMENT_MOVEMENT_GRANULARITY_INT");
        boolean bl2 = bundle.getBoolean("ACTION_ARGUMENT_EXTEND_SELECTION_BOOLEAN");
        if (n3 != 1) {
            if (n3 != 2) {
                return false;
            }
            if (bl && j2.b(f.u)) {
                a2 = this.b;
                f2 = f.u;
            } else {
                if (bl) return false;
                if (!j2.b(f.v)) return false;
                a2 = this.b;
                f2 = f.v;
            }
        } else if (bl && j2.b(f.k)) {
            a2 = this.b;
            f2 = f.k;
        } else {
            if (bl) return false;
            if (!j2.b(f.l)) return false;
            a2 = this.b;
            f2 = f.l;
        }
        a2.a(n2, f2, bl2);
        return true;
    }

    static /* synthetic */ boolean a(j j2, j j3) {
        return j3 == j2;
    }

    private j b(int n2) {
        j j2 = (j)this.g.get((Object)n2);
        if (j2 == null) {
            j2 = new j(this);
            j2.b = n2;
            this.g.put((Object)n2, (Object)j2);
        }
        return j2;
    }

    private void b(int n2, int n3) {
        if (!this.c.isEnabled()) {
            return;
        }
        if (n2 == 0) {
            this.a.sendAccessibilityEvent(n3);
            return;
        }
        this.a(this.a(n2, n3));
    }

    private void b(j j2) {
        AccessibilityEvent accessibilityEvent = this.a(j2.b, 32);
        String string = j2.e();
        accessibilityEvent.getText().add((Object)string);
        this.a(accessibilityEvent);
    }

    private void c(int n2) {
        AccessibilityEvent accessibilityEvent = this.a(n2, 2048);
        if (Build.VERSION.SDK_INT >= 19) {
            accessibilityEvent.setContentChangeTypes(1);
        }
        this.a(accessibilityEvent);
    }

    private boolean c(j j2) {
        return j2.j > 0 && (j.b(this.i, new io.flutter.view.a(j2)) || !j.b(this.i, io.flutter.view.b.a));
    }

    private j d() {
        return (j)this.g.get((Object)0);
    }

    private void d(j j2) {
        j2.G = null;
        j j3 = this.i;
        if (j3 == j2) {
            this.b(j3.b, 65536);
            this.i = null;
        }
        if (this.m == j2) {
            this.m = null;
        }
        if (this.o == j2) {
            this.o = null;
        }
    }

    private void e() {
        j j2 = this.o;
        if (j2 != null) {
            this.b(j2.b, 256);
            this.o = null;
        }
    }

    private void f() {
        this.b.a(this.l);
    }

    public void a(i i2) {
        this.s = i2;
    }

    void a(ByteBuffer byteBuffer, String[] arrstring) {
        while (byteBuffer.hasRemaining()) {
            g g2 = this.a(byteBuffer.getInt());
            g2.c = byteBuffer.getInt();
            int n2 = byteBuffer.getInt();
            String string = n2 == -1 ? null : arrstring[n2];
            g2.d = string;
            int n3 = byteBuffer.getInt();
            String string2 = n3 == -1 ? null : arrstring[n3];
            g2.e = string2;
        }
    }

    public boolean a() {
        return this.c.isEnabled();
    }

    public boolean a(MotionEvent motionEvent) {
        if (!this.c.isTouchExplorationEnabled()) {
            return false;
        }
        if (this.g.isEmpty()) {
            return false;
        }
        j j2 = this.d();
        float[] arrf = new float[]{motionEvent.getX(), motionEvent.getY(), 0.0f, 1.0f};
        j j3 = j2.a(arrf);
        if (j3.i != -1) {
            return this.d.onAccessibilityHoverEvent(j3.b, motionEvent);
        }
        if (motionEvent.getAction() != 9 && motionEvent.getAction() != 7) {
            if (motionEvent.getAction() == 10) {
                this.e();
                return true;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("unexpected accessibility hover event: ");
            stringBuilder.append((Object)motionEvent);
            Log.d((String)"flutter", (String)stringBuilder.toString());
            return false;
        }
        this.a(motionEvent.getX(), motionEvent.getY());
        return true;
    }

    public boolean a(View view, View view2, AccessibilityEvent accessibilityEvent) {
        if (!this.d.requestSendAccessibilityEvent(view, view2, accessibilityEvent)) {
            return false;
        }
        Integer n2 = this.d.getRecordFlutterId(view, (AccessibilityRecord)accessibilityEvent);
        if (n2 == null) {
            return false;
        }
        int n3 = accessibilityEvent.getEventType();
        if (n3 != 8) {
            if (n3 != 128) {
                if (n3 != 32768) {
                    if (n3 == 65536) {
                        this.k = null;
                        this.j = null;
                    }
                } else {
                    this.j = n2;
                    this.i = null;
                }
            } else {
                this.o = null;
            }
        } else {
            this.k = n2;
            this.m = null;
        }
        return true;
    }

    void b(ByteBuffer byteBuffer, String[] arrstring) {
        ArrayList arrayList = new ArrayList();
        while (byteBuffer.hasRemaining()) {
            j j2 = this.b(byteBuffer.getInt());
            j2.a(byteBuffer, arrstring);
            if (j2.b(h.o)) continue;
            if (j2.b(h.g)) {
                this.m = j2;
            }
            if (!j2.t) continue;
            arrayList.add((Object)j2);
        }
        HashSet hashSet = new HashSet();
        j j3 = this.d();
        ArrayList arrayList2 = new ArrayList();
        if (j3 != null) {
            WindowInsets windowInsets;
            float[] arrf = new float[16];
            Matrix.setIdentityM((float[])arrf, (int)0);
            if (Build.VERSION.SDK_INT >= 23 && (windowInsets = this.a.getRootWindowInsets()) != null) {
                if (!this.r.equals((Object)windowInsets.getSystemWindowInsetLeft())) {
                    j3.O = true;
                    j3.M = true;
                }
                this.r = windowInsets.getSystemWindowInsetLeft();
                Matrix.translateM((float[])arrf, (int)0, (float)this.r.intValue(), (float)0.0f, (float)0.0f);
            }
            j3.a(arrf, (Set<j>)((Set)hashSet), false);
            j3.a((List<j>)((List)arrayList2));
        }
        Iterator iterator = arrayList2.iterator();
        j j4 = null;
        while (iterator.hasNext()) {
            j j5 = (j)iterator.next();
            if (this.p.contains((Object)j5.b)) continue;
            j4 = j5;
        }
        if (j4 == null && arrayList2.size() > 0) {
            j4 = (j)arrayList2.get(arrayList2.size() - 1);
        }
        if (j4 != null && j4.b != this.q) {
            this.q = j4.b;
            this.b(j4);
        }
        this.p.clear();
        for (j j6 : arrayList2) {
            this.p.add((Object)j6.b);
        }
        Iterator iterator2 = this.g.entrySet().iterator();
        while (iterator2.hasNext()) {
            j j7 = (j)((Map.Entry)iterator2.next()).getValue();
            if (hashSet.contains((Object)j7)) continue;
            this.d(j7);
            iterator2.remove();
        }
        this.c(0);
        for (j j8 : arrayList) {
            j j9;
            j j10;
            String string;
            j j11;
            String string2;
            j j12;
            j j13;
            j j14;
            AccessibilityEvent accessibilityEvent;
            if (j8.b()) {
                float f2;
                float f3;
                AccessibilityEvent accessibilityEvent2 = this.a(j8.b, 4096);
                float f4 = j8.l;
                float f5 = j8.m;
                if (Float.isInfinite((float)j8.m)) {
                    if (f4 > 70000.0f) {
                        f4 = 70000.0f;
                    }
                    f5 = 100000.0f;
                }
                if (Float.isInfinite((float)j8.n)) {
                    f2 = f5 + 100000.0f;
                    if (f4 < -70000.0f) {
                        f4 = -70000.0f;
                    }
                    f3 = f4 + 100000.0f;
                } else {
                    f2 = f5 - j8.n;
                    f3 = f4 - j8.n;
                }
                if (!j8.a(f.f) && !j8.a(f.g)) {
                    if (j8.a(f.d) || j8.a(f.e)) {
                        accessibilityEvent2.setScrollX((int)f3);
                        accessibilityEvent2.setMaxScrollX((int)f2);
                    }
                } else {
                    accessibilityEvent2.setScrollY((int)f3);
                    accessibilityEvent2.setMaxScrollY((int)f2);
                }
                if (j8.j > 0) {
                    accessibilityEvent2.setItemCount(j8.j);
                    accessibilityEvent2.setFromIndex(j8.k);
                    Iterator iterator3 = j8.I.iterator();
                    int n2 = 0;
                    while (iterator3.hasNext()) {
                        if (((j)iterator3.next()).b(h.o)) continue;
                        ++n2;
                    }
                    accessibilityEvent2.setToIndex(n2 + j8.k - 1);
                }
                this.a(accessibilityEvent2);
            }
            boolean bl = j8.b(h.q);
            String string3 = "";
            if (bl ? !(string = j8.o == null ? string3 : j8.o).equals((Object)(string2 = j8.A == null ? string3 : j8.o)) || !j8.a(h.q) : j8.b(h.f) && j8.a() && (j12 = this.m) != null && j12.b == j8.b) {
                this.c(j8.b);
            }
            if ((j11 = this.i) != null && j11.b == j8.b && !j8.a(h.d) && j8.b(h.d)) {
                AccessibilityEvent accessibilityEvent3 = this.a(j8.b, 4);
                accessibilityEvent3.getText().add((Object)j8.o);
                this.a(accessibilityEvent3);
            }
            if ((j10 = this.m) != null && j10.b == j8.b && ((j14 = this.n) == null || j14.b != this.m.b)) {
                this.n = this.m;
                this.a(this.a(j8.b, 8));
            } else if (this.m == null) {
                this.n = null;
            }
            if ((j9 = this.m) == null || j9.b != j8.b || !j8.a(h.f) || !j8.b(h.f) || (j13 = this.i) != null && j13.b != this.m.b) continue;
            String string4 = j8.z != null ? j8.z : string3;
            if (j8.p != null) {
                string3 = j8.p;
            }
            if ((accessibilityEvent = this.a(j8.b, string4, string3)) != null) {
                this.a(accessibilityEvent);
            }
            if (j8.w == j8.g && j8.x == j8.h) continue;
            AccessibilityEvent accessibilityEvent4 = this.a(j8.b, 8192);
            accessibilityEvent4.getText().add((Object)string3);
            accessibilityEvent4.setFromIndex(j8.g);
            accessibilityEvent4.setToIndex(j8.h);
            accessibilityEvent4.setItemCount(string3.length());
            this.a(accessibilityEvent4);
        }
    }

    public boolean b() {
        return this.c.isTouchExplorationEnabled();
    }

    public void c() {
        io.flutter.plugin.platform.h h2 = this.e;
        if (h2 != null) {
            h2.a();
        }
        this.a((i)null);
        this.c.removeAccessibilityStateChangeListener(this.u);
        if (Build.VERSION.SDK_INT >= 19) {
            this.c.removeTouchExplorationStateChangeListener(this.v);
        }
        this.f.unregisterContentObserver(this.w);
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    @SuppressLint(value={"NewApi"})
    public AccessibilityNodeInfo createAccessibilityNodeInfo(int var1_1) {
        block61 : {
            block60 : {
                block56 : {
                    block57 : {
                        block58 : {
                            block59 : {
                                if (var1_1 >= 65536) {
                                    return this.d.createAccessibilityNodeInfo(var1_1);
                                }
                                if (var1_1 == -1) {
                                    var31_2 = AccessibilityNodeInfo.obtain((View)this.a);
                                    this.a.onInitializeAccessibilityNodeInfo(var31_2);
                                    if (this.g.containsKey((Object)0) == false) return var31_2;
                                    var31_2.addChild(this.a, 0);
                                    return var31_2;
                                }
                                var2_3 = (j)this.g.get((Object)var1_1);
                                if (var2_3 == null) {
                                    return null;
                                }
                                if (j.b(var2_3) != -1) {
                                    var29_4 = this.e.a(j.b(var2_3));
                                    var30_5 = j.c(var2_3);
                                    return this.d.getRootNode(var29_4, j.d(var2_3), var30_5);
                                }
                                var3_6 = AccessibilityNodeInfo.obtain((View)this.a, (int)var1_1);
                                if (Build.VERSION.SDK_INT >= 18) {
                                    var3_6.setViewIdResourceName("");
                                }
                                var3_6.setPackageName((CharSequence)this.a.getContext().getPackageName());
                                var3_6.setClassName((CharSequence)"android.view.View");
                                var3_6.setSource(this.a, var1_1);
                                var3_6.setFocusable(j.e(var2_3));
                                var4_7 = this.m;
                                if (var4_7 != null) {
                                    var28_8 = j.d(var4_7) == var1_1;
                                    var3_6.setFocused(var28_8);
                                }
                                if ((var5_9 = this.i) != null) {
                                    var27_10 = j.d(var5_9) == var1_1;
                                    var3_6.setAccessibilityFocused(var27_10);
                                }
                                if (j.a(var2_3, h.f)) {
                                    var3_6.setPassword(j.a(var2_3, h.l));
                                    if (!j.a(var2_3, h.u)) {
                                        var3_6.setClassName((CharSequence)"android.widget.EditText");
                                    }
                                    if (Build.VERSION.SDK_INT >= 18) {
                                        var3_6.setEditable(true ^ j.a(var2_3, h.u));
                                        if (j.f(var2_3) != -1 && j.g(var2_3) != -1) {
                                            var3_6.setTextSelection(j.f(var2_3), j.g(var2_3));
                                        }
                                        if (Build.VERSION.SDK_INT > 18 && (var26_11 = this.i) != null && j.d(var26_11) == var1_1) {
                                            var3_6.setLiveRegion(1);
                                        }
                                    }
                                    if (j.a(var2_3, f.k)) {
                                        var3_6.addAction(256);
                                        var22_12 = 1;
                                    } else {
                                        var22_12 = 0;
                                    }
                                    if (j.a(var2_3, f.l)) {
                                        var3_6.addAction(512);
                                        var22_12 |= true;
                                    }
                                    if (j.a(var2_3, f.u)) {
                                        var3_6.addAction(256);
                                        var22_12 |= 2;
                                    }
                                    if (j.a(var2_3, f.v)) {
                                        var3_6.addAction(512);
                                        var22_12 |= 2;
                                    }
                                    var3_6.setMovementGranularities(var22_12);
                                    if (Build.VERSION.SDK_INT >= 21 && j.h(var2_3) >= 0) {
                                        var23_13 = j.i(var2_3) == null ? 0 : j.i(var2_3).length();
                                        j.j(var2_3);
                                        j.h(var2_3);
                                        var3_6.setMaxTextLength(var23_13 - j.j(var2_3) + j.h(var2_3));
                                    }
                                }
                                if (Build.VERSION.SDK_INT > 18) {
                                    if (j.a(var2_3, f.m)) {
                                        var3_6.addAction(131072);
                                    }
                                    if (j.a(var2_3, f.n)) {
                                        var3_6.addAction(16384);
                                    }
                                    if (j.a(var2_3, f.o)) {
                                        var3_6.addAction(65536);
                                    }
                                    if (j.a(var2_3, f.p)) {
                                        var3_6.addAction(32768);
                                    }
                                }
                                if (j.a(var2_3, h.e) || j.a(var2_3, h.w)) {
                                    var3_6.setClassName((CharSequence)"android.widget.Button");
                                }
                                if (j.a(var2_3, h.p)) {
                                    var3_6.setClassName((CharSequence)"android.widget.ImageView");
                                }
                                if (Build.VERSION.SDK_INT > 18 && j.a(var2_3, f.t)) {
                                    var3_6.setDismissable(true);
                                    var3_6.addAction(1048576);
                                }
                                if (j.k(var2_3) != null) {
                                    var3_6.setParent(this.a, j.d(j.k(var2_3)));
                                } else {
                                    var3_6.setParent(this.a);
                                }
                                var6_14 = j.c(var2_3);
                                if (j.k(var2_3) != null) {
                                    var20_15 = j.c(j.k(var2_3));
                                    var21_16 = new Rect(var6_14);
                                    var21_16.offset(-var20_15.left, -var20_15.top);
                                    var3_6.setBoundsInParent(var21_16);
                                } else {
                                    var3_6.setBoundsInParent(var6_14);
                                }
                                var3_6.setBoundsInScreen(var6_14);
                                var3_6.setVisibleToUser(true);
                                var7_17 = !j.a(var2_3, h.h) || j.a(var2_3, h.i);
                                var3_6.setEnabled(var7_17);
                                if (j.a(var2_3, f.b)) {
                                    if (Build.VERSION.SDK_INT >= 21 && j.l(var2_3) != null) {
                                        var3_6.addAction(new AccessibilityNodeInfo.AccessibilityAction(16, (CharSequence)g.a(j.l(var2_3))));
                                    } else {
                                        var3_6.addAction(16);
                                    }
                                    var3_6.setClickable(true);
                                }
                                if (j.a(var2_3, f.c)) {
                                    if (Build.VERSION.SDK_INT >= 21 && j.m(var2_3) != null) {
                                        var3_6.addAction(new AccessibilityNodeInfo.AccessibilityAction(32, (CharSequence)g.a(j.m(var2_3))));
                                    } else {
                                        var3_6.addAction(32);
                                    }
                                    var3_6.setLongClickable(true);
                                }
                                if (!j.a(var2_3, f.d) && !j.a(var2_3, f.f) && !j.a(var2_3, f.e) && !j.a(var2_3, f.g)) break block56;
                                var3_6.setScrollable(true);
                                if (!j.a(var2_3, h.t)) break block57;
                                if (j.a(var2_3, f.d) || j.a(var2_3, f.e)) break block58;
                                if (Build.VERSION.SDK_INT <= 18 || !this.c(var2_3)) break block59;
                                var19_18 = AccessibilityNodeInfo.CollectionInfo.obtain((int)j.a(var2_3), (int)0, (boolean)false);
                                ** GOTO lbl117
                            }
                            var18_19 = "android.widget.ScrollView";
                            ** GOTO lbl120
                        }
                        if (Build.VERSION.SDK_INT > 19 && this.c(var2_3)) {
                            var19_18 = AccessibilityNodeInfo.CollectionInfo.obtain((int)0, (int)j.a(var2_3), (boolean)false);
lbl117: // 2 sources:
                            var3_6.setCollectionInfo(var19_18);
                        } else {
                            var18_19 = "android.widget.HorizontalScrollView";
lbl120: // 2 sources:
                            var3_6.setClassName((CharSequence)var18_19);
                        }
                    }
                    if (j.a(var2_3, f.d) || j.a(var2_3, f.f)) {
                        var3_6.addAction(4096);
                    }
                    if (j.a(var2_3, f.e) || j.a(var2_3, f.g)) {
                        var3_6.addAction(8192);
                    }
                }
                if (j.a(var2_3, f.h) || j.a(var2_3, f.i)) {
                    var3_6.setClassName((CharSequence)"android.widget.SeekBar");
                    if (j.a(var2_3, f.h)) {
                        var3_6.addAction(4096);
                    }
                    if (j.a(var2_3, f.i)) {
                        var3_6.addAction(8192);
                    }
                }
                if (j.a(var2_3, h.q) && Build.VERSION.SDK_INT > 18) {
                    var3_6.setLiveRegion(1);
                }
                var8_20 = j.a(var2_3, h.b);
                var9_21 = j.a(var2_3, h.r);
                if (var8_20) break block60;
                var10_22 = false;
                if (!var9_21) break block61;
            }
            var10_22 = true;
        }
        var3_6.setCheckable(var10_22);
        if (var8_20) {
            var3_6.setChecked(j.a(var2_3, h.c));
            var3_6.setContentDescription((CharSequence)j.n(var2_3));
            var17_23 = j.a(var2_3, h.j) != false ? "android.widget.RadioButton" : "android.widget.CheckBox";
            var3_6.setClassName((CharSequence)var17_23);
        } else if (var9_21) {
            var3_6.setChecked(j.a(var2_3, h.s));
            var3_6.setClassName((CharSequence)"android.widget.Switch");
            var3_6.setContentDescription((CharSequence)j.n(var2_3));
        } else if (!j.a(var2_3, h.m)) {
            var3_6.setText((CharSequence)j.n(var2_3));
        }
        var3_6.setSelected(j.a(var2_3, h.d));
        if (Build.VERSION.SDK_INT >= 28) {
            var3_6.setHeading(j.a(var2_3, h.k));
        }
        var12_25 = (var11_24 = this.i) != null && j.d(var11_24) == var1_1 ? 128 : 64;
        var3_6.addAction(var12_25);
        if (Build.VERSION.SDK_INT >= 21 && j.o(var2_3) != null) {
            for (g var16_27 : j.o(var2_3)) {
                var3_6.addAction(new AccessibilityNodeInfo.AccessibilityAction(g.b(var16_27), (CharSequence)g.c(var16_27)));
            }
        }
        var13_28 = j.p(var2_3).iterator();
        while (var13_28.hasNext() != false) {
            var14_29 = (j)var13_28.next();
            if (j.a(var14_29, h.o)) continue;
            var3_6.addChild(this.a, j.d(var14_29));
        }
        return var3_6;
    }

    /*
     * Enabled aggressive block sorting
     */
    public AccessibilityNodeInfo findFocus(int n2) {
        Integer n3;
        int n4;
        block8 : {
            block9 : {
                j j2;
                block7 : {
                    block6 : {
                        block5 : {
                            if (n2 == 1) break block5;
                            if (n2 != 2) {
                                return null;
                            }
                            break block6;
                        }
                        j2 = this.m;
                        if (j2 != null) break block7;
                        n3 = this.k;
                        if (n3 != null) break block8;
                    }
                    if ((j2 = this.i) == null) break block9;
                }
                n4 = j2.b;
                return this.createAccessibilityNodeInfo(n4);
            }
            n3 = this.j;
            if (n3 == null) return null;
        }
        n4 = n3;
        return this.createAccessibilityNodeInfo(n4);
    }

    /*
     * Enabled aggressive block sorting
     */
    public boolean performAction(int n2, int n3, Bundle bundle) {
        if (n2 >= 65536) {
            boolean bl = this.d.performAction(n2, n3, bundle);
            if (bl && n3 == 128) {
                this.j = null;
            }
            return bl;
        }
        j j2 = (j)this.g.get((Object)n2);
        if (j2 == null) {
            return false;
        }
        switch (n3) {
            default: {
                int n4 = n3 - x;
                g g2 = (g)this.h.get((Object)n4);
                if (g2 == null) break;
                this.b.a(n2, f.s, g2.b);
                return true;
            }
            case 16908342: {
                this.b.a(n2, f.j);
                return true;
            }
            case 1048576: {
                this.b.a(n2, f.t);
                return true;
            }
            case 131072: {
                int n5;
                if (Build.VERSION.SDK_INT < 18) {
                    return false;
                }
                HashMap hashMap = new HashMap();
                boolean bl = false;
                if (bundle != null) {
                    boolean bl2 = bundle.containsKey("ACTION_ARGUMENT_SELECTION_START_INT");
                    bl = false;
                    if (bl2) {
                        boolean bl3 = bundle.containsKey("ACTION_ARGUMENT_SELECTION_END_INT");
                        bl = false;
                        if (bl3) {
                            bl = true;
                        }
                    }
                }
                if (bl) {
                    hashMap.put((Object)"base", (Object)bundle.getInt("ACTION_ARGUMENT_SELECTION_START_INT"));
                    n5 = bundle.getInt("ACTION_ARGUMENT_SELECTION_END_INT");
                } else {
                    hashMap.put((Object)"base", (Object)j2.h);
                    n5 = j2.h;
                }
                hashMap.put((Object)"extent", (Object)n5);
                this.b.a(n2, f.m, (Object)hashMap);
                return true;
            }
            case 65536: {
                this.b.a(n2, f.o);
                return true;
            }
            case 32768: {
                this.b.a(n2, f.p);
                return true;
            }
            case 16384: {
                this.b.a(n2, f.n);
                return true;
            }
            case 8192: {
                f f2;
                io.flutter.embedding.engine.i.a a2;
                if (j2.b(f.g)) {
                    a2 = this.b;
                    f2 = f.g;
                } else if (j2.b(f.e)) {
                    a2 = this.b;
                    f2 = f.e;
                } else {
                    if (!j2.b(f.i)) {
                        return false;
                    }
                    j2.p = j2.r;
                    this.b(n2, 4);
                    a2 = this.b;
                    f2 = f.i;
                }
                a2.a(n2, f2);
                return true;
            }
            case 4096: {
                f f3;
                io.flutter.embedding.engine.i.a a3;
                if (j2.b(f.f)) {
                    a3 = this.b;
                    f3 = f.f;
                } else if (j2.b(f.d)) {
                    a3 = this.b;
                    f3 = f.d;
                } else {
                    if (!j2.b(f.h)) {
                        return false;
                    }
                    j2.p = j2.q;
                    this.b(n2, 4);
                    a3 = this.b;
                    f3 = f.h;
                }
                a3.a(n2, f3);
                return true;
            }
            case 512: {
                if (Build.VERSION.SDK_INT < 18) {
                    return false;
                }
                return this.a(j2, n2, bundle, false);
            }
            case 256: {
                if (Build.VERSION.SDK_INT < 18) {
                    return false;
                }
                return this.a(j2, n2, bundle, true);
            }
            case 128: {
                this.b.a(n2, f.r);
                this.b(n2, 65536);
                this.i = null;
                this.j = null;
                return true;
            }
            case 64: {
                this.b.a(n2, f.q);
                this.b(n2, 32768);
                if (this.i == null) {
                    this.a.invalidate();
                }
                this.i = j2;
                if (j2.b(f.h) || j2.b(f.i)) {
                    this.b(n2, 4);
                }
                return true;
            }
            case 32: {
                this.b.a(n2, f.c);
                return true;
            }
            case 16: {
                this.b.a(n2, f.b);
                return true;
            }
        }
        return false;
    }

    private static final class e
    extends Enum<e> {
        public static final /* enum */ e b = new e(1);
        public static final /* enum */ e c = new e(2);
        public static final /* enum */ e d = new e(4);
        private static final /* synthetic */ e[] e;
        final int a;

        static {
            e[] arre = new e[]{b, c, d};
            e = arre;
        }

        private e(int n3) {
            this.a = n3;
        }

        public static e valueOf(String string) {
            return (e)Enum.valueOf(e.class, (String)string);
        }

        public static e[] values() {
            return (e[])e.clone();
        }
    }

    public static final class f
    extends Enum<f> {
        public static final /* enum */ f b = new f(1);
        public static final /* enum */ f c = new f(2);
        public static final /* enum */ f d = new f(4);
        public static final /* enum */ f e = new f(8);
        public static final /* enum */ f f = new f(16);
        public static final /* enum */ f g = new f(32);
        public static final /* enum */ f h = new f(64);
        public static final /* enum */ f i = new f(128);
        public static final /* enum */ f j = new f(256);
        public static final /* enum */ f k = new f(512);
        public static final /* enum */ f l = new f(1024);
        public static final /* enum */ f m = new f(2048);
        public static final /* enum */ f n = new f(4096);
        public static final /* enum */ f o = new f(8192);
        public static final /* enum */ f p = new f(16384);
        public static final /* enum */ f q = new f(32768);
        public static final /* enum */ f r = new f(65536);
        public static final /* enum */ f s = new f(131072);
        public static final /* enum */ f t = new f(262144);
        public static final /* enum */ f u = new f(524288);
        public static final /* enum */ f v = new f(1048576);
        private static final /* synthetic */ f[] w;
        public final int a;

        static {
            f[] arrf = new f[]{b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v};
            w = arrf;
        }

        private f(int n3) {
            this.a = n3;
        }

        public static f valueOf(String string) {
            return (f)Enum.valueOf(f.class, (String)string);
        }

        public static f[] values() {
            return (f[])w.clone();
        }
    }

    private static class g {
        private int a = -1;
        private int b = -1;
        private int c = -1;
        private String d;
        private String e;

        g() {
        }

        static /* synthetic */ String a(g g2) {
            return g2.e;
        }

        static /* synthetic */ int b(g g2) {
            return g2.a;
        }

        static /* synthetic */ String c(g g2) {
            return g2.d;
        }
    }

    private static final class h
    extends Enum<h> {
        public static final /* enum */ h b = new h(1);
        public static final /* enum */ h c = new h(2);
        public static final /* enum */ h d = new h(4);
        public static final /* enum */ h e = new h(8);
        public static final /* enum */ h f = new h(16);
        public static final /* enum */ h g = new h(32);
        public static final /* enum */ h h = new h(64);
        public static final /* enum */ h i = new h(128);
        public static final /* enum */ h j = new h(256);
        public static final /* enum */ h k = new h(512);
        public static final /* enum */ h l = new h(1024);
        public static final /* enum */ h m = new h(2048);
        public static final /* enum */ h n = new h(4096);
        public static final /* enum */ h o = new h(8192);
        public static final /* enum */ h p = new h(16384);
        public static final /* enum */ h q = new h(32768);
        public static final /* enum */ h r = new h(65536);
        public static final /* enum */ h s = new h(131072);
        public static final /* enum */ h t = new h(262144);
        public static final /* enum */ h u = new h(1048576);
        public static final /* enum */ h v = new h(2097152);
        public static final /* enum */ h w = new h(4194304);
        private static final /* synthetic */ h[] x;
        final int a;

        static {
            h[] arrh = new h[]{b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w};
            x = arrh;
        }

        private h(int n3) {
            this.a = n3;
        }

        public static h valueOf(String string) {
            return (h)Enum.valueOf(h.class, (String)string);
        }

        public static h[] values() {
            return (h[])x.clone();
        }
    }

    public static interface i {
        public void a(boolean var1, boolean var2);
    }

    private static class j {
        private String A;
        private float B;
        private float C;
        private float D;
        private float E;
        private float[] F;
        private j G;
        private List<j> H = new ArrayList();
        private List<j> I = new ArrayList();
        private List<g> J;
        private g K;
        private g L;
        private boolean M = true;
        private float[] N;
        private boolean O = true;
        private float[] P;
        private Rect Q;
        final c a;
        private int b = -1;
        private int c;
        private int d;
        private int e;
        private int f;
        private int g;
        private int h;
        private int i;
        private int j;
        private int k;
        private float l;
        private float m;
        private float n;
        private String o;
        private String p;
        private String q;
        private String r;
        private String s;
        private boolean t = false;
        private int u;
        private int v;
        private int w;
        private int x;
        private float y;
        private String z;

        j(c c2) {
            this.a = c2;
        }

        private float a(float f2, float f3, float f4, float f5) {
            return Math.max((float)f2, (float)Math.max((float)f3, (float)Math.max((float)f4, (float)f5)));
        }

        private j a(b.a.d.b<j> b2) {
            j j2 = this.G;
            while (j2 != null) {
                if (b2.a(j2)) {
                    return j2;
                }
                j2 = j2.G;
            }
            return null;
        }

        private j a(float[] arrf) {
            float f2 = arrf[3];
            float f3 = arrf[0] / f2;
            float f4 = arrf[1] / f2;
            if (!(f3 < this.B || f3 >= this.D || f4 < this.C || f4 >= this.E)) {
                float[] arrf2 = new float[4];
                for (j j2 : this.I) {
                    if (j2.b(h.o)) continue;
                    j2.c();
                    Matrix.multiplyMV((float[])arrf2, (int)0, (float[])j2.N, (int)0, (float[])arrf, (int)0);
                    j j3 = j2.a(arrf2);
                    if (j3 == null) continue;
                    return j3;
                }
                return this;
            }
            return null;
        }

        private void a(ByteBuffer byteBuffer, String[] arrstring) {
            this.t = true;
            this.z = this.p;
            this.A = this.o;
            this.u = this.c;
            this.v = this.d;
            this.w = this.g;
            this.x = this.h;
            this.y = this.l;
            this.c = byteBuffer.getInt();
            this.d = byteBuffer.getInt();
            this.e = byteBuffer.getInt();
            this.f = byteBuffer.getInt();
            this.g = byteBuffer.getInt();
            this.h = byteBuffer.getInt();
            this.i = byteBuffer.getInt();
            this.j = byteBuffer.getInt();
            this.k = byteBuffer.getInt();
            this.l = byteBuffer.getFloat();
            this.m = byteBuffer.getFloat();
            this.n = byteBuffer.getFloat();
            int n2 = byteBuffer.getInt();
            String string = n2 == -1 ? null : arrstring[n2];
            this.o = string;
            int n3 = byteBuffer.getInt();
            String string2 = n3 == -1 ? null : arrstring[n3];
            this.p = string2;
            int n4 = byteBuffer.getInt();
            String string3 = n4 == -1 ? null : arrstring[n4];
            this.q = string3;
            int n5 = byteBuffer.getInt();
            String string4 = n5 == -1 ? null : arrstring[n5];
            this.r = string4;
            int n6 = byteBuffer.getInt();
            String string5 = n6 == -1 ? null : arrstring[n6];
            this.s = string5;
            k.a(byteBuffer.getInt());
            this.B = byteBuffer.getFloat();
            this.C = byteBuffer.getFloat();
            this.D = byteBuffer.getFloat();
            this.E = byteBuffer.getFloat();
            if (this.F == null) {
                this.F = new float[16];
            }
            int n7 = 0;
            for (int i2 = 0; i2 < 16; ++i2) {
                this.F[i2] = byteBuffer.getFloat();
            }
            this.M = true;
            this.O = true;
            int n8 = byteBuffer.getInt();
            this.H.clear();
            this.I.clear();
            for (int i3 = 0; i3 < n8; ++i3) {
                j j2 = this.a.b(byteBuffer.getInt());
                j2.G = this;
                this.H.add((Object)j2);
            }
            for (int i4 = 0; i4 < n8; ++i4) {
                j j3 = this.a.b(byteBuffer.getInt());
                j3.G = this;
                this.I.add((Object)j3);
            }
            int n9 = byteBuffer.getInt();
            if (n9 == 0) {
                this.J = null;
                return;
            }
            List<g> list = this.J;
            if (list == null) {
                this.J = new ArrayList(n9);
                n7 = 0;
            } else {
                list.clear();
            }
            while (n7 < n9) {
                g g2 = this.a.a(byteBuffer.getInt());
                if (g2.c == f.b.a) {
                    this.K = g2;
                } else if (g2.c == f.c.a) {
                    this.L = g2;
                } else {
                    this.J.add((Object)g2);
                }
                this.J.add((Object)g2);
                ++n7;
            }
        }

        private void a(List<j> list) {
            if (this.b(h.m)) {
                list.add((Object)this);
            }
            Iterator iterator = this.H.iterator();
            while (iterator.hasNext()) {
                ((j)iterator.next()).a(list);
            }
        }

        private void a(float[] arrf, Set<j> set, boolean bl) {
            set.add((Object)this);
            if (this.O) {
                bl = true;
            }
            if (bl) {
                if (this.P == null) {
                    this.P = new float[16];
                }
                Matrix.multiplyMM((float[])this.P, (int)0, (float[])arrf, (int)0, (float[])this.F, (int)0);
                float[] arrf2 = new float[4];
                arrf2[2] = 0.0f;
                arrf2[3] = 1.0f;
                float[] arrf3 = new float[4];
                float[] arrf4 = new float[4];
                float[] arrf5 = new float[4];
                float[] arrf6 = new float[4];
                arrf2[0] = this.B;
                arrf2[1] = this.C;
                this.a(arrf3, this.P, arrf2);
                arrf2[0] = this.D;
                arrf2[1] = this.C;
                this.a(arrf4, this.P, arrf2);
                arrf2[0] = this.D;
                arrf2[1] = this.E;
                this.a(arrf5, this.P, arrf2);
                arrf2[0] = this.B;
                arrf2[1] = this.E;
                this.a(arrf6, this.P, arrf2);
                if (this.Q == null) {
                    this.Q = new Rect();
                }
                this.Q.set(Math.round((float)this.b(arrf3[0], arrf4[0], arrf5[0], arrf6[0])), Math.round((float)this.b(arrf3[1], arrf4[1], arrf5[1], arrf6[1])), Math.round((float)this.a(arrf3[0], arrf4[0], arrf5[0], arrf6[0])), Math.round((float)this.a(arrf3[1], arrf4[1], arrf5[1], arrf6[1])));
                this.O = false;
            }
            Iterator iterator = this.H.iterator();
            while (iterator.hasNext()) {
                ((j)iterator.next()).a(this.P, set, bl);
            }
        }

        private void a(float[] arrf, float[] arrf2, float[] arrf3) {
            Matrix.multiplyMV((float[])arrf, (int)0, (float[])arrf2, (int)0, (float[])arrf3, (int)0);
            float f2 = arrf[3];
            arrf[0] = arrf[0] / f2;
            arrf[1] = arrf[1] / f2;
            arrf[2] = arrf[2] / f2;
            arrf[3] = 0.0f;
        }

        private boolean a() {
            boolean bl;
            block5 : {
                block4 : {
                    String string;
                    if (this.o == null && this.A == null) {
                        return false;
                    }
                    String string2 = this.o;
                    if (string2 == null || (string = this.A) == null) break block4;
                    boolean bl2 = string2.equals((Object)string);
                    bl = false;
                    if (bl2) break block5;
                }
                bl = true;
            }
            return bl;
        }

        private boolean a(f f2) {
            return (this.v & f2.a) != 0;
        }

        private boolean a(h h2) {
            return (this.u & h2.a) != 0;
        }

        private float b(float f2, float f3, float f4, float f5) {
            return Math.min((float)f2, (float)Math.min((float)f3, (float)Math.min((float)f4, (float)f5)));
        }

        private boolean b() {
            return !Float.isNaN((float)this.l) && !Float.isNaN((float)this.y) && this.y != this.l;
        }

        private boolean b(f f2) {
            return (this.d & f2.a) != 0;
        }

        private boolean b(h h2) {
            return (this.c & h2.a) != 0;
        }

        private static boolean b(j j2, b.a.d.b<j> b2) {
            return j2 != null && j2.a(b2) != null;
        }

        static /* synthetic */ Rect c(j j2) {
            return j2.d();
        }

        private void c() {
            if (!this.M) {
                return;
            }
            this.M = false;
            if (this.N == null) {
                this.N = new float[16];
            }
            if (!Matrix.invertM((float[])this.N, (int)0, (float[])this.F, (int)0)) {
                Arrays.fill((float[])this.N, (float)0.0f);
            }
        }

        private Rect d() {
            return this.Q;
        }

        private String e() {
            String string;
            if (this.b(h.n) && (string = this.o) != null && !string.isEmpty()) {
                return this.o;
            }
            Iterator iterator = this.H.iterator();
            while (iterator.hasNext()) {
                String string2 = ((j)iterator.next()).e();
                if (string2 == null || string2.isEmpty()) continue;
                return string2;
            }
            return null;
        }

        static /* synthetic */ boolean e(j j2) {
            return j2.g();
        }

        private String f() {
            StringBuilder stringBuilder = new StringBuilder();
            String[] arrstring = new String[3];
            String string = this.p;
            arrstring[0] = string;
            arrstring[1] = this.o;
            arrstring[2] = this.s;
            for (String string2 : arrstring) {
                if (string2 == null || string2.length() <= 0) continue;
                if (stringBuilder.length() > 0) {
                    stringBuilder.append(", ");
                }
                stringBuilder.append(string2);
            }
            if (stringBuilder.length() > 0) {
                return stringBuilder.toString();
            }
            return null;
        }

        private boolean g() {
            boolean bl;
            block6 : {
                block5 : {
                    String string;
                    String string2;
                    if (this.b(h.m)) {
                        return false;
                    }
                    if (this.b(h.v)) {
                        return true;
                    }
                    int n2 = f.e.a | f.d.a | f.f.a | f.g.a;
                    if ((this.d & ~n2) != 0 || this.c != 0 || (string2 = this.o) != null && !string2.isEmpty() || (string = this.p) != null && !string.isEmpty()) break block5;
                    String string3 = this.s;
                    bl = false;
                    if (string3 == null) break block6;
                    boolean bl2 = string3.isEmpty();
                    bl = false;
                    if (bl2) break block6;
                }
                bl = true;
            }
            return bl;
        }

        static /* synthetic */ int h(j j2) {
            return j2.e;
        }

        static /* synthetic */ int j(j j2) {
            return j2.f;
        }

        static /* synthetic */ j k(j j2) {
            return j2.G;
        }

        static /* synthetic */ g l(j j2) {
            return j2.K;
        }

        static /* synthetic */ g m(j j2) {
            return j2.L;
        }

        static /* synthetic */ String n(j j2) {
            return j2.f();
        }

        static /* synthetic */ List o(j j2) {
            return j2.J;
        }

        static /* synthetic */ List p(j j2) {
            return j2.H;
        }
    }

    private static final class k
    extends Enum<k> {
        public static final /* enum */ k a = new k();
        public static final /* enum */ k b = new k();
        public static final /* enum */ k c = new k();
        private static final /* synthetic */ k[] d;

        static {
            k[] arrk = new k[]{a, b, c};
            d = arrk;
        }

        public static k a(int n2) {
            if (n2 != 1) {
                if (n2 != 2) {
                    return a;
                }
                return b;
            }
            return c;
        }

        public static k valueOf(String string) {
            return (k)Enum.valueOf(k.class, (String)string);
        }

        public static k[] values() {
            return (k[])d.clone();
        }
    }

}


/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.View$OnFocusChangeListener
 *  java.lang.Object
 */
package io.flutter.plugin.platform;

import android.view.View;
import io.flutter.embedding.engine.i.g;
import io.flutter.plugin.platform.i;

public final class a
implements View.OnFocusChangeListener {
    private final /* synthetic */ i.a a;
    private final /* synthetic */ g.b b;

    public /* synthetic */ a(i.a a2, g.b b2) {
        this.a = a2;
        this.b = b2;
    }

    public final void onFocusChange(View view, boolean bl) {
        this.a.a(this.b, view, bl);
    }
}


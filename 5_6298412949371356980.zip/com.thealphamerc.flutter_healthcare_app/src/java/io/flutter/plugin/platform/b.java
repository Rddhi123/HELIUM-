/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  android.view.accessibility.AccessibilityEvent
 *  java.lang.Object
 */
package io.flutter.plugin.platform;

import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import io.flutter.view.c;

class b {
    private c a;

    b() {
    }

    void a(c c2) {
        this.a = c2;
    }

    public boolean a(View view, View view2, AccessibilityEvent accessibilityEvent) {
        c c2 = this.a;
        if (c2 == null) {
            return false;
        }
        return c2.a(view, view2, accessibilityEvent);
    }
}


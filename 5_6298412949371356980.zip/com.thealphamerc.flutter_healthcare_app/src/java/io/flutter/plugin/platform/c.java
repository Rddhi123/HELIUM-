/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.ActivityManager
 *  android.app.ActivityManager$TaskDescription
 *  android.content.ClipData
 *  android.content.ClipData$Item
 *  android.content.ClipboardManager
 *  android.content.Context
 *  android.graphics.Bitmap
 *  android.graphics.Rect
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.View
 *  android.view.Window
 *  java.lang.CharSequence
 *  java.lang.Integer
 *  java.lang.NoSuchFieldError
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.List
 */
package io.flutter.plugin.platform;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Rect;
import android.os.Build;
import android.view.View;
import android.view.Window;
import io.flutter.embedding.engine.i.f;
import java.util.ArrayList;
import java.util.List;

public class c {
    private final Activity a;
    private final f b;
    private f.j c;
    private int d;
    private final f.h e = new f.h(){

        @Override
        public CharSequence a(f.e e2) {
            return c.this.a(e2);
        }

        @Override
        public List<Rect> a() {
            return c.this.c();
        }

        @Override
        public void a(int n2) {
            c.this.a(n2);
        }

        @Override
        public void a(f.c c2) {
            c.this.a(c2);
        }

        @Override
        public void a(f.g g2) {
            c.this.a(g2);
        }

        @Override
        public void a(f.i i2) {
            c.this.a(i2);
        }

        @Override
        public void a(f.j j2) {
            c.this.a(j2);
        }

        @Override
        public void a(String string) {
            c.this.a(string);
        }

        @Override
        public void a(ArrayList<Rect> arrayList) {
            c.this.a((ArrayList<Rect>)arrayList);
        }

        @Override
        public void a(List<f.k> list) {
            c.this.a((List<f.k>)list);
        }

        @Override
        public void b() {
            c.this.e();
        }

        @Override
        public void c() {
            c.this.d();
        }
    };

    public c(Activity activity, f f2) {
        this.a = activity;
        this.b = f2;
        this.b.a(this.e);
        this.d = 1280;
    }

    private CharSequence a(f.e e2) {
        ClipData clipData = ((ClipboardManager)this.a.getSystemService("clipboard")).getPrimaryClip();
        if (clipData == null) {
            return null;
        }
        if (e2 != null && e2 != f.e.b) {
            return null;
        }
        return clipData.getItemAt(0).coerceToText((Context)this.a);
    }

    private void a(int n2) {
        this.a.setRequestedOrientation(n2);
    }

    private void a(f.c c2) {
        int n2 = Build.VERSION.SDK_INT;
        if (n2 < 21) {
            return;
        }
        if (n2 < 28 && n2 > 21) {
            this.a.setTaskDescription(new ActivityManager.TaskDescription(c2.b, null, c2.a));
        }
        if (Build.VERSION.SDK_INT >= 28) {
            ActivityManager.TaskDescription taskDescription = new ActivityManager.TaskDescription(c2.b, 0, c2.a);
            this.a.setTaskDescription(taskDescription);
        }
    }

    /*
     * Unable to fully structure code
     * Enabled aggressive block sorting
     * Lifted jumps to return sites
     */
    private void a(f.g var1_1) {
        var2_2 = this.a.getWindow().getDecorView();
        var3_3 = b.a[var1_1.ordinal()];
        if (var3_3 == (var4_4 = 1)) ** GOTO lbl13
        if (var3_3 == 2 || var3_3 == (var4_4 = 3)) ** GOTO lbl11
        var4_4 = 4;
        if (var3_3 == var4_4) {
            var5_5 = 6;
        } else {
            if (var3_3 != 5) {
                return;
            }
lbl11: // 3 sources:
            var2_2.performHapticFeedback(var4_4);
            return;
lbl13: // 1 sources:
            var5_5 = 0;
        }
        var2_2.performHapticFeedback(var5_5);
    }

    private void a(f.i i2) {
        if (i2 == f.i.b) {
            this.a.getWindow().getDecorView().playSoundEffect(0);
        }
    }

    private void a(f.j j2) {
        Window window = this.a.getWindow();
        View view = window.getDecorView();
        int n2 = view.getSystemUiVisibility();
        if (Build.VERSION.SDK_INT >= 26) {
            Integer n3;
            f.d d2 = j2.d;
            if (d2 != null) {
                int n4 = b.c[d2.ordinal()];
                if (n4 != 1) {
                    if (n4 == 2) {
                        n2 &= -17;
                    }
                } else {
                    n2 |= 16;
                }
            }
            if ((n3 = j2.c) != null) {
                window.setNavigationBarColor(n3.intValue());
            }
        }
        if (Build.VERSION.SDK_INT >= 23) {
            Integer n5;
            f.d d3 = j2.b;
            if (d3 != null) {
                int n6 = b.c[d3.ordinal()];
                if (n6 != 1) {
                    if (n6 == 2) {
                        n2 &= -8193;
                    }
                } else {
                    n2 |= 8192;
                }
            }
            if ((n5 = j2.a) != null) {
                window.setStatusBarColor(n5.intValue());
            }
        }
        view.setSystemUiVisibility(n2);
        this.c = j2;
    }

    private void a(String string) {
        ((ClipboardManager)this.a.getSystemService("clipboard")).setPrimaryClip(ClipData.newPlainText((CharSequence)"text label?", (CharSequence)string));
    }

    private void a(ArrayList<Rect> arrayList) {
        if (Build.VERSION.SDK_INT < 29) {
            return;
        }
        this.a.getWindow().getDecorView().setSystemGestureExclusionRects(arrayList);
    }

    private void a(List<f.k> list) {
        int n2 = list.size() == 0 ? 5894 : 1798;
        for (int i2 = 0; i2 < list.size(); ++i2) {
            f.k k2 = (f.k)((Object)list.get(i2));
            int n3 = b.b[k2.ordinal()];
            if (n3 != 1) {
                if (n3 != 2) continue;
                n2 = -3 & (n2 & -513);
                continue;
            }
            n2 &= -5;
        }
        this.d = n2;
        this.b();
    }

    private List<Rect> c() {
        if (Build.VERSION.SDK_INT >= 29) {
            return this.a.getWindow().getDecorView().getSystemGestureExclusionRects();
        }
        return null;
    }

    private void d() {
        this.a.finish();
    }

    private void e() {
        this.b();
    }

    public void a() {
        this.b.a((f.h)null);
    }

    public void b() {
        this.a.getWindow().getDecorView().setSystemUiVisibility(this.d);
        f.j j2 = this.c;
        if (j2 != null) {
            this.a(j2);
        }
    }

}


/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.content.res.Resources
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.util.DisplayMetrics
 *  android.util.Log
 *  android.view.MotionEvent
 *  android.view.MotionEvent$PointerCoords
 *  android.view.MotionEvent$PointerProperties
 *  android.view.View
 *  java.lang.AssertionError
 *  java.lang.Double
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Math
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.nio.ByteBuffer
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.Iterator
 *  java.util.List
 */
package io.flutter.plugin.platform;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Resources;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import io.flutter.embedding.engine.i.g;
import io.flutter.plugin.platform.b;
import io.flutter.plugin.platform.e;
import io.flutter.plugin.platform.f;
import io.flutter.plugin.platform.g;
import io.flutter.plugin.platform.h;
import io.flutter.plugin.platform.j;
import io.flutter.view.c;
import io.flutter.view.e;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public class i
implements h {
    private final g a = new g();
    private Context b;
    private View c;
    private io.flutter.view.e d;
    private b.a.c.b.b e;
    private io.flutter.embedding.engine.i.g f;
    private final b g = new b();
    final HashMap<Integer, j> h = new HashMap();
    private final HashMap<Context, View> i = new HashMap();
    private final g.e j = new g.e(){

        private void a() {
            if (Build.VERSION.SDK_INT >= 20) {
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Trying to use platform views with API ");
            stringBuilder.append(Build.VERSION.SDK_INT);
            stringBuilder.append(", required API level is: ");
            stringBuilder.append(20);
            throw new IllegalStateException(stringBuilder.toString());
        }

        @TargetApi(value=17)
        @Override
        public long a(g.b b2) {
            this.a();
            if (i.b(b2.e)) {
                if (!i.this.h.containsKey((Object)b2.a)) {
                    e e2 = i.this.a.a(b2.b);
                    if (e2 != null) {
                        ByteBuffer byteBuffer = b2.f;
                        Object object = null;
                        if (byteBuffer != null) {
                            object = e2.a().a(b2.f);
                        }
                        Object object2 = object;
                        int n2 = i.this.a(b2.c);
                        int n3 = i.this.a(b2.d);
                        i.this.a(n2, n3);
                        e.a a2 = i.this.d.a();
                        j j2 = j.a(i.this.b, i.this.g, e2, a2, n2, n3, b2.a, object2, new io.flutter.plugin.platform.a(this, b2));
                        if (j2 != null) {
                            if (i.this.c != null) {
                                j2.a(i.this.c);
                            }
                            i.this.h.put((Object)b2.a, (Object)j2);
                            View view = j2.b();
                            view.setLayoutDirection(b2.e);
                            i.this.i.put((Object)view.getContext(), (Object)view);
                            return a2.b();
                        }
                        StringBuilder stringBuilder = new StringBuilder();
                        stringBuilder.append("Failed creating virtual display for a ");
                        stringBuilder.append(b2.b);
                        stringBuilder.append(" with id: ");
                        stringBuilder.append(b2.a);
                        throw new IllegalStateException(stringBuilder.toString());
                    }
                    StringBuilder stringBuilder = new StringBuilder();
                    stringBuilder.append("Trying to create a platform view of unregistered type: ");
                    stringBuilder.append(b2.b);
                    throw new IllegalStateException(stringBuilder.toString());
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Trying to create an already created platform view, view id: ");
                stringBuilder.append(b2.a);
                throw new IllegalStateException(stringBuilder.toString());
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Trying to create a view with unknown direction value: ");
            stringBuilder.append(b2.e);
            stringBuilder.append("(view id: ");
            stringBuilder.append(b2.a);
            stringBuilder.append(")");
            throw new IllegalStateException(stringBuilder.toString());
        }

        @Override
        public void a(int n2) {
            this.a();
            j j2 = (j)i.this.h.get((Object)n2);
            if (j2 != null) {
                if (i.this.e != null) {
                    i.this.e.a(n2);
                }
                i.this.i.remove((Object)j2.b().getContext());
                j2.a();
                i.this.h.remove((Object)n2);
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Trying to dispose a platform view with unknown id: ");
            stringBuilder.append(n2);
            throw new IllegalStateException(stringBuilder.toString());
        }

        @TargetApi(value=17)
        @Override
        public void a(int n2, int n3) {
            this.a();
            if (i.b(n3)) {
                View view = ((j)i.this.h.get((Object)n2)).b();
                if (view != null) {
                    view.setLayoutDirection(n3);
                    return;
                }
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Sending touch to an unknown view with id: ");
                stringBuilder.append(n3);
                throw new IllegalStateException(stringBuilder.toString());
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Trying to set unknown direction value: ");
            stringBuilder.append(n3);
            stringBuilder.append("(view id: ");
            stringBuilder.append(n2);
            stringBuilder.append(")");
            throw new IllegalStateException(stringBuilder.toString());
        }

        public /* synthetic */ void a(g.b b2, View view, boolean bl) {
            if (bl) {
                i.this.f.a(b2.a);
            }
        }

        @Override
        public void a(g.c c2, final Runnable runnable) {
            this.a();
            final j j2 = (j)i.this.h.get((Object)c2.a);
            if (j2 != null) {
                int n2 = i.this.a(c2.b);
                int n3 = i.this.a(c2.c);
                i.this.a(n2, n3);
                i.this.a(j2);
                j2.a(n2, n3, new Runnable(){

                    public void run() {
                        i.this.b(j2);
                        runnable.run();
                    }
                });
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Trying to resize a platform view with unknown id: ");
            stringBuilder.append(c2.a);
            throw new IllegalStateException(stringBuilder.toString());
        }

        @Override
        public void a(g.d d2) {
            this.a();
            float f2 = i.d((i)i.this).getResources().getDisplayMetrics().density;
            MotionEvent.PointerProperties[] arrpointerProperties = (MotionEvent.PointerProperties[])i.c(d2.f).toArray((Object[])new MotionEvent.PointerProperties[d2.e]);
            MotionEvent.PointerCoords[] arrpointerCoords = (MotionEvent.PointerCoords[])i.c(d2.g, f2).toArray((Object[])new MotionEvent.PointerCoords[d2.e]);
            if (i.this.h.containsKey((Object)d2.a)) {
                ((j)i.this.h.get((Object)d2.a)).b().dispatchTouchEvent(MotionEvent.obtain((long)d2.b.longValue(), (long)d2.c.longValue(), (int)d2.d, (int)d2.e, (MotionEvent.PointerProperties[])arrpointerProperties, (MotionEvent.PointerCoords[])arrpointerCoords, (int)d2.h, (int)d2.i, (float)d2.j, (float)d2.k, (int)d2.l, (int)d2.m, (int)d2.n, (int)d2.o));
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Sending touch to an unknown view with id: ");
            stringBuilder.append(d2.a);
            throw new IllegalStateException(stringBuilder.toString());
        }

        @Override
        public void b(int n2) {
            ((j)i.this.h.get((Object)n2)).b().clearFocus();
        }

    };

    private int a(double d2) {
        double d3 = this.b.getResources().getDisplayMetrics().density;
        Double.isNaN((double)d3);
        return (int)Math.round((double)(d2 * d3));
    }

    private void a(int n2, int n3) {
        DisplayMetrics displayMetrics = this.b.getResources().getDisplayMetrics();
        if (n3 > displayMetrics.heightPixels || n2 > displayMetrics.widthPixels) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Creating a virtual display of size: [");
            stringBuilder.append(n2);
            stringBuilder.append(", ");
            stringBuilder.append(n3);
            stringBuilder.append("] may result in problems(https://github.com/flutter/flutter/issues/2897).It is larger than the device screen size: [");
            stringBuilder.append(displayMetrics.widthPixels);
            stringBuilder.append(", ");
            stringBuilder.append(displayMetrics.heightPixels);
            stringBuilder.append("].");
            Log.w((String)"PlatformViewsController", (String)stringBuilder.toString());
        }
    }

    private void a(j j2) {
        b.a.c.b.b b2 = this.e;
        if (b2 == null) {
            return;
        }
        b2.d();
        j2.d();
    }

    private static MotionEvent.PointerCoords b(Object object, float f2) {
        List list = (List)object;
        MotionEvent.PointerCoords pointerCoords = new MotionEvent.PointerCoords();
        pointerCoords.orientation = (float)((Double)list.get(0)).doubleValue();
        pointerCoords.pressure = (float)((Double)list.get(1)).doubleValue();
        pointerCoords.size = (float)((Double)list.get(2)).doubleValue();
        pointerCoords.toolMajor = f2 * (float)((Double)list.get(3)).doubleValue();
        pointerCoords.toolMinor = f2 * (float)((Double)list.get(4)).doubleValue();
        pointerCoords.touchMajor = f2 * (float)((Double)list.get(5)).doubleValue();
        pointerCoords.touchMinor = f2 * (float)((Double)list.get(6)).doubleValue();
        pointerCoords.x = f2 * (float)((Double)list.get(7)).doubleValue();
        pointerCoords.y = f2 * (float)((Double)list.get(8)).doubleValue();
        return pointerCoords;
    }

    private static MotionEvent.PointerProperties b(Object object) {
        List list = (List)object;
        MotionEvent.PointerProperties pointerProperties = new MotionEvent.PointerProperties();
        pointerProperties.id = (Integer)list.get(0);
        pointerProperties.toolType = (Integer)list.get(1);
        return pointerProperties;
    }

    private void b(j j2) {
        b.a.c.b.b b2 = this.e;
        if (b2 == null) {
            return;
        }
        b2.e();
        j2.e();
    }

    private static boolean b(int n2) {
        int n3 = 1;
        if (n2 != 0) {
            if (n2 == n3) {
                return n3;
            }
            n3 = 0;
        }
        return n3;
    }

    private static List<MotionEvent.PointerProperties> c(Object object) {
        List list = (List)object;
        ArrayList arrayList = new ArrayList();
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)i.b(iterator.next()));
        }
        return arrayList;
    }

    private static List<MotionEvent.PointerCoords> c(Object object, float f2) {
        List list = (List)object;
        ArrayList arrayList = new ArrayList();
        Iterator iterator = list.iterator();
        while (iterator.hasNext()) {
            arrayList.add((Object)i.b(iterator.next(), f2));
        }
        return arrayList;
    }

    @Override
    public View a(Integer n2) {
        j j2 = (j)this.h.get((Object)n2);
        if (j2 == null) {
            return null;
        }
        return j2.b();
    }

    @Override
    public void a() {
        this.g.a(null);
    }

    public void a(Context context, io.flutter.view.e e2, io.flutter.embedding.engine.e.a a2) {
        if (this.b == null) {
            this.b = context;
            this.d = e2;
            this.f = new io.flutter.embedding.engine.i.g(a2);
            this.f.a(this.j);
            return;
        }
        throw new AssertionError((Object)"A PlatformViewsController can only be attached to a single output target.\nattach was called while the PlatformViewsController was already attached.");
    }

    public void a(View view) {
        this.c = view;
        Iterator iterator = this.h.values().iterator();
        while (iterator.hasNext()) {
            ((j)iterator.next()).a(view);
        }
    }

    public void a(b.a.c.b.b b2) {
        this.e = b2;
    }

    @Override
    public void a(c c2) {
        this.g.a(c2);
    }

    public void b() {
        this.f.a(null);
        this.f = null;
        this.b = null;
        this.d = null;
    }

    public boolean b(View view) {
        if (!this.i.containsKey((Object)view.getContext())) {
            return false;
        }
        View view2 = (View)this.i.get((Object)view.getContext());
        if (view2 == view) {
            return true;
        }
        return view2.checkInputConnectionProxy(view);
    }

    public void c() {
        this.c = null;
        Iterator iterator = this.h.values().iterator();
        while (iterator.hasNext()) {
            ((j)iterator.next()).c();
        }
    }

    public void d() {
        this.e = null;
    }

    public f e() {
        return this.a;
    }

}


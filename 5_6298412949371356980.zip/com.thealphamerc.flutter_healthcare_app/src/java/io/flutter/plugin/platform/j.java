/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.content.Context
 *  android.content.res.Resources
 *  android.graphics.SurfaceTexture
 *  android.hardware.display.DisplayManager
 *  android.hardware.display.VirtualDisplay
 *  android.util.DisplayMetrics
 *  android.view.Display
 *  android.view.Surface
 *  android.view.View
 *  android.view.View$OnAttachStateChangeListener
 *  android.view.View$OnFocusChangeListener
 *  android.view.ViewTreeObserver
 *  android.view.ViewTreeObserver$OnDrawListener
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 */
package io.flutter.plugin.platform;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.SurfaceTexture;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.Surface;
import android.view.View;
import android.view.ViewTreeObserver;
import io.flutter.plugin.platform.SingleViewPresentation;
import io.flutter.plugin.platform.d;
import io.flutter.plugin.platform.e;
import io.flutter.view.e;

@TargetApi(value=20)
class j {
    private final Context a;
    private final io.flutter.plugin.platform.b b;
    private final int c;
    private final e.a d;
    private final View.OnFocusChangeListener e;
    private VirtualDisplay f;
    private SingleViewPresentation g;
    private Surface h;

    private j(Context context, io.flutter.plugin.platform.b b2, VirtualDisplay virtualDisplay, e e2, Surface surface, e.a a2, View.OnFocusChangeListener onFocusChangeListener, int n2, Object object) {
        SingleViewPresentation singleViewPresentation;
        this.a = context;
        this.b = b2;
        this.d = a2;
        this.e = onFocusChangeListener;
        this.h = surface;
        this.f = virtualDisplay;
        this.c = context.getResources().getDisplayMetrics().densityDpi;
        this.g = singleViewPresentation = new SingleViewPresentation(context, this.f.getDisplay(), e2, b2, n2, object, onFocusChangeListener);
        this.g.show();
    }

    public static j a(Context context, io.flutter.plugin.platform.b b2, e e2, e.a a2, int n2, int n3, int n4, Object object, View.OnFocusChangeListener onFocusChangeListener) {
        a2.c().setDefaultBufferSize(n2, n3);
        Surface surface = new Surface(a2.c());
        VirtualDisplay virtualDisplay = ((DisplayManager)context.getSystemService("display")).createVirtualDisplay("flutter-vd", n2, n3, context.getResources().getDisplayMetrics().densityDpi, surface, 0);
        if (virtualDisplay == null) {
            return null;
        }
        j j2 = new j(context, b2, virtualDisplay, e2, surface, a2, onFocusChangeListener, n4, object);
        return j2;
    }

    public void a() {
        d d2 = this.g.getView();
        this.g.cancel();
        this.g.detachState();
        d2.a();
        this.f.release();
        this.d.a();
    }

    public void a(int n2, int n3, final Runnable runnable) {
        SingleViewPresentation singleViewPresentation;
        boolean bl = this.b().isFocused();
        SingleViewPresentation.e e2 = this.g.detachState();
        this.f.setSurface(null);
        this.f.release();
        this.d.c().setDefaultBufferSize(n2, n3);
        this.f = ((DisplayManager)this.a.getSystemService("display")).createVirtualDisplay("flutter-vd", n2, n3, this.c, this.h, 0);
        final View view = this.b();
        view.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener(this){

            public void onViewAttachedToWindow(View view2) {
                b.a(view, new Runnable(){

                    public void run() {
                        a a2 = a.this;
                        a2.view.postDelayed(a2.runnable, 128L);
                    }
                });
                view.removeOnAttachStateChangeListener((View.OnAttachStateChangeListener)this);
            }

            public void onViewDetachedFromWindow(View view2) {
            }

        });
        this.g = singleViewPresentation = new SingleViewPresentation(this.a, this.f.getDisplay(), this.b, e2, this.e, bl);
        this.g.show();
    }

    void a(View view) {
        SingleViewPresentation singleViewPresentation = this.g;
        if (singleViewPresentation != null) {
            if (singleViewPresentation.getView() == null) {
                return;
            }
            this.g.getView().a(view);
        }
    }

    public View b() {
        SingleViewPresentation singleViewPresentation = this.g;
        if (singleViewPresentation == null) {
            return null;
        }
        return singleViewPresentation.getView().d();
    }

    void c() {
        SingleViewPresentation singleViewPresentation = this.g;
        if (singleViewPresentation != null) {
            if (singleViewPresentation.getView() == null) {
                return;
            }
            this.g.getView().c();
        }
    }

    void d() {
        SingleViewPresentation singleViewPresentation = this.g;
        if (singleViewPresentation != null) {
            if (singleViewPresentation.getView() == null) {
                return;
            }
            this.g.getView().e();
        }
    }

    void e() {
        SingleViewPresentation singleViewPresentation = this.g;
        if (singleViewPresentation != null) {
            if (singleViewPresentation.getView() == null) {
                return;
            }
            this.g.getView().b();
        }
    }

    @TargetApi(value=16)
    static class b
    implements ViewTreeObserver.OnDrawListener {
        final View a;
        Runnable b;

        b(View view, Runnable runnable) {
            this.a = view;
            this.b = runnable;
        }

        static void a(View view, Runnable runnable) {
            b b2 = new b(view, runnable);
            view.getViewTreeObserver().addOnDrawListener((ViewTreeObserver.OnDrawListener)b2);
        }

        public void onDraw() {
            Runnable runnable = this.b;
            if (runnable == null) {
                return;
            }
            runnable.run();
            this.b = null;
            this.a.post(new Runnable(){

                public void run() {
                    b.this.a.getViewTreeObserver().removeOnDrawListener((ViewTreeObserver.OnDrawListener)b.this);
                }
            });
        }

    }

}


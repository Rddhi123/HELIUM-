/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.app.Presentation
 *  android.content.Context
 *  android.content.ContextWrapper
 *  android.graphics.Rect
 *  android.graphics.drawable.ColorDrawable
 *  android.graphics.drawable.Drawable
 *  android.os.Bundle
 *  android.util.Log
 *  android.view.Display
 *  android.view.Gravity
 *  android.view.View
 *  android.view.View$MeasureSpec
 *  android.view.View$OnFocusChangeListener
 *  android.view.ViewGroup
 *  android.view.ViewGroup$LayoutParams
 *  android.view.Window
 *  android.view.WindowManager
 *  android.view.WindowManager$LayoutParams
 *  android.view.accessibility.AccessibilityEvent
 *  android.view.inputmethod.InputMethodManager
 *  android.widget.FrameLayout
 *  androidx.annotation.Keep
 *  java.lang.Class
 *  java.lang.ClassLoader
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.Throwable
 *  java.lang.reflect.InvocationHandler
 *  java.lang.reflect.InvocationTargetException
 *  java.lang.reflect.Method
 *  java.lang.reflect.Proxy
 */
package io.flutter.plugin.platform;

import android.annotation.TargetApi;
import android.app.Presentation;
import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.view.inputmethod.InputMethodManager;
import android.widget.FrameLayout;
import androidx.annotation.Keep;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

@TargetApi(value=17)
@Keep
class SingleViewPresentation
extends Presentation {
    private final io.flutter.plugin.platform.b accessibilityEventsDelegate;
    private FrameLayout container;
    private Object createParams;
    private final View.OnFocusChangeListener focusChangeListener;
    private a rootView;
    private boolean startFocused = false;
    private e state;
    private final io.flutter.plugin.platform.e viewFactory;
    private int viewId;

    public SingleViewPresentation(Context context, Display display, io.flutter.plugin.platform.b b2, e e2, View.OnFocusChangeListener onFocusChangeListener, boolean bl) {
        super((Context)new c(context), display);
        this.accessibilityEventsDelegate = b2;
        this.viewFactory = null;
        this.state = e2;
        this.focusChangeListener = onFocusChangeListener;
        this.getWindow().setFlags(8, 8);
        this.startFocused = bl;
    }

    public SingleViewPresentation(Context context, Display display, io.flutter.plugin.platform.e e2, io.flutter.plugin.platform.b b2, int n2, Object object, View.OnFocusChangeListener onFocusChangeListener) {
        super((Context)new c(context), display);
        this.viewFactory = e2;
        this.accessibilityEventsDelegate = b2;
        this.viewId = n2;
        this.createParams = object;
        this.focusChangeListener = onFocusChangeListener;
        this.state = new e();
        this.getWindow().setFlags(8, 8);
    }

    public e detachState() {
        this.container.removeAllViews();
        this.rootView.removeAllViews();
        return this.state;
    }

    public io.flutter.plugin.platform.d getView() {
        if (this.state.a == null) {
            return null;
        }
        return this.state.a;
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.getWindow().setBackgroundDrawable((Drawable)new ColorDrawable(0));
        if (this.state.c == null) {
            this.state.c = new b(this.getContext());
        }
        if (this.state.b == null) {
            WindowManager windowManager = (WindowManager)this.getContext().getSystemService("window");
            e e2 = this.state;
            e2.b = new f(windowManager, e2.c);
        }
        this.container = new FrameLayout(this.getContext());
        d d2 = new d(this.getContext(), this.state.b);
        if (this.state.a == null) {
            this.state.a = this.viewFactory.a((Context)d2, this.viewId, this.createParams);
        }
        View view = this.state.a.d();
        this.container.addView(view);
        this.rootView = new a(this.getContext(), this.accessibilityEventsDelegate, view);
        this.rootView.addView((View)this.container);
        this.rootView.addView((View)this.state.c);
        view.setOnFocusChangeListener(this.focusChangeListener);
        this.rootView.setFocusableInTouchMode(true);
        if (this.startFocused) {
            view.requestFocus();
        } else {
            this.rootView.requestFocus();
        }
        this.setContentView((View)this.rootView);
    }

    private static class a
    extends FrameLayout {
        private final io.flutter.plugin.platform.b a;
        private final View b;

        public a(Context context, io.flutter.plugin.platform.b b2, View view) {
            super(context);
            this.a = b2;
            this.b = view;
        }

        public boolean requestSendAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            return this.a.a(this.b, view, accessibilityEvent);
        }
    }

    static class b
    extends ViewGroup {
        private final Rect a = new Rect();
        private final Rect b = new Rect();

        public b(Context context) {
            super(context);
        }

        private static int a(int n2) {
            return View.MeasureSpec.makeMeasureSpec((int)View.MeasureSpec.getSize((int)n2), (int)Integer.MIN_VALUE);
        }

        protected void onLayout(boolean bl, int n2, int n3, int n4, int n5) {
            for (int i2 = 0; i2 < this.getChildCount(); ++i2) {
                View view = this.getChildAt(i2);
                WindowManager.LayoutParams layoutParams = (WindowManager.LayoutParams)view.getLayoutParams();
                this.a.set(n2, n3, n4, n5);
                Gravity.apply((int)layoutParams.gravity, (int)view.getMeasuredWidth(), (int)view.getMeasuredHeight(), (Rect)this.a, (int)layoutParams.x, (int)layoutParams.y, (Rect)this.b);
                Rect rect = this.b;
                view.layout(rect.left, rect.top, rect.right, rect.bottom);
            }
        }

        protected void onMeasure(int n2, int n3) {
            for (int i2 = 0; i2 < this.getChildCount(); ++i2) {
                this.getChildAt(i2).measure(b.a(n2), b.a(n3));
            }
            super.onMeasure(n2, n3);
        }
    }

    private static class c
    extends ContextWrapper {
        private final InputMethodManager a;

        c(Context context) {
            this(context, null);
        }

        private c(Context context, InputMethodManager inputMethodManager) {
            super(context);
            if (inputMethodManager == null) {
                inputMethodManager = (InputMethodManager)context.getSystemService("input_method");
            }
            this.a = inputMethodManager;
        }

        public Context createDisplayContext(Display display) {
            return new c(super.createDisplayContext(display), this.a);
        }

        public Object getSystemService(String string) {
            if ("input_method".equals((Object)string)) {
                return this.a;
            }
            return super.getSystemService(string);
        }
    }

    private static class d
    extends ContextWrapper {
        private final f a;
        private WindowManager b;

        d(Context context, f f2) {
            super(context);
            this.a = f2;
        }

        private WindowManager a() {
            if (this.b == null) {
                this.b = this.a.a();
            }
            return this.b;
        }

        public Object getSystemService(String string) {
            if ("window".equals((Object)string)) {
                return this.a();
            }
            return super.getSystemService(string);
        }
    }

    static class e {
        private io.flutter.plugin.platform.d a;
        private f b;
        private b c;

        e() {
        }
    }

    static class f
    implements InvocationHandler {
        private final WindowManager a;
        b b;

        f(WindowManager windowManager, b b2) {
            this.a = windowManager;
            this.b = b2;
        }

        private void a(Object[] arrobject) {
            b b2 = this.b;
            if (b2 == null) {
                Log.w((String)"PlatformViewsController", (String)"Embedded view called addView while detached from presentation");
                return;
            }
            b2.addView((View)arrobject[0], (ViewGroup.LayoutParams)((WindowManager.LayoutParams)arrobject[1]));
        }

        private void b(Object[] arrobject) {
            b b2 = this.b;
            if (b2 == null) {
                Log.w((String)"PlatformViewsController", (String)"Embedded view called removeView while detached from presentation");
                return;
            }
            b2.removeView((View)arrobject[0]);
        }

        private void c(Object[] arrobject) {
            if (this.b == null) {
                Log.w((String)"PlatformViewsController", (String)"Embedded view called removeViewImmediate while detached from presentation");
                return;
            }
            View view = (View)arrobject[0];
            view.clearAnimation();
            this.b.removeView(view);
        }

        private void d(Object[] arrobject) {
            b b2 = this.b;
            if (b2 == null) {
                Log.w((String)"PlatformViewsController", (String)"Embedded view called updateViewLayout while detached from presentation");
                return;
            }
            b2.updateViewLayout((View)arrobject[0], (ViewGroup.LayoutParams)((WindowManager.LayoutParams)arrobject[1]));
        }

        public WindowManager a() {
            return (WindowManager)Proxy.newProxyInstance((ClassLoader)WindowManager.class.getClassLoader(), (Class[])new Class[]{WindowManager.class}, (InvocationHandler)this);
        }

        public Object invoke(Object object, Method method, Object[] arrobject) {
            int n2;
            block12 : {
                String string = method.getName();
                switch (string.hashCode()) {
                    default: {
                        break;
                    }
                    case 1098630473: {
                        if (!string.equals((Object)"removeView")) break;
                        n2 = 1;
                        break block12;
                    }
                    case 931413976: {
                        if (!string.equals((Object)"updateViewLayout")) break;
                        n2 = 3;
                        break block12;
                    }
                    case 542766184: {
                        if (!string.equals((Object)"removeViewImmediate")) break;
                        n2 = 2;
                        break block12;
                    }
                    case -1148522778: {
                        if (!string.equals((Object)"addView")) break;
                        n2 = 0;
                        break block12;
                    }
                }
                n2 = -1;
            }
            if (n2 != 0) {
                if (n2 != 1) {
                    if (n2 != 2) {
                        if (n2 != 3) {
                            try {
                                Object object2 = method.invoke((Object)this.a, arrobject);
                                return object2;
                            }
                            catch (InvocationTargetException invocationTargetException) {
                                throw invocationTargetException.getCause();
                            }
                        }
                        this.d(arrobject);
                        return null;
                    }
                    this.c(arrobject);
                    return null;
                }
                this.b(arrobject);
                return null;
            }
            this.a(arrobject);
            return null;
        }
    }

}


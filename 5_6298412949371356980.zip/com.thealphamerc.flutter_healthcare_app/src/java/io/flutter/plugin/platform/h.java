/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.view.View
 *  java.lang.Integer
 *  java.lang.Object
 */
package io.flutter.plugin.platform;

import android.view.View;
import io.flutter.view.c;

public interface h {
    public View a(Integer var1);

    public void a();

    public void a(c var1);
}


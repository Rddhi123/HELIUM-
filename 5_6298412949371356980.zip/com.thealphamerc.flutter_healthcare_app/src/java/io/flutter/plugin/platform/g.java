/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 */
package io.flutter.plugin.platform;

import io.flutter.plugin.platform.e;
import io.flutter.plugin.platform.f;
import java.util.HashMap;
import java.util.Map;

class g
implements f {
    private final Map<String, e> a = new HashMap();

    g() {
    }

    e a(String string) {
        return (e)this.a.get((Object)string);
    }
}


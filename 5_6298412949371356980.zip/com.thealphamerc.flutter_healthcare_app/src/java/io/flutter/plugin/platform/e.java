/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Object
 */
package io.flutter.plugin.platform;

import android.content.Context;
import b.a.c.a.g;
import io.flutter.plugin.platform.d;

public abstract class e {
    private final g<Object> a;

    public final g<Object> a() {
        return this.a;
    }

    public abstract d a(Context var1, int var2, Object var3);
}


/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.SuppressLint
 *  android.view.View
 *  java.lang.Object
 */
package io.flutter.plugin.platform;

import android.annotation.SuppressLint;
import android.view.View;

public interface d {
    public void a();

    @SuppressLint(value={"NewApi"})
    public void a(View var1);

    @SuppressLint(value={"NewApi"})
    public void b();

    @SuppressLint(value={"NewApi"})
    public void c();

    public View d();

    @SuppressLint(value={"NewApi"})
    public void e();
}


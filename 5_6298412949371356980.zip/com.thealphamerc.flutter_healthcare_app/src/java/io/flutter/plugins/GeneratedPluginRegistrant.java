/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  androidx.annotation.Keep
 *  java.lang.Object
 */
package io.flutter.plugins;

import androidx.annotation.Keep;
import io.flutter.embedding.engine.a;

@Keep
public final class GeneratedPluginRegistrant {
    public static void registerWith(a a2) {
    }
}


/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Arrays
 *  java.util.Collection
 */
package io.flutter.embedding.engine.f;

import android.os.Build;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;

class c {
    static {
        c.b();
    }

    private static String[] b() {
        if (Build.VERSION.SDK_INT >= 21) {
            return Build.SUPPORTED_ABIS;
        }
        Object[] arrobject = new String[]{Build.CPU_ABI, Build.CPU_ABI2};
        ArrayList arrayList = new ArrayList((Collection)Arrays.asList((Object[])arrobject));
        arrayList.removeAll((Collection)Arrays.asList((Object[])new String[]{null, ""}));
        return (String[])arrayList.toArray((Object[])new String[0]);
    }

    void a() {
        throw null;
    }
}


/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.flutter.embedding.engine.h;

import io.flutter.embedding.engine.h.a;

public interface c {
    public void a();

    public void a(a var1);

    public a getAttachedRenderer();
}


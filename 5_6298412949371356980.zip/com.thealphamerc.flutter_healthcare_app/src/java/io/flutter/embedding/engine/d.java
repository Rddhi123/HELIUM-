/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Intent
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.HashSet
 *  java.util.List
 *  java.util.Set
 */
package io.flutter.embedding.engine;

import android.content.Intent;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class d {
    private Set<String> a;

    public d(List<String> list) {
        this.a = new HashSet(list);
    }

    public static d a(Intent intent) {
        int n2;
        ArrayList arrayList = new ArrayList();
        if (intent.getBooleanExtra("trace-startup", false)) {
            arrayList.add((Object)"--trace-startup");
        }
        if (intent.getBooleanExtra("start-paused", false)) {
            arrayList.add((Object)"--start-paused");
        }
        if ((n2 = intent.getIntExtra("observatory-port", 0)) > 0) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("--observatory-port=");
            stringBuilder.append(Integer.toString((int)n2));
            arrayList.add((Object)stringBuilder.toString());
        }
        if (intent.getBooleanExtra("disable-service-auth-codes", false)) {
            arrayList.add((Object)"--disable-service-auth-codes");
        }
        if (intent.getBooleanExtra("use-test-fonts", false)) {
            arrayList.add((Object)"--use-test-fonts");
        }
        if (intent.getBooleanExtra("enable-dart-profiling", false)) {
            arrayList.add((Object)"--enable-dart-profiling");
        }
        if (intent.getBooleanExtra("enable-software-rendering", false)) {
            arrayList.add((Object)"--enable-software-rendering");
        }
        if (intent.getBooleanExtra("skia-deterministic-rendering", false)) {
            arrayList.add((Object)"--skia-deterministic-rendering");
        }
        if (intent.getBooleanExtra("trace-skia", false)) {
            arrayList.add((Object)"--trace-skia");
        }
        if (intent.getBooleanExtra("dump-skp-on-shader-compilation", false)) {
            arrayList.add((Object)"--dump-skp-on-shader-compilation");
        }
        if (intent.getBooleanExtra("cache-sksl", false)) {
            arrayList.add((Object)"--cache-sksl");
        }
        if (intent.getBooleanExtra("verbose-logging", false)) {
            arrayList.add((Object)"--verbose-logging");
        }
        if (intent.hasExtra("dart-flags")) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("--dart-flags=");
            stringBuilder.append(intent.getStringExtra("dart-flags"));
            arrayList.add((Object)stringBuilder.toString());
        }
        return new d((List<String>)arrayList);
    }

    public String[] a() {
        Object[] arrobject = new String[this.a.size()];
        return (String[])this.a.toArray(arrobject);
    }
}


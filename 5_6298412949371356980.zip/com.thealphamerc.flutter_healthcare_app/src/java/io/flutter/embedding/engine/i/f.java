/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.graphics.Rect
 *  java.lang.CharSequence
 *  java.lang.Enum
 *  java.lang.Integer
 *  java.lang.NoSuchFieldError
 *  java.lang.NoSuchFieldException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.HashMap
 *  java.util.List
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package io.flutter.embedding.engine.i;

import android.graphics.Rect;
import b.a.c.a.i;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class f {
    public final b.a.c.a.i a;
    private h b;
    protected final i.c c = new i.c(){

        /*
         * Exception decompiling
         */
        @Override
        public void a(b.a.c.a.h var1, i.d var2) {
            // This method has failed to decompile.  When submitting a bug report, please provide this stack trace, and (if you hold appropriate legal rights) the relevant class file.
            // org.benf.cfr.reader.util.ConfusedCFRException: Invalid stack depths @ lbl169 : ALOAD_0 : trying to set 1 previously set to 0
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:203)
            // org.benf.cfr.reader.b.a.a.g.a(Op02WithProcessedDataAndRefs.java:1489)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:308)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:182)
            // org.benf.cfr.reader.b.f.a(CodeAnalyser.java:127)
            // org.benf.cfr.reader.entities.attributes.f.c(AttributeCode.java:96)
            // org.benf.cfr.reader.entities.g.p(Method.java:396)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:890)
            // org.benf.cfr.reader.entities.d.c(ClassFile.java:773)
            // org.benf.cfr.reader.entities.d.e(ClassFile.java:870)
            // org.benf.cfr.reader.entities.d.b(ClassFile.java:792)
            // org.benf.cfr.reader.b.a(Driver.java:128)
            // org.benf.cfr.reader.a.a(CfrDriverImpl.java:63)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.decompileWithCFR(JavaExtractionWorker.kt:61)
            // com.njlabs.showjava.decompilers.JavaExtractionWorker.doWork(JavaExtractionWorker.kt:130)
            // com.njlabs.showjava.decompilers.BaseDecompiler.withAttempt(BaseDecompiler.kt:108)
            // com.njlabs.showjava.workers.DecompilerWorker$b.run(DecompilerWorker.kt:118)
            // java.util.concurrent.ThreadPoolExecutor.runWorker(ThreadPoolExecutor.java:1137)
            // java.util.concurrent.ThreadPoolExecutor$Worker.run(ThreadPoolExecutor.java:637)
            // java.lang.Thread.run(Thread.java:1012)
            throw new IllegalStateException("Decompilation failed");
        }
    };

    public f(io.flutter.embedding.engine.e.a a2) {
        this.a = new b.a.c.a.i(a2, "flutter/platform", b.a.c.a.e.a);
        this.a.a(this.c);
    }

    static /* synthetic */ int a(f f2, JSONArray jSONArray) {
        return f2.b(jSONArray);
    }

    static /* synthetic */ c a(f f2, JSONObject jSONObject) {
        return f2.a(jSONObject);
    }

    private c a(JSONObject jSONObject) {
        int n2 = jSONObject.getInt("primaryColor");
        if (n2 != 0) {
            n2 |= -16777216;
        }
        return new c(n2, jSONObject.getString("label"));
    }

    static /* synthetic */ h a(f f2) {
        return f2.b;
    }

    static /* synthetic */ ArrayList a(f f2, List list) {
        return f2.a((List<Rect>)list);
    }

    private ArrayList<HashMap<String, Integer>> a(List<Rect> list) {
        ArrayList arrayList = new ArrayList();
        for (Rect rect : list) {
            HashMap hashMap = new HashMap();
            hashMap.put((Object)"top", (Object)rect.top);
            hashMap.put((Object)"right", (Object)rect.right);
            hashMap.put((Object)"bottom", (Object)rect.bottom);
            hashMap.put((Object)"left", (Object)rect.left);
            arrayList.add((Object)hashMap);
        }
        return arrayList;
    }

    private ArrayList<Rect> a(JSONArray jSONArray) {
        ArrayList arrayList = new ArrayList();
        for (int i2 = 0; i2 < jSONArray.length(); ++i2) {
            int n2;
            int n3;
            int n4;
            int n5;
            JSONObject jSONObject = jSONArray.getJSONObject(i2);
            try {
                n4 = jSONObject.getInt("top");
                n3 = jSONObject.getInt("right");
                n5 = jSONObject.getInt("bottom");
                n2 = jSONObject.getInt("left");
            }
            catch (JSONException jSONException) {
                throw new JSONException("Incorrect JSON data shape. To set system gesture exclusion rects, \na JSONObject with top, right, bottom and left values need to be set to int values.");
            }
            arrayList.add((Object)new Rect(n2, n4, n3, n5));
        }
        return arrayList;
    }

    private int b(JSONArray jSONArray) {
        int n2 = 0;
        int n3 = 0;
        for (int i2 = 0; i2 < jSONArray.length(); ++i2) {
            f f2 = f.a(jSONArray.getString(i2));
            int n4 = b.a[f2.ordinal()];
            if (n4 != 1) {
                if (n4 != 2) {
                    if (n4 != 3) {
                        if (n4 == 4) {
                            n2 |= 8;
                        }
                    } else {
                        n2 |= 2;
                    }
                } else {
                    n2 |= 4;
                }
            } else {
                n2 |= 1;
            }
            if (n3 != 0) continue;
            n3 = n2;
        }
        int n5 = 9;
        switch (n2) {
            default: {
                return 1;
            }
            case 15: {
                return 13;
            }
            case 11: {
                return 2;
            }
            case 10: {
                return 11;
            }
            case 8: {
                return 8;
            }
            case 5: {
                n5 = 12;
            }
            case 4: {
                return n5;
            }
            case 3: 
            case 6: 
            case 7: 
            case 9: 
            case 12: 
            case 13: 
            case 14: {
                if (n3 != 1) {
                    if (n3 != 2) {
                        if (n3 != 4) {
                            if (n3 != 8) {
                                return 1;
                            }
                            return 8;
                        }
                        return n5;
                    }
                    return 0;
                }
                return 1;
            }
            case 2: {
                return 0;
            }
            case 1: {
                return 1;
            }
            case 0: 
        }
        return -1;
    }

    static /* synthetic */ j b(f f2, JSONObject jSONObject) {
        return f2.b(jSONObject);
    }

    private j b(JSONObject jSONObject) {
        d d2 = !jSONObject.isNull("systemNavigationBarIconBrightness") ? d.a(jSONObject.getString("systemNavigationBarIconBrightness")) : null;
        Integer n2 = !jSONObject.isNull("systemNavigationBarColor") ? Integer.valueOf((int)jSONObject.getInt("systemNavigationBarColor")) : null;
        d d3 = !jSONObject.isNull("statusBarIconBrightness") ? d.a(jSONObject.getString("statusBarIconBrightness")) : null;
        Integer n3 = !jSONObject.isNull("statusBarColor") ? Integer.valueOf((int)jSONObject.getInt("statusBarColor")) : null;
        boolean bl = jSONObject.isNull("systemNavigationBarDividerColor");
        Integer n4 = null;
        if (!bl) {
            n4 = jSONObject.getInt("systemNavigationBarDividerColor");
        }
        Integer n5 = n4;
        j j2 = new j(n3, d3, n2, d2, n5);
        return j2;
    }

    static /* synthetic */ List b(f f2, JSONArray jSONArray) {
        return f2.c(jSONArray);
    }

    static /* synthetic */ ArrayList c(f f2, JSONArray jSONArray) {
        return f2.a(jSONArray);
    }

    private List<k> c(JSONArray jSONArray) {
        ArrayList arrayList = new ArrayList();
        for (int i2 = 0; i2 < jSONArray.length(); ++i2) {
            k k2;
            k k3 = k.a(jSONArray.getString(i2));
            int n2 = b.b[k3.ordinal()];
            if (n2 != 1) {
                if (n2 != 2) continue;
                k2 = k.c;
            } else {
                k2 = k.b;
            }
            arrayList.add((Object)k2);
        }
        return arrayList;
    }

    public void a(h h2) {
        this.b = h2;
    }

    public static class c {
        public final int a;
        public final String b;

        public c(int n2, String string) {
            this.a = n2;
            this.b = string;
        }
    }

    public static final class d
    extends Enum<d> {
        public static final /* enum */ d b = new d("Brightness.light");
        public static final /* enum */ d c = new d("Brightness.dark");
        private static final /* synthetic */ d[] d;
        private String a;

        static {
            d[] arrd = new d[]{b, c};
            d = arrd;
        }

        private d(String string2) {
            this.a = string2;
        }

        static d a(String string) {
            NoSuchFieldException noSuchFieldException;
            for (d d2 : d.values()) {
                if (!d2.a.equals((Object)string)) continue;
                return d2;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("No such Brightness: ");
            stringBuilder.append(string);
            noSuchFieldException = new NoSuchFieldException(stringBuilder.toString());
            throw noSuchFieldException;
        }

        public static d valueOf(String string) {
            return (d)Enum.valueOf(d.class, (String)string);
        }

        public static d[] values() {
            return (d[])d.clone();
        }
    }

    public static final class e
    extends Enum<e> {
        public static final /* enum */ e b = new e("text/plain");
        private static final /* synthetic */ e[] c;
        private String a;

        static {
            e[] arre = new e[]{b};
            c = arre;
        }

        private e(String string2) {
            this.a = string2;
        }

        static e a(String string) {
            NoSuchFieldException noSuchFieldException;
            for (e e2 : e.values()) {
                if (!e2.a.equals((Object)string)) continue;
                return e2;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("No such ClipboardContentFormat: ");
            stringBuilder.append(string);
            noSuchFieldException = new NoSuchFieldException(stringBuilder.toString());
            throw noSuchFieldException;
        }

        public static e valueOf(String string) {
            return (e)Enum.valueOf(e.class, (String)string);
        }

        public static e[] values() {
            return (e[])c.clone();
        }
    }

    public static final class f
    extends Enum<f> {
        public static final /* enum */ f b = new f("DeviceOrientation.portraitUp");
        public static final /* enum */ f c = new f("DeviceOrientation.portraitDown");
        public static final /* enum */ f d = new f("DeviceOrientation.landscapeLeft");
        public static final /* enum */ f e = new f("DeviceOrientation.landscapeRight");
        private static final /* synthetic */ f[] f;
        private String a;

        static {
            f[] arrf = new f[]{b, c, d, e};
            f = arrf;
        }

        private f(String string2) {
            this.a = string2;
        }

        static f a(String string) {
            NoSuchFieldException noSuchFieldException;
            for (f f2 : f.values()) {
                if (!f2.a.equals((Object)string)) continue;
                return f2;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("No such DeviceOrientation: ");
            stringBuilder.append(string);
            noSuchFieldException = new NoSuchFieldException(stringBuilder.toString());
            throw noSuchFieldException;
        }

        public static f valueOf(String string) {
            return (f)Enum.valueOf(f.class, (String)string);
        }

        public static f[] values() {
            return (f[])f.clone();
        }
    }

    public static final class g
    extends Enum<g> {
        public static final /* enum */ g b = new g(null);
        public static final /* enum */ g c = new g("HapticFeedbackType.lightImpact");
        public static final /* enum */ g d = new g("HapticFeedbackType.mediumImpact");
        public static final /* enum */ g e = new g("HapticFeedbackType.heavyImpact");
        public static final /* enum */ g f = new g("HapticFeedbackType.selectionClick");
        private static final /* synthetic */ g[] g;
        private final String a;

        static {
            g[] arrg = new g[]{b, c, d, e, f};
            g = arrg;
        }

        private g(String string2) {
            this.a = string2;
        }

        static g a(String string) {
            NoSuchFieldException noSuchFieldException;
            for (g g2 : g.values()) {
                String string2;
                if ((g2.a != null || string != null) && ((string2 = g2.a) == null || !string2.equals((Object)string))) continue;
                return g2;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("No such HapticFeedbackType: ");
            stringBuilder.append(string);
            noSuchFieldException = new NoSuchFieldException(stringBuilder.toString());
            throw noSuchFieldException;
        }

        public static g valueOf(String string) {
            return (g)Enum.valueOf(g.class, (String)string);
        }

        public static g[] values() {
            return (g[])g.clone();
        }
    }

    public static interface h {
        public CharSequence a(e var1);

        public List<Rect> a();

        public void a(int var1);

        public void a(c var1);

        public void a(g var1);

        public void a(i var1);

        public void a(j var1);

        public void a(String var1);

        public void a(ArrayList<Rect> var1);

        public void a(List<k> var1);

        public void b();

        public void c();
    }

    public static final class i
    extends Enum<i> {
        public static final /* enum */ i b = new i("SystemSoundType.click");
        private static final /* synthetic */ i[] c;
        private final String a;

        static {
            i[] arri = new i[]{b};
            c = arri;
        }

        private i(String string2) {
            this.a = string2;
        }

        static i a(String string) {
            NoSuchFieldException noSuchFieldException;
            for (i i2 : i.values()) {
                if (!i2.a.equals((Object)string)) continue;
                return i2;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("No such SoundType: ");
            stringBuilder.append(string);
            noSuchFieldException = new NoSuchFieldException(stringBuilder.toString());
            throw noSuchFieldException;
        }

        public static i valueOf(String string) {
            return (i)Enum.valueOf(i.class, (String)string);
        }

        public static i[] values() {
            return (i[])c.clone();
        }
    }

    public static class j {
        public final Integer a;
        public final d b;
        public final Integer c;
        public final d d;
        public final Integer e;

        public j(Integer n2, d d2, Integer n3, d d3, Integer n4) {
            this.a = n2;
            this.b = d2;
            this.c = n3;
            this.d = d3;
            this.e = n4;
        }
    }

    public static final class k
    extends Enum<k> {
        public static final /* enum */ k b = new k("SystemUiOverlay.top");
        public static final /* enum */ k c = new k("SystemUiOverlay.bottom");
        private static final /* synthetic */ k[] d;
        private String a;

        static {
            k[] arrk = new k[]{b, c};
            d = arrk;
        }

        private k(String string2) {
            this.a = string2;
        }

        static k a(String string) {
            NoSuchFieldException noSuchFieldException;
            for (k k2 : k.values()) {
                if (!k2.a.equals((Object)string)) continue;
                return k2;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("No such SystemUiOverlay: ");
            stringBuilder.append(string);
            noSuchFieldException = new NoSuchFieldException(stringBuilder.toString());
            throw noSuchFieldException;
        }

        public static k valueOf(String string) {
            return (k)Enum.valueOf(k.class, (String)string);
        }

        public static k[] values() {
            return (k[])d.clone();
        }
    }

}


/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.res.AssetManager
 *  java.lang.Class
 *  java.lang.Deprecated
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.nio.ByteBuffer
 */
package io.flutter.embedding.engine.e;

import android.content.res.AssetManager;
import b.a.c.a.b;
import b.a.c.a.q;
import io.flutter.embedding.engine.FlutterJNI;
import java.nio.ByteBuffer;

public class a
implements b.a.c.a.b {
    private final FlutterJNI a;
    private final AssetManager b;
    private final io.flutter.embedding.engine.e.b c;
    private final b.a.c.a.b d;
    private boolean e = false;
    private String f;
    private d g;
    private final b.a h = new b.a(){

        @Override
        public void a(ByteBuffer byteBuffer, b.b b2) {
            a.this.f = (String)q.b.a(byteBuffer);
            if (a.this.g != null) {
                a.this.g.a(a.this.f);
            }
        }
    };

    public a(FlutterJNI flutterJNI, AssetManager assetManager) {
        this.a = flutterJNI;
        this.b = assetManager;
        this.c = new io.flutter.embedding.engine.e.b(flutterJNI);
        this.c.a("flutter/isolate", this.h);
        this.d = new c(this.c);
    }

    public String a() {
        return this.f;
    }

    public void a(b b2) {
        if (this.e) {
            b.a.a.d("DartExecutor", "Attempted to run a DartExecutor that is already running.");
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Executing Dart entrypoint: ");
        stringBuilder.append((Object)b2);
        b.a.a.c("DartExecutor", stringBuilder.toString());
        this.a.runBundleAndSnapshotFromLibrary(b2.a, b2.b, null, this.b);
        this.e = true;
    }

    @Deprecated
    @Override
    public void a(String string, b.a a2) {
        this.d.a(string, a2);
    }

    @Deprecated
    @Override
    public void a(String string, ByteBuffer byteBuffer, b.b b2) {
        this.d.a(string, byteBuffer, b2);
    }

    public boolean b() {
        return this.e;
    }

    public void c() {
        b.a.a.c("DartExecutor", "Attached to JNI. Registering the platform message handler for this Dart execution context.");
        this.a.setPlatformMessageHandler(this.c);
    }

    public void d() {
        b.a.a.c("DartExecutor", "Detached from JNI. De-registering the platform message handler for this Dart execution context.");
        this.a.setPlatformMessageHandler(null);
    }

    public static class b {
        public final String a;
        public final String b;

        public b(String string, String string2) {
            this.a = string;
            this.b = string2;
        }

        public boolean equals(Object object) {
            if (this == object) {
                return true;
            }
            if (object != null) {
                if (b.class != object.getClass()) {
                    return false;
                }
                b b2 = (b)object;
                if (!this.a.equals((Object)b2.a)) {
                    return false;
                }
                return this.b.equals((Object)b2.b);
            }
            return false;
        }

        public int hashCode() {
            return 31 * this.a.hashCode() + this.b.hashCode();
        }

        public String toString() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("DartEntrypoint( bundle path: ");
            stringBuilder.append(this.a);
            stringBuilder.append(", function: ");
            stringBuilder.append(this.b);
            stringBuilder.append(" )");
            return stringBuilder.toString();
        }
    }

    private static class c
    implements b.a.c.a.b {
        private final io.flutter.embedding.engine.e.b a;

        private c(io.flutter.embedding.engine.e.b b2) {
            this.a = b2;
        }

        @Override
        public void a(String string, b.a a2) {
            this.a.a(string, a2);
        }

        @Override
        public void a(String string, ByteBuffer byteBuffer, b.b b2) {
            this.a.a(string, byteBuffer, b2);
        }
    }

    static interface d {
        public void a(String var1);
    }

}


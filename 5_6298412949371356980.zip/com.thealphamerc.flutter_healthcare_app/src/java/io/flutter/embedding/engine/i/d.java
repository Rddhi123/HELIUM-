/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.ArrayList
 *  java.util.List
 *  java.util.Locale
 */
package io.flutter.embedding.engine.i;

import android.os.Build;
import b.a.a;
import b.a.c.a.b;
import b.a.c.a.e;
import b.a.c.a.i;
import b.a.c.a.j;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class d {
    public final i a;

    public d(io.flutter.embedding.engine.e.a a2) {
        this.a = new i(a2, "flutter/localization", e.a);
    }

    public void a(List<Locale> list) {
        a.c("LocalizationChannel", "Sending Locales to Flutter.");
        ArrayList arrayList = new ArrayList();
        for (Locale locale : list) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Locale (Language: ");
            stringBuilder.append(locale.getLanguage());
            stringBuilder.append(", Country: ");
            stringBuilder.append(locale.getCountry());
            stringBuilder.append(", Variant: ");
            stringBuilder.append(locale.getVariant());
            stringBuilder.append(")");
            a.c("LocalizationChannel", stringBuilder.toString());
            arrayList.add((Object)locale.getLanguage());
            arrayList.add((Object)locale.getCountry());
            String string = Build.VERSION.SDK_INT >= 21 ? locale.getScript() : "";
            arrayList.add((Object)string);
            arrayList.add((Object)locale.getVariant());
        }
        this.a.a("setLocale", (Object)arrayList);
    }
}


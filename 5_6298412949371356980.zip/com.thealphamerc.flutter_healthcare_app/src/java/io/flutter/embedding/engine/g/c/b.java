/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Intent
 *  android.os.Bundle
 *  androidx.lifecycle.e
 *  java.lang.Object
 *  java.lang.String
 */
package io.flutter.embedding.engine.g.c;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import androidx.lifecycle.e;

public interface b {
    public void a();

    public void a(Activity var1, e var2);

    public void a(Intent var1);

    public void a(Bundle var1);

    public boolean a(int var1, int var2, Intent var3);

    public boolean a(int var1, String[] var2, int[] var3);

    public void b();

    public void b(Bundle var1);

    public void c();
}


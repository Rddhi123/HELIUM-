/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.annotation.TargetApi
 *  android.graphics.SurfaceTexture
 *  android.graphics.SurfaceTexture$OnFrameAvailableListener
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.os.Handler
 *  android.view.Surface
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.nio.ByteBuffer
 *  java.util.concurrent.atomic.AtomicLong
 */
package io.flutter.embedding.engine.h;

import android.annotation.TargetApi;
import android.graphics.SurfaceTexture;
import android.os.Build;
import android.os.Handler;
import android.view.Surface;
import io.flutter.embedding.engine.FlutterJNI;
import io.flutter.view.e;
import java.nio.ByteBuffer;
import java.util.concurrent.atomic.AtomicLong;

@TargetApi(value=16)
public class a
implements e {
    private final FlutterJNI a;
    private final AtomicLong b = new AtomicLong(0L);
    private Surface c;
    private boolean d = false;
    private final io.flutter.embedding.engine.h.b e = new io.flutter.embedding.engine.h.b(){

        @Override
        public void a() {
            a.this.d = true;
        }

        @Override
        public void b() {
            a.this.d = false;
        }
    };

    public a(FlutterJNI flutterJNI) {
        this.a = flutterJNI;
        this.a.addIsDisplayingFlutterUiListener(this.e);
    }

    private void a(long l2) {
        this.a.markTextureFrameAvailable(l2);
    }

    private void a(long l2, SurfaceTexture surfaceTexture) {
        this.a.registerTexture(l2, surfaceTexture);
    }

    private void b(long l2) {
        this.a.unregisterTexture(l2);
    }

    @Override
    public e.a a() {
        b.a.a.c("FlutterRenderer", "Creating a SurfaceTexture.");
        SurfaceTexture surfaceTexture = new SurfaceTexture(0);
        surfaceTexture.detachFromGLContext();
        b b2 = new b(this.b.getAndIncrement(), surfaceTexture);
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("New SurfaceTexture ID: ");
        stringBuilder.append(b2.b());
        b.a.a.c("FlutterRenderer", stringBuilder.toString());
        this.a(b2.b(), surfaceTexture);
        return b2;
    }

    public void a(int n2, int n3) {
        this.a.onSurfaceChanged(n2, n3);
    }

    public void a(Surface surface) {
        if (this.c != null) {
            this.d();
        }
        this.c = surface;
        this.a.onSurfaceCreated(surface);
    }

    public void a(c c2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Setting viewport metrics\nSize: ");
        stringBuilder.append(c2.b);
        stringBuilder.append(" x ");
        stringBuilder.append(c2.c);
        stringBuilder.append("\nPadding - L: ");
        stringBuilder.append(c2.g);
        stringBuilder.append(", T: ");
        stringBuilder.append(c2.d);
        stringBuilder.append(", R: ");
        stringBuilder.append(c2.e);
        stringBuilder.append(", B: ");
        stringBuilder.append(c2.f);
        stringBuilder.append("\nInsets - L: ");
        stringBuilder.append(c2.k);
        stringBuilder.append(", T: ");
        stringBuilder.append(c2.h);
        stringBuilder.append(", R: ");
        stringBuilder.append(c2.i);
        stringBuilder.append(", B: ");
        stringBuilder.append(c2.j);
        stringBuilder.append("\nSystem Gesture Insets - L: ");
        stringBuilder.append(c2.o);
        stringBuilder.append(", T: ");
        stringBuilder.append(c2.l);
        stringBuilder.append(", R: ");
        stringBuilder.append(c2.m);
        stringBuilder.append(", B: ");
        stringBuilder.append(c2.j);
        b.a.a.c("FlutterRenderer", stringBuilder.toString());
        this.a.setViewportMetrics(c2.a, c2.b, c2.c, c2.d, c2.e, c2.f, c2.g, c2.h, c2.i, c2.j, c2.k, c2.l, c2.m, c2.n, c2.o);
    }

    public void a(io.flutter.embedding.engine.h.b b2) {
        this.a.addIsDisplayingFlutterUiListener(b2);
        if (this.d) {
            b2.a();
        }
    }

    public void a(ByteBuffer byteBuffer, int n2) {
        this.a.dispatchPointerDataPacket(byteBuffer, n2);
    }

    public void a(boolean bl) {
        this.a.setSemanticsEnabled(bl);
    }

    public void b(io.flutter.embedding.engine.h.b b2) {
        this.a.removeIsDisplayingFlutterUiListener(b2);
    }

    public boolean b() {
        return this.d;
    }

    public boolean c() {
        return this.a.nativeGetIsSoftwareRenderingEnabled();
    }

    public void d() {
        this.a.onSurfaceDestroyed();
        this.c = null;
        if (this.d) {
            this.e.b();
        }
        this.d = false;
    }

    final class b
    implements e.a {
        private final long a;
        private final SurfaceTexture b;
        private boolean c;
        private SurfaceTexture.OnFrameAvailableListener d = new SurfaceTexture.OnFrameAvailableListener(){

            public void onFrameAvailable(SurfaceTexture surfaceTexture) {
                if (b.this.c) {
                    return;
                }
                b b2 = b.this;
                b2.a.this.a(b2.a);
            }
        };

        b(long l2, SurfaceTexture surfaceTexture) {
            this.a = l2;
            this.b = surfaceTexture;
            if (Build.VERSION.SDK_INT >= 21) {
                this.b.setOnFrameAvailableListener(this.d, new Handler());
                return;
            }
            this.b.setOnFrameAvailableListener(this.d);
        }

        @Override
        public void a() {
            if (this.c) {
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Releasing a SurfaceTexture (");
            stringBuilder.append(this.a);
            stringBuilder.append(").");
            b.a.a.c("FlutterRenderer", stringBuilder.toString());
            this.b.release();
            a.this.b(this.a);
            this.c = true;
        }

        @Override
        public long b() {
            return this.a;
        }

        @Override
        public SurfaceTexture c() {
            return this.b;
        }

    }

    public static final class c {
        public float a = 1.0f;
        public int b = 0;
        public int c = 0;
        public int d = 0;
        public int e = 0;
        public int f = 0;
        public int g = 0;
        public int h = 0;
        public int i = 0;
        public int j = 0;
        public int k = 0;
        public int l = 0;
        public int m = 0;
        public int n = 0;
        public int o = 0;
    }

}


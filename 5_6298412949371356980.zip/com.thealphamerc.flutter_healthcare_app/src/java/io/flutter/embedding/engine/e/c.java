/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package io.flutter.embedding.engine.e;

public interface c {
    public void a(int var1, byte[] var2);

    public void a(String var1, byte[] var2, int var3);
}


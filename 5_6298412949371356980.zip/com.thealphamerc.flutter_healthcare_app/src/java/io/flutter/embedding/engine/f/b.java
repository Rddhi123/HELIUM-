/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.os.AsyncTask
 *  android.os.Handler
 *  java.io.File
 *  java.io.FilenameFilter
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.Void
 *  java.util.concurrent.Executor
 */
package io.flutter.embedding.engine.f;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Handler;
import java.io.File;
import java.io.FilenameFilter;
import java.util.concurrent.Executor;

class b {
    private final Context a;

    b(Context context) {
        this.a = context;
    }

    void a() {
        File file = this.a.getCacheDir();
        if (file == null) {
            return;
        }
        final c c2 = new c(file.listFiles(new FilenameFilter(this){

            public boolean accept(File file, String string) {
                return string.startsWith(".org.chromium.Chromium.");
            }
        }));
        if (!c2.a()) {
            return;
        }
        new Handler().postDelayed(new Runnable(this){

            public void run() {
                c2.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Object[])new Void[0]);
            }
        }, 5000L);
    }

    private static class c
    extends AsyncTask<Void, Void, Void> {
        private final File[] a;

        c(File[] arrfile) {
            this.a = arrfile;
        }

        private void a(File file) {
            if (file.isDirectory()) {
                File[] arrfile = file.listFiles();
                int n2 = arrfile.length;
                for (int i2 = 0; i2 < n2; ++i2) {
                    this.a(arrfile[i2]);
                }
            }
            file.delete();
        }

        protected /* varargs */ Void a(Void ... arrvoid) {
            for (File file : this.a) {
                if (!file.exists()) continue;
                this.a(file);
            }
            return null;
        }

        boolean a() {
            File[] arrfile = this.a;
            return arrfile != null && arrfile.length > 0;
        }
    }

}


/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package io.flutter.embedding.engine.g.c;

import io.flutter.embedding.engine.g.c.c;

public interface a {
    public void a();

    public void a(c var1);

    public void b();

    public void b(c var1);
}


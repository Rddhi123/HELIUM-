/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.app.Service
 *  android.content.BroadcastReceiver
 *  android.content.ContentProvider
 *  android.content.Context
 *  android.content.Intent
 *  android.os.Bundle
 *  androidx.lifecycle.e
 *  java.lang.Class
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Collection
 *  java.util.HashMap
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.Map
 *  java.util.Set
 */
package io.flutter.embedding.engine;

import android.app.Activity;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ContentProvider;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import androidx.lifecycle.e;
import b.a.c.a.k;
import b.a.c.a.l;
import b.a.c.a.m;
import b.a.c.a.n;
import io.flutter.embedding.engine.g.a;
import io.flutter.embedding.engine.g.c.c;
import io.flutter.embedding.engine.plugins.lifecycle.HiddenLifecycleReference;
import io.flutter.plugin.platform.f;
import io.flutter.plugin.platform.i;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

class c
implements io.flutter.embedding.engine.g.b,
io.flutter.embedding.engine.g.c.b,
io.flutter.embedding.engine.g.f.b,
io.flutter.embedding.engine.g.d.b,
io.flutter.embedding.engine.g.e.b {
    private final Map<Class<? extends io.flutter.embedding.engine.g.a>, io.flutter.embedding.engine.g.a> a = new HashMap();
    private final io.flutter.embedding.engine.a b;
    private final a.b c;
    private final Map<Class<? extends io.flutter.embedding.engine.g.a>, io.flutter.embedding.engine.g.c.a> d = new HashMap();
    private Activity e;
    private c f;
    private boolean g = false;
    private final Map<Class<? extends io.flutter.embedding.engine.g.a>, io.flutter.embedding.engine.g.f.a> h = new HashMap();
    private Service i;
    private final Map<Class<? extends io.flutter.embedding.engine.g.a>, io.flutter.embedding.engine.g.d.a> j = new HashMap();
    private BroadcastReceiver k;
    private final Map<Class<? extends io.flutter.embedding.engine.g.a>, io.flutter.embedding.engine.g.e.a> l = new HashMap();
    private ContentProvider m;

    c(Context context, io.flutter.embedding.engine.a a2, io.flutter.embedding.engine.f.a a3) {
        a.b b2;
        this.b = a2;
        this.c = b2 = new a.b(context, a2, a2.d(), a2.k(), a2.j().e(), new b(a3));
    }

    private void i() {
        if (this.j()) {
            this.c();
            return;
        }
        if (this.m()) {
            this.g();
            return;
        }
        if (this.k()) {
            this.e();
            return;
        }
        if (this.l()) {
            this.f();
        }
    }

    private boolean j() {
        return this.e != null;
    }

    private boolean k() {
        return this.k != null;
    }

    private boolean l() {
        return this.m != null;
    }

    private boolean m() {
        return this.i != null;
    }

    @Override
    public void a() {
        b.a.a.c("FlutterEnginePluginRegistry", "Forwarding onUserLeaveHint() to plugins.");
        if (this.j()) {
            this.f.a();
            return;
        }
        b.a.a.b("FlutterEnginePluginRegistry", "Attempted to notify ActivityAware plugins of onUserLeaveHint, but no Activity was attached.");
    }

    @Override
    public void a(Activity activity, e e2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Attaching to an Activity: ");
        stringBuilder.append((Object)activity);
        stringBuilder.append(".");
        String string = this.g ? " This is after a config change." : "";
        stringBuilder.append(string);
        b.a.a.c("FlutterEnginePluginRegistry", stringBuilder.toString());
        this.i();
        this.e = activity;
        this.f = new c(activity, e2);
        this.b.j().a((Context)activity, this.b.k(), this.b.d());
        for (io.flutter.embedding.engine.g.c.a a2 : this.d.values()) {
            if (this.g) {
                a2.b(this.f);
                continue;
            }
            a2.a(this.f);
        }
        this.g = false;
    }

    @Override
    public void a(Intent intent) {
        b.a.a.c("FlutterEnginePluginRegistry", "Forwarding onNewIntent() to plugins.");
        if (this.j()) {
            this.f.a(intent);
            return;
        }
        b.a.a.b("FlutterEnginePluginRegistry", "Attempted to notify ActivityAware plugins of onNewIntent, but no Activity was attached.");
    }

    @Override
    public void a(Bundle bundle) {
        b.a.a.c("FlutterEnginePluginRegistry", "Forwarding onRestoreInstanceState() to plugins.");
        if (this.j()) {
            this.f.a(bundle);
            return;
        }
        b.a.a.b("FlutterEnginePluginRegistry", "Attempted to notify ActivityAware plugins of onRestoreInstanceState, but no Activity was attached.");
    }

    public void a(Class<? extends io.flutter.embedding.engine.g.a> class_) {
        io.flutter.embedding.engine.g.a a2 = (io.flutter.embedding.engine.g.a)this.a.get(class_);
        if (a2 != null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Removing plugin: ");
            stringBuilder.append((Object)a2);
            b.a.a.c("FlutterEnginePluginRegistry", stringBuilder.toString());
            if (a2 instanceof io.flutter.embedding.engine.g.c.a) {
                if (this.j()) {
                    ((io.flutter.embedding.engine.g.c.a)((Object)a2)).a();
                }
                this.d.remove(class_);
            }
            if (a2 instanceof io.flutter.embedding.engine.g.f.a) {
                if (this.m()) {
                    ((io.flutter.embedding.engine.g.f.a)((Object)a2)).a();
                }
                this.h.remove(class_);
            }
            if (a2 instanceof io.flutter.embedding.engine.g.d.a) {
                if (this.k()) {
                    ((io.flutter.embedding.engine.g.d.a)((Object)a2)).a();
                }
                this.j.remove(class_);
            }
            if (a2 instanceof io.flutter.embedding.engine.g.e.a) {
                if (this.l()) {
                    ((io.flutter.embedding.engine.g.e.a)((Object)a2)).a();
                }
                this.l.remove(class_);
            }
            a2.a(this.c);
            this.a.remove(class_);
        }
    }

    public void a(Set<Class<? extends io.flutter.embedding.engine.g.a>> set) {
        Iterator iterator = set.iterator();
        while (iterator.hasNext()) {
            this.a((Class<? extends io.flutter.embedding.engine.g.a>)((Class)iterator.next()));
        }
    }

    @Override
    public boolean a(int n2, int n3, Intent intent) {
        b.a.a.c("FlutterEnginePluginRegistry", "Forwarding onActivityResult() to plugins.");
        if (this.j()) {
            return this.f.a(n2, n3, intent);
        }
        b.a.a.b("FlutterEnginePluginRegistry", "Attempted to notify ActivityAware plugins of onActivityResult, but no Activity was attached.");
        return false;
    }

    @Override
    public boolean a(int n2, String[] arrstring, int[] arrn) {
        b.a.a.c("FlutterEnginePluginRegistry", "Forwarding onRequestPermissionsResult() to plugins.");
        if (this.j()) {
            return this.f.a(n2, arrstring, arrn);
        }
        b.a.a.b("FlutterEnginePluginRegistry", "Attempted to notify ActivityAware plugins of onRequestPermissionsResult, but no Activity was attached.");
        return false;
    }

    @Override
    public void b() {
        if (this.j()) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Detaching from an Activity for config changes: ");
            stringBuilder.append((Object)this.e);
            b.a.a.c("FlutterEnginePluginRegistry", stringBuilder.toString());
            this.g = true;
            Iterator iterator = this.d.values().iterator();
            while (iterator.hasNext()) {
                ((io.flutter.embedding.engine.g.c.a)iterator.next()).b();
            }
            this.b.j().b();
            this.e = null;
            this.f = null;
            return;
        }
        b.a.a.b("FlutterEnginePluginRegistry", "Attempted to detach plugins from an Activity when no Activity was attached.");
    }

    @Override
    public void b(Bundle bundle) {
        b.a.a.c("FlutterEnginePluginRegistry", "Forwarding onSaveInstanceState() to plugins.");
        if (this.j()) {
            this.f.b(bundle);
            return;
        }
        b.a.a.b("FlutterEnginePluginRegistry", "Attempted to notify ActivityAware plugins of onSaveInstanceState, but no Activity was attached.");
    }

    @Override
    public void c() {
        if (this.j()) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Detaching from an Activity: ");
            stringBuilder.append((Object)this.e);
            b.a.a.c("FlutterEnginePluginRegistry", stringBuilder.toString());
            Iterator iterator = this.d.values().iterator();
            while (iterator.hasNext()) {
                ((io.flutter.embedding.engine.g.c.a)iterator.next()).a();
            }
            this.b.j().b();
            this.e = null;
            this.f = null;
            return;
        }
        b.a.a.b("FlutterEnginePluginRegistry", "Attempted to detach plugins from an Activity when no Activity was attached.");
    }

    public void d() {
        b.a.a.a("FlutterEnginePluginRegistry", "Destroying.");
        this.i();
        this.h();
    }

    public void e() {
        if (this.k()) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Detaching from BroadcastReceiver: ");
            stringBuilder.append((Object)this.k);
            b.a.a.c("FlutterEnginePluginRegistry", stringBuilder.toString());
            Iterator iterator = this.j.values().iterator();
            while (iterator.hasNext()) {
                ((io.flutter.embedding.engine.g.d.a)iterator.next()).a();
            }
        } else {
            b.a.a.b("FlutterEnginePluginRegistry", "Attempted to detach plugins from a BroadcastReceiver when no BroadcastReceiver was attached.");
        }
    }

    public void f() {
        if (this.l()) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Detaching from ContentProvider: ");
            stringBuilder.append((Object)this.m);
            b.a.a.c("FlutterEnginePluginRegistry", stringBuilder.toString());
            Iterator iterator = this.l.values().iterator();
            while (iterator.hasNext()) {
                ((io.flutter.embedding.engine.g.e.a)iterator.next()).a();
            }
        } else {
            b.a.a.b("FlutterEnginePluginRegistry", "Attempted to detach plugins from a ContentProvider when no ContentProvider was attached.");
        }
    }

    public void g() {
        if (this.m()) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Detaching from a Service: ");
            stringBuilder.append((Object)this.i);
            b.a.a.c("FlutterEnginePluginRegistry", stringBuilder.toString());
            Iterator iterator = this.h.values().iterator();
            while (iterator.hasNext()) {
                ((io.flutter.embedding.engine.g.f.a)iterator.next()).a();
            }
            this.i = null;
            return;
        }
        b.a.a.b("FlutterEnginePluginRegistry", "Attempted to detach plugins from a Service when no Service was attached.");
    }

    public void h() {
        this.a((Set<Class<? extends io.flutter.embedding.engine.g.a>>)new HashSet((Collection)this.a.keySet()));
        this.a.clear();
    }

    private static class b
    implements a.a {
        private b(io.flutter.embedding.engine.f.a a2) {
        }
    }

    private static class c
    implements io.flutter.embedding.engine.g.c.c {
        private final Set<m> a = new HashSet();
        private final Set<k> b = new HashSet();
        private final Set<l> c = new HashSet();
        private final Set<n> d = new HashSet();
        private final Set<c.a> e = new HashSet();

        public c(Activity activity, e e2) {
            new HiddenLifecycleReference(e2);
        }

        void a() {
            Iterator iterator = this.d.iterator();
            while (iterator.hasNext()) {
                ((n)iterator.next()).a();
            }
        }

        void a(Intent intent) {
            Iterator iterator = this.c.iterator();
            while (iterator.hasNext()) {
                ((l)iterator.next()).a(intent);
            }
        }

        void a(Bundle bundle) {
            Iterator iterator = this.e.iterator();
            while (iterator.hasNext()) {
                ((c.a)iterator.next()).a(bundle);
            }
        }

        boolean a(int n2, int n3, Intent intent) {
            boolean bl;
            Iterator iterator = this.b.iterator();
            block0 : do {
                bl = false;
                while (iterator.hasNext()) {
                    if (!((k)iterator.next()).a(n2, n3, intent) && !bl) continue block0;
                    bl = true;
                }
                break;
            } while (true);
            return bl;
        }

        boolean a(int n2, String[] arrstring, int[] arrn) {
            boolean bl;
            Iterator iterator = this.a.iterator();
            block0 : do {
                bl = false;
                while (iterator.hasNext()) {
                    if (!((m)iterator.next()).a(n2, arrstring, arrn) && !bl) continue block0;
                    bl = true;
                }
                break;
            } while (true);
            return bl;
        }

        void b(Bundle bundle) {
            Iterator iterator = this.e.iterator();
            while (iterator.hasNext()) {
                ((c.a)iterator.next()).b(bundle);
            }
        }
    }

}


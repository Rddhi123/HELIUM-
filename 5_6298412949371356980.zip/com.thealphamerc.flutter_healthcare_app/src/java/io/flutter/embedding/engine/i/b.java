/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Build
 *  android.os.Build$VERSION
 *  android.view.InputDevice
 *  android.view.KeyEvent
 *  java.lang.Character
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 */
package io.flutter.embedding.engine.i;

import android.os.Build;
import android.view.InputDevice;
import android.view.KeyEvent;
import b.a.c.a.d;
import b.a.c.a.g;
import java.util.HashMap;
import java.util.Map;

public class b {
    public final b.a.c.a.a<Object> a;

    public b(io.flutter.embedding.engine.e.a a2) {
        this.a = new b.a.c.a.a<Object>(a2, "flutter/keyevent", d.a);
    }

    private void a(a a2, Map<String, Object> map) {
        map.put((Object)"flags", (Object)a2.b);
        map.put((Object)"plainCodePoint", (Object)a2.c);
        map.put((Object)"codePoint", (Object)a2.d);
        map.put((Object)"keyCode", (Object)a2.e);
        map.put((Object)"scanCode", (Object)a2.g);
        map.put((Object)"metaState", (Object)a2.h);
        Character c2 = a2.f;
        if (c2 != null) {
            map.put((Object)"character", (Object)c2.toString());
        }
        map.put((Object)"source", (Object)a2.i);
        map.put((Object)"vendorId", (Object)a2.j);
        map.put((Object)"productId", (Object)a2.k);
        map.put((Object)"deviceId", (Object)a2.a);
        map.put((Object)"repeatCount", (Object)a2.l);
    }

    public void a(a a2) {
        HashMap hashMap = new HashMap();
        hashMap.put((Object)"type", (Object)"keydown");
        hashMap.put((Object)"keymap", (Object)"android");
        this.a(a2, (Map<String, Object>)hashMap);
        this.a.a((Object)hashMap);
    }

    public void b(a a2) {
        HashMap hashMap = new HashMap();
        hashMap.put((Object)"type", (Object)"keyup");
        hashMap.put((Object)"keymap", (Object)"android");
        this.a(a2, (Map<String, Object>)hashMap);
        this.a.a((Object)hashMap);
    }

    public static class a {
        public final int a;
        public final int b;
        public final int c;
        public final int d;
        public final int e;
        public final Character f;
        public final int g;
        public final int h;
        public final int i;
        public final int j;
        public final int k;
        public final int l;

        public a(int n2, int n3, int n4, int n5, int n6, Character c2, int n7, int n8, int n9, int n10) {
            this.a = n2;
            this.b = n3;
            this.c = n4;
            this.d = n5;
            this.e = n6;
            this.f = c2;
            this.g = n7;
            this.h = n8;
            this.i = n9;
            this.l = n10;
            InputDevice inputDevice = InputDevice.getDevice((int)n2);
            if (inputDevice != null && Build.VERSION.SDK_INT >= 19) {
                this.j = inputDevice.getVendorId();
                this.k = inputDevice.getProductId();
                return;
            }
            this.j = 0;
            this.k = 0;
        }

        public a(KeyEvent keyEvent, Character c2) {
            this(keyEvent.getDeviceId(), keyEvent.getFlags(), keyEvent.getUnicodeChar(0), keyEvent.getUnicodeChar(), keyEvent.getKeyCode(), c2, keyEvent.getScanCode(), keyEvent.getMetaState(), keyEvent.getSource(), keyEvent.getRepeatCount());
        }
    }

}


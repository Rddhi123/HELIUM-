/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.HashMap
 */
package io.flutter.embedding.engine.i;

import b.a.c.a.a;
import b.a.c.a.g;
import b.a.c.a.o;
import io.flutter.embedding.engine.FlutterJNI;
import io.flutter.view.c;
import java.util.HashMap;

public class a {
    public final b.a.c.a.a<Object> a;
    public final FlutterJNI b;
    private b c;
    private final a.d<Object> d = new a.d<Object>(){

        @Override
        public void a(Object object, a.e<Object> e2) {
            if (a.this.c == null) {
                return;
            }
            HashMap hashMap = (HashMap)object;
            String string = (String)hashMap.get((Object)"type");
            HashMap hashMap2 = (HashMap)hashMap.get((Object)"data");
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Received ");
            stringBuilder.append(string);
            stringBuilder.append(" message.");
            b.a.a.c("AccessibilityChannel", stringBuilder.toString());
            int n2 = -1;
            switch (string.hashCode()) {
                default: {
                    break;
                }
                case 114203431: {
                    if (!string.equals((Object)"longPress")) break;
                    n2 = 2;
                    break;
                }
                case 114595: {
                    if (!string.equals((Object)"tap")) break;
                    n2 = 1;
                    break;
                }
                case -649620375: {
                    if (!string.equals((Object)"announce")) break;
                    n2 = 0;
                    break;
                }
                case -1140076541: {
                    if (!string.equals((Object)"tooltip")) break;
                    n2 = 3;
                }
            }
            if (n2 != 0) {
                if (n2 != 1) {
                    if (n2 != 2) {
                        if (n2 != 3) {
                            return;
                        }
                        String string2 = (String)hashMap2.get((Object)"message");
                        if (string2 != null) {
                            a.this.c.a(string2);
                            return;
                        }
                    } else {
                        Integer n3 = (Integer)hashMap.get((Object)"nodeId");
                        if (n3 != null) {
                            a.this.c.b(n3);
                            return;
                        }
                    }
                } else {
                    Integer n4 = (Integer)hashMap.get((Object)"nodeId");
                    if (n4 != null) {
                        a.this.c.a(n4);
                        return;
                    }
                }
            } else {
                String string3 = (String)hashMap2.get((Object)"message");
                if (string3 != null) {
                    a.this.c.b(string3);
                }
            }
        }
    };

    public a(io.flutter.embedding.engine.e.a a2, FlutterJNI flutterJNI) {
        this.a = new b.a.c.a.a<Object>(a2, "flutter/accessibility", o.a);
        this.a.a((Object)this.d);
        this.b = flutterJNI;
    }

    public void a() {
        this.b.setSemanticsEnabled(false);
    }

    public void a(int n2) {
        this.b.setAccessibilityFeatures(n2);
    }

    public void a(int n2, c.f f2) {
        this.b.dispatchSemanticsAction(n2, f2);
    }

    public void a(int n2, c.f f2, Object object) {
        this.b.dispatchSemanticsAction(n2, f2, object);
    }

    public void a(b b2) {
        this.c = b2;
        this.b.setAccessibilityDelegate(b2);
    }

    public void b() {
        this.b.setSemanticsEnabled(true);
    }

    public static interface b
    extends FlutterJNI.a {
        public void a(int var1);

        public void a(String var1);

        public void b(int var1);

        public void b(String var1);
    }

}


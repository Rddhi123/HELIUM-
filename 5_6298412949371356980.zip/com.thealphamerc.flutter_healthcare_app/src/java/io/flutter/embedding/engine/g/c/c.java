/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.os.Bundle
 *  java.lang.Object
 */
package io.flutter.embedding.engine.g.c;

import android.os.Bundle;

public interface c {

    public static interface a {
        public void a(Bundle var1);

        public void b(Bundle var1);
    }

}


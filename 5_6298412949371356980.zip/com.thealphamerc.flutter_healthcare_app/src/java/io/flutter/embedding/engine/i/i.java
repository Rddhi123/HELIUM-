/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 */
package io.flutter.embedding.engine.i;

import b.a.c.a.a;
import b.a.c.a.b;
import b.a.c.a.d;
import b.a.c.a.g;
import java.util.HashMap;

public class i {
    public final a<Object> a;

    public i(io.flutter.embedding.engine.e.a a2) {
        this.a = new a<Object>(a2, "flutter/system", d.a);
    }

    public void a() {
        b.a.a.c("SystemChannel", "Sending memory pressure warning to Flutter.");
        HashMap hashMap = new HashMap(1);
        hashMap.put((Object)"type", (Object)"memoryPressure");
        this.a.a((Object)hashMap);
    }
}


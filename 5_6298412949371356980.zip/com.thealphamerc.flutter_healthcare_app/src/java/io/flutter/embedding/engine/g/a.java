/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  java.lang.Object
 */
package io.flutter.embedding.engine.g;

import android.content.Context;
import io.flutter.plugin.platform.f;
import io.flutter.view.e;

public interface a {
    public void a(b var1);

    public static interface a {
    }

    public static class b {
        public b(Context context, io.flutter.embedding.engine.a a2, b.a.c.a.b b2, e e2, f f2, a a3) {
        }
    }

}


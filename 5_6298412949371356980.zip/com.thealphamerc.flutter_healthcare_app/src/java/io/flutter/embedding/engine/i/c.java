/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 */
package io.flutter.embedding.engine.i;

import b.a.c.a.a;
import b.a.c.a.b;
import b.a.c.a.g;
import b.a.c.a.q;

public class c {
    public final a<String> a;

    public c(io.flutter.embedding.engine.e.a a2) {
        this.a = new a<String>(a2, "flutter/lifecycle", q.b);
    }

    public void a() {
        b.a.a.c("LifecycleChannel", "Sending AppLifecycleState.detached message.");
        this.a.a("AppLifecycleState.detached");
    }

    public void b() {
        b.a.a.c("LifecycleChannel", "Sending AppLifecycleState.inactive message.");
        this.a.a("AppLifecycleState.inactive");
    }

    public void c() {
        b.a.a.c("LifecycleChannel", "Sending AppLifecycleState.paused message.");
        this.a.a("AppLifecycleState.paused");
    }

    public void d() {
        b.a.a.c("LifecycleChannel", "Sending AppLifecycleState.resumed message.");
        this.a.a("AppLifecycleState.resumed");
    }
}


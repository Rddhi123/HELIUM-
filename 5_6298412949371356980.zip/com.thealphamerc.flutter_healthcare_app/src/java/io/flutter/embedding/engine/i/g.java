/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.PrintWriter
 *  java.io.StringWriter
 *  java.io.Writer
 *  java.lang.Double
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Number
 *  java.lang.Object
 *  java.lang.Runnable
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.nio.ByteBuffer
 *  java.util.List
 *  java.util.Map
 */
package io.flutter.embedding.engine.i;

import b.a.c.a.h;
import b.a.c.a.i;
import b.a.c.a.j;
import b.a.c.a.p;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.ByteBuffer;
import java.util.List;
import java.util.Map;

public class g {
    private final i a;
    private e b;
    private final i.c c = new i.c(){

        private void b(h h2, i.d d2) {
            int n2 = (Integer)h2.a();
            try {
                g.this.b.b(n2);
                d2.a(null);
                return;
            }
            catch (IllegalStateException illegalStateException) {
                d2.a("error", g.b((Exception)((Object)illegalStateException)), null);
                return;
            }
        }

        private void c(h h2, i.d d2) {
            Map map = (Map)h2.a();
            int n2 = (Integer)map.get((Object)"id");
            String string = (String)map.get((Object)"viewType");
            double d3 = (Double)map.get((Object)"width");
            double d4 = (Double)map.get((Object)"height");
            int n3 = (Integer)map.get((Object)"direction");
            ByteBuffer byteBuffer = map.containsKey((Object)"params") ? ByteBuffer.wrap((byte[])((byte[])map.get((Object)"params"))) : null;
            b b2 = new b(n2, string, d3, d4, n3, byteBuffer);
            try {
                d2.a(g.this.b.a(b2));
                return;
            }
            catch (IllegalStateException illegalStateException) {
                d2.a("error", g.b((Exception)((Object)illegalStateException)), null);
                return;
            }
        }

        private void d(h h2, i.d d2) {
            int n2 = (Integer)h2.a();
            try {
                g.this.b.a(n2);
                d2.a(null);
                return;
            }
            catch (IllegalStateException illegalStateException) {
                d2.a("error", g.b((Exception)((Object)illegalStateException)), null);
                return;
            }
        }

        private void e(h h2, final i.d d2) {
            Map map = (Map)h2.a();
            c c2 = new c((Integer)map.get((Object)"id"), (Double)map.get((Object)"width"), (Double)map.get((Object)"height"));
            try {
                g.this.b.a(c2, new Runnable(this){

                    public void run() {
                        d2.a(null);
                    }
                });
                return;
            }
            catch (IllegalStateException illegalStateException) {
                d2.a("error", g.b((Exception)((Object)illegalStateException)), null);
                return;
            }
        }

        private void f(h h2, i.d d2) {
            Map map = (Map)h2.a();
            int n2 = (Integer)map.get((Object)"id");
            int n3 = (Integer)map.get((Object)"direction");
            try {
                g.this.b.a(n2, n3);
                d2.a(null);
                return;
            }
            catch (IllegalStateException illegalStateException) {
                d2.a("error", g.b((Exception)((Object)illegalStateException)), null);
                return;
            }
        }

        /*
         * Loose catch block
         * Enabled aggressive block sorting
         * Enabled unnecessary exception pruning
         * Enabled aggressive exception aggregation
         * Lifted jumps to return sites
         */
        private void g(h h2, i.d d2) {
            i.d d3;
            void var5_8;
            block4 : {
                List list = (List)h2.a();
                d d4 = new d((Integer)list.get(0), (Number)list.get(1), (Number)list.get(2), (Integer)list.get(3), (Integer)list.get(4), list.get(5), list.get(6), (Integer)list.get(7), (Integer)list.get(8), (float)((Double)list.get(9)).doubleValue(), (float)((Double)list.get(10)).doubleValue(), (Integer)list.get(11), (Integer)list.get(12), (Integer)list.get(13), (Integer)list.get(14));
                g.this.b.a(d4);
                d3 = d2;
                try {
                    d3.a(null);
                    return;
                }
                catch (IllegalStateException illegalStateException) {}
                break block4;
                catch (IllegalStateException illegalStateException) {
                    d3 = d2;
                }
            }
            d3.a("error", g.b((Exception)var5_8), null);
        }

        @Override
        public void a(h h2, i.d d2) {
            if (g.this.b == null) {
                return;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Received '");
            stringBuilder.append(h2.a);
            stringBuilder.append("' message.");
            b.a.a.c("PlatformViewsChannel", stringBuilder.toString());
            String string = h2.a;
            int n2 = -1;
            switch (string.hashCode()) {
                default: {
                    break;
                }
                case 1671767583: {
                    if (!string.equals((Object)"dispose")) break;
                    n2 = 1;
                    break;
                }
                case 576796989: {
                    if (!string.equals((Object)"setDirection")) break;
                    n2 = 4;
                    break;
                }
                case 110550847: {
                    if (!string.equals((Object)"touch")) break;
                    n2 = 3;
                    break;
                }
                case -756050293: {
                    if (!string.equals((Object)"clearFocus")) break;
                    n2 = 5;
                    break;
                }
                case -934437708: {
                    if (!string.equals((Object)"resize")) break;
                    n2 = 2;
                    break;
                }
                case -1352294148: {
                    if (!string.equals((Object)"create")) break;
                    n2 = 0;
                }
            }
            if (n2 != 0) {
                if (n2 != 1) {
                    if (n2 != 2) {
                        if (n2 != 3) {
                            if (n2 != 4) {
                                if (n2 != 5) {
                                    d2.a();
                                    return;
                                }
                                this.b(h2, d2);
                                return;
                            }
                            this.f(h2, d2);
                            return;
                        }
                        this.g(h2, d2);
                        return;
                    }
                    this.e(h2, d2);
                    return;
                }
                this.d(h2, d2);
                return;
            }
            this.c(h2, d2);
        }

    };

    public g(io.flutter.embedding.engine.e.a a2) {
        this.a = new i(a2, "flutter/platform_views", p.b);
        this.a.a(this.c);
    }

    private static String b(Exception exception) {
        StringWriter stringWriter = new StringWriter();
        exception.printStackTrace(new PrintWriter((Writer)stringWriter));
        return stringWriter.toString();
    }

    public void a(int n2) {
        i i2 = this.a;
        if (i2 == null) {
            return;
        }
        i2.a("viewFocused", n2);
    }

    public void a(e e2) {
        this.b = e2;
    }

    public static class b {
        public final int a;
        public final String b;
        public final double c;
        public final double d;
        public final int e;
        public final ByteBuffer f;

        public b(int n2, String string, double d2, double d3, int n3, ByteBuffer byteBuffer) {
            this.a = n2;
            this.b = string;
            this.c = d2;
            this.d = d3;
            this.e = n3;
            this.f = byteBuffer;
        }
    }

    public static class c {
        public final int a;
        public final double b;
        public final double c;

        public c(int n2, double d2, double d3) {
            this.a = n2;
            this.b = d2;
            this.c = d3;
        }
    }

    public static class d {
        public final int a;
        public final Number b;
        public final Number c;
        public final int d;
        public final int e;
        public final Object f;
        public final Object g;
        public final int h;
        public final int i;
        public final float j;
        public final float k;
        public final int l;
        public final int m;
        public final int n;
        public final int o;

        d(int n2, Number number, Number number2, int n3, int n4, Object object, Object object2, int n5, int n6, float f2, float f3, int n7, int n8, int n9, int n10) {
            this.a = n2;
            this.b = number;
            this.c = number2;
            this.d = n3;
            this.e = n4;
            this.f = object;
            this.g = object2;
            this.h = n5;
            this.i = n6;
            this.j = f2;
            this.k = f3;
            this.l = n7;
            this.m = n8;
            this.n = n9;
            this.o = n10;
        }
    }

    public static interface e {
        public long a(b var1);

        public void a(int var1);

        public void a(int var1, int var2);

        public void a(c var1, Runnable var2);

        public void a(d var1);

        public void b(int var1);
    }

}


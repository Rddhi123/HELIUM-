/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.pm.ApplicationInfo
 *  android.content.pm.PackageManager
 *  android.content.pm.PackageManager$NameNotFoundException
 *  android.os.Bundle
 *  android.os.Looper
 *  android.os.SystemClock
 *  android.util.Log
 *  android.view.WindowManager
 *  java.io.File
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.System
 *  java.lang.Throwable
 *  java.util.ArrayList
 *  java.util.Collection
 *  java.util.Collections
 */
package io.flutter.embedding.engine.f;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;
import android.view.WindowManager;
import io.flutter.embedding.engine.FlutterJNI;
import io.flutter.embedding.engine.f.b;
import io.flutter.embedding.engine.f.c;
import io.flutter.view.f;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class a {
    private static final String f;
    private static final String g;
    private static final String h;
    private static final String i;
    private static a j;
    private String a = "libapp.so";
    private String b = "flutter_assets";
    private boolean c = false;
    private c d;
    private a e;

    static {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(a.class.getName());
        stringBuilder.append('.');
        stringBuilder.append("aot-shared-library-name");
        f = stringBuilder.toString();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(a.class.getName());
        stringBuilder2.append('.');
        stringBuilder2.append("vm-snapshot-data");
        g = stringBuilder2.toString();
        StringBuilder stringBuilder3 = new StringBuilder();
        stringBuilder3.append(a.class.getName());
        stringBuilder3.append('.');
        stringBuilder3.append("isolate-snapshot-data");
        h = stringBuilder3.toString();
        StringBuilder stringBuilder4 = new StringBuilder();
        stringBuilder4.append(a.class.getName());
        stringBuilder4.append('.');
        stringBuilder4.append("flutter-assets-dir");
        i = stringBuilder4.toString();
    }

    private ApplicationInfo b(Context context) {
        try {
            ApplicationInfo applicationInfo = context.getPackageManager().getApplicationInfo(context.getPackageName(), 128);
            return applicationInfo;
        }
        catch (PackageManager.NameNotFoundException nameNotFoundException) {
            throw new RuntimeException((Throwable)nameNotFoundException);
        }
    }

    public static a b() {
        if (j == null) {
            j = new a();
        }
        return j;
    }

    private void c(Context context) {
        Bundle bundle = this.b((Context)context).metaData;
        if (bundle == null) {
            return;
        }
        this.a = bundle.getString(f, "libapp.so");
        this.b = bundle.getString(i, "flutter_assets");
        bundle.getString(g, "vm_snapshot_data");
        bundle.getString(h, "isolate_snapshot_data");
    }

    private void d(Context context) {
        new b(context).a();
    }

    public String a() {
        return this.b;
    }

    public void a(Context context) {
        this.a(context, new a());
    }

    public void a(Context context, a a2) {
        if (this.e != null) {
            return;
        }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            this.e = a2;
            long l2 = SystemClock.uptimeMillis();
            this.c(context);
            this.d(context);
            System.loadLibrary((String)"flutter");
            f.a((WindowManager)context.getSystemService("window")).a();
            FlutterJNI.nativeRecordStartTimestamp(SystemClock.uptimeMillis() - l2);
            return;
        }
        throw new IllegalStateException("startInitialization must be called on the main thread");
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    public void a(Context context, String[] arrstring) {
        if (this.c) {
            return;
        }
        if (Looper.myLooper() != Looper.getMainLooper()) {
            throw new IllegalStateException("ensureInitializationComplete must be called on the main thread");
        }
        if (this.e == null) {
            throw new IllegalStateException("ensureInitializationComplete must be called after startInitialization");
        }
        try {
            if (this.d == null) {
                ArrayList arrayList = new ArrayList();
                arrayList.add((Object)"--icu-symbol-prefix=_binary_icudtl_dat");
                ApplicationInfo applicationInfo = this.b(context);
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("--icu-native-lib-path=");
                stringBuilder.append(applicationInfo.nativeLibraryDir);
                stringBuilder.append(File.separator);
                stringBuilder.append("libflutter.so");
                arrayList.add((Object)stringBuilder.toString());
                if (arrstring != null) {
                    Collections.addAll((Collection)arrayList, (Object[])arrstring);
                }
                StringBuilder stringBuilder2 = new StringBuilder();
                stringBuilder2.append("--aot-shared-library-name=");
                stringBuilder2.append(this.a);
                arrayList.add((Object)stringBuilder2.toString());
                StringBuilder stringBuilder3 = new StringBuilder();
                stringBuilder3.append("--aot-shared-library-name=");
                stringBuilder3.append(applicationInfo.nativeLibraryDir);
                stringBuilder3.append(File.separator);
                stringBuilder3.append(this.a);
                arrayList.add((Object)stringBuilder3.toString());
                StringBuilder stringBuilder4 = new StringBuilder();
                stringBuilder4.append("--cache-dir-path=");
                stringBuilder4.append(b.a.d.a.a(context));
                arrayList.add((Object)stringBuilder4.toString());
                if (this.e.a() != null) {
                    StringBuilder stringBuilder5 = new StringBuilder();
                    stringBuilder5.append("--log-tag=");
                    stringBuilder5.append(this.e.a());
                    arrayList.add((Object)stringBuilder5.toString());
                }
                String string = b.a.d.a.b(context);
                String string2 = b.a.d.a.a(context);
                FlutterJNI.nativeInit(context, (String[])arrayList.toArray((Object[])new String[0]), null, string, string2);
                this.c = true;
                return;
            }
            this.d.a();
        }
        catch (Exception exception) {
            Log.e((String)"FlutterLoader", (String)"Flutter initialization failed.", (Throwable)exception);
            throw new RuntimeException((Throwable)exception);
        }
        throw null;
    }

    public static class a {
        private String a;

        public String a() {
            return this.a;
        }
    }

}


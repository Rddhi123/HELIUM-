/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.io.Serializable
 *  java.lang.Enum
 *  java.lang.Integer
 *  java.lang.NoSuchFieldException
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.Arrays
 *  java.util.HashMap
 *  org.json.JSONArray
 *  org.json.JSONException
 *  org.json.JSONObject
 */
package io.flutter.embedding.engine.i;

import b.a.c.a.h;
import b.a.c.a.i;
import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class j {
    public final i a;
    private f b;
    private final i.c c = new i.c(){

        @Override
        public void a(h h2, i.d d2) {
            block20 : {
                block15 : {
                    block16 : {
                        String string;
                        block21 : {
                            Object object;
                            void var10_16;
                            block17 : {
                                block18 : {
                                    block19 : {
                                        if (j.this.b == null) {
                                            return;
                                        }
                                        String string2 = h2.a;
                                        object = h2.b;
                                        StringBuilder stringBuilder = new StringBuilder();
                                        stringBuilder.append("Received '");
                                        stringBuilder.append(string2);
                                        stringBuilder.append("' message.");
                                        b.a.a.c("TextInputChannel", stringBuilder.toString());
                                        int n2 = -1;
                                        switch (string2.hashCode()) {
                                            default: {
                                                break;
                                            }
                                            case 1904427655: {
                                                if (!string2.equals((Object)"TextInput.clearClient")) break;
                                                n2 = 5;
                                                break;
                                            }
                                            case 270803918: {
                                                if (!string2.equals((Object)"TextInput.show")) break;
                                                n2 = 0;
                                                break;
                                            }
                                            case 270476819: {
                                                if (!string2.equals((Object)"TextInput.hide")) break;
                                                n2 = 1;
                                                break;
                                            }
                                            case -37561188: {
                                                if (!string2.equals((Object)"TextInput.setClient")) break;
                                                n2 = 2;
                                                break;
                                            }
                                            case -1015421462: {
                                                if (!string2.equals((Object)"TextInput.setEditingState")) break;
                                                n2 = 4;
                                                break;
                                            }
                                            case -1779068172: {
                                                if (!string2.equals((Object)"TextInput.setPlatformViewClient")) break;
                                                n2 = 3;
                                            }
                                        }
                                        if (n2 == 0) break block15;
                                        if (n2 == 1) break block16;
                                        if (n2 == 2) break block17;
                                        if (n2 == 3) break block18;
                                        if (n2 == 4) break block19;
                                        if (n2 != 5) {
                                            d2.a();
                                            return;
                                        }
                                        j.this.b.b();
                                        break block20;
                                    }
                                    try {
                                        JSONObject jSONObject = (JSONObject)object;
                                        j.this.b.a(e.a(jSONObject));
                                        d2.a(null);
                                        return;
                                    }
                                    catch (JSONException jSONException) {
                                        string = jSONException.getMessage();
                                    }
                                    break block21;
                                }
                                int n3 = (Integer)object;
                                j.this.b.a(n3);
                                return;
                            }
                            try {
                                JSONArray jSONArray = (JSONArray)object;
                                int n4 = jSONArray.getInt(0);
                                JSONObject jSONObject = jSONArray.getJSONObject(1);
                                j.this.b.a(n4, b.a(jSONObject));
                                d2.a(null);
                                return;
                            }
                            catch (NoSuchFieldException noSuchFieldException) {
                            }
                            catch (JSONException jSONException) {
                                // empty catch block
                            }
                            string = var10_16.getMessage();
                        }
                        d2.a("error", string, null);
                        return;
                    }
                    j.this.b.a();
                    break block20;
                }
                j.this.b.c();
            }
            d2.a(null);
        }
    };

    public j(io.flutter.embedding.engine.e.a a2) {
        this.a = new i(a2, "flutter/textinput", b.a.c.a.e.a);
        this.a.a(this.c);
    }

    public void a() {
        this.a.a("TextInputClient.requestExistingInputState", null);
    }

    public void a(int n2) {
        b.a.a.c("TextInputChannel", "Sending 'done' message.");
        i i2 = this.a;
        Object[] arrobject = new Serializable[]{Integer.valueOf((int)n2), "TextInputAction.done"};
        i2.a("TextInputClient.performAction", (Object)Arrays.asList((Object[])arrobject));
    }

    public void a(int n2, String string, int n3, int n4, int n5, int n6) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Sending message to update editing state: \nText: ");
        stringBuilder.append(string);
        stringBuilder.append("\nSelection start: ");
        stringBuilder.append(n3);
        stringBuilder.append("\nSelection end: ");
        stringBuilder.append(n4);
        stringBuilder.append("\nComposing start: ");
        stringBuilder.append(n5);
        stringBuilder.append("\nComposing end: ");
        stringBuilder.append(n6);
        b.a.a.c("TextInputChannel", stringBuilder.toString());
        HashMap hashMap = new HashMap();
        hashMap.put((Object)"text", (Object)string);
        hashMap.put((Object)"selectionBase", (Object)n3);
        hashMap.put((Object)"selectionExtent", (Object)n4);
        hashMap.put((Object)"composingBase", (Object)n5);
        hashMap.put((Object)"composingExtent", (Object)n6);
        i i2 = this.a;
        Object[] arrobject = new Serializable[]{Integer.valueOf((int)n2), hashMap};
        i2.a("TextInputClient.updateEditingState", (Object)Arrays.asList((Object[])arrobject));
    }

    public void a(f f2) {
        this.b = f2;
    }

    public void b(int n2) {
        b.a.a.c("TextInputChannel", "Sending 'go' message.");
        i i2 = this.a;
        Object[] arrobject = new Serializable[]{Integer.valueOf((int)n2), "TextInputAction.go"};
        i2.a("TextInputClient.performAction", (Object)Arrays.asList((Object[])arrobject));
    }

    public void c(int n2) {
        b.a.a.c("TextInputChannel", "Sending 'newline' message.");
        i i2 = this.a;
        Object[] arrobject = new Serializable[]{Integer.valueOf((int)n2), "TextInputAction.newline"};
        i2.a("TextInputClient.performAction", (Object)Arrays.asList((Object[])arrobject));
    }

    public void d(int n2) {
        b.a.a.c("TextInputChannel", "Sending 'next' message.");
        i i2 = this.a;
        Object[] arrobject = new Serializable[]{Integer.valueOf((int)n2), "TextInputAction.next"};
        i2.a("TextInputClient.performAction", (Object)Arrays.asList((Object[])arrobject));
    }

    public void e(int n2) {
        b.a.a.c("TextInputChannel", "Sending 'previous' message.");
        i i2 = this.a;
        Object[] arrobject = new Serializable[]{Integer.valueOf((int)n2), "TextInputAction.previous"};
        i2.a("TextInputClient.performAction", (Object)Arrays.asList((Object[])arrobject));
    }

    public void f(int n2) {
        b.a.a.c("TextInputChannel", "Sending 'search' message.");
        i i2 = this.a;
        Object[] arrobject = new Serializable[]{Integer.valueOf((int)n2), "TextInputAction.search"};
        i2.a("TextInputClient.performAction", (Object)Arrays.asList((Object[])arrobject));
    }

    public void g(int n2) {
        b.a.a.c("TextInputChannel", "Sending 'send' message.");
        i i2 = this.a;
        Object[] arrobject = new Serializable[]{Integer.valueOf((int)n2), "TextInputAction.send"};
        i2.a("TextInputClient.performAction", (Object)Arrays.asList((Object[])arrobject));
    }

    public void h(int n2) {
        b.a.a.c("TextInputChannel", "Sending 'unspecified' message.");
        i i2 = this.a;
        Object[] arrobject = new Serializable[]{Integer.valueOf((int)n2), "TextInputAction.unspecified"};
        i2.a("TextInputClient.performAction", (Object)Arrays.asList((Object[])arrobject));
    }

    public static class b {
        public final boolean a;
        public final boolean b;
        public final boolean c;
        public final d d;
        public final c e;
        public final Integer f;
        public final String g;

        public b(boolean bl, boolean bl2, boolean bl3, d d2, c c2, Integer n2, String string) {
            this.a = bl;
            this.b = bl2;
            this.c = bl3;
            this.d = d2;
            this.e = c2;
            this.f = n2;
            this.g = string;
        }

        public static b a(JSONObject jSONObject) {
            String string = jSONObject.getString("inputAction");
            if (string != null) {
                Integer n2 = b.a(string);
                boolean bl = jSONObject.optBoolean("obscureText");
                boolean bl2 = jSONObject.optBoolean("autocorrect", true);
                boolean bl3 = jSONObject.optBoolean("enableSuggestions");
                d d2 = d.a(jSONObject.getString("textCapitalization"));
                c c2 = c.a(jSONObject.getJSONObject("inputType"));
                String string2 = jSONObject.isNull("actionLabel") ? null : jSONObject.getString("actionLabel");
                b b2 = new b(bl, bl2, bl3, d2, c2, n2, string2);
                return b2;
            }
            throw new JSONException("Configuration JSON missing 'inputAction' property.");
        }

        private static Integer a(String string) {
            int n2;
            Integer n3;
            Integer n4;
            block21 : {
                int n5 = string.hashCode();
                n4 = 1;
                n3 = 0;
                switch (n5) {
                    default: {
                        break;
                    }
                    case 2110497650: {
                        if (!string.equals((Object)"TextInputAction.previous")) break;
                        n2 = 8;
                        break block21;
                    }
                    case 1539450297: {
                        if (!string.equals((Object)"TextInputAction.newline")) break;
                        n2 = 0;
                        break block21;
                    }
                    case 1241689507: {
                        if (!string.equals((Object)"TextInputAction.go")) break;
                        n2 = 4;
                        break block21;
                    }
                    case 469250275: {
                        if (!string.equals((Object)"TextInputAction.search")) break;
                        n2 = 5;
                        break block21;
                    }
                    case -736940669: {
                        if (!string.equals((Object)"TextInputAction.send")) break;
                        n2 = 6;
                        break block21;
                    }
                    case -737080013: {
                        if (!string.equals((Object)"TextInputAction.none")) break;
                        n2 = 1;
                        break block21;
                    }
                    case -737089298: {
                        if (!string.equals((Object)"TextInputAction.next")) break;
                        n2 = 7;
                        break block21;
                    }
                    case -737377923: {
                        if (!string.equals((Object)"TextInputAction.done")) break;
                        n2 = 3;
                        break block21;
                    }
                    case -810971940: {
                        if (!string.equals((Object)"TextInputAction.unspecified")) break;
                        n2 = 2;
                        break block21;
                    }
                }
                n2 = -1;
            }
            switch (n2) {
                default: {
                    return n3;
                }
                case 8: {
                    return 7;
                }
                case 7: {
                    return 5;
                }
                case 6: {
                    return 4;
                }
                case 5: {
                    return 3;
                }
                case 4: {
                    return 2;
                }
                case 3: {
                    return 6;
                }
                case 2: {
                    return n3;
                }
                case 0: 
                case 1: 
            }
            return n4;
        }
    }

    public static class c {
        public final g a;
        public final boolean b;
        public final boolean c;

        public c(g g2, boolean bl, boolean bl2) {
            this.a = g2;
            this.b = bl;
            this.c = bl2;
        }

        public static c a(JSONObject jSONObject) {
            return new c(g.a(jSONObject.getString("name")), jSONObject.optBoolean("signed", false), jSONObject.optBoolean("decimal", false));
        }
    }

    public static final class d
    extends Enum<d> {
        public static final /* enum */ d b = new d("TextCapitalization.characters");
        public static final /* enum */ d c = new d("TextCapitalization.words");
        public static final /* enum */ d d = new d("TextCapitalization.sentences");
        public static final /* enum */ d e = new d("TextCapitalization.none");
        private static final /* synthetic */ d[] f;
        private final String a;

        static {
            d[] arrd = new d[]{b, c, d, e};
            f = arrd;
        }

        private d(String string2) {
            this.a = string2;
        }

        static d a(String string) {
            NoSuchFieldException noSuchFieldException;
            for (d d2 : d.values()) {
                if (!d2.a.equals((Object)string)) continue;
                return d2;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("No such TextCapitalization: ");
            stringBuilder.append(string);
            noSuchFieldException = new NoSuchFieldException(stringBuilder.toString());
            throw noSuchFieldException;
        }

        public static d valueOf(String string) {
            return (d)Enum.valueOf(d.class, (String)string);
        }

        public static d[] values() {
            return (d[])f.clone();
        }
    }

    public static class e {
        public final String a;
        public final int b;
        public final int c;

        public e(String string, int n2, int n3) {
            this.a = string;
            this.b = n2;
            this.c = n3;
        }

        public static e a(JSONObject jSONObject) {
            return new e(jSONObject.getString("text"), jSONObject.getInt("selectionBase"), jSONObject.getInt("selectionExtent"));
        }
    }

    public static interface f {
        public void a();

        public void a(int var1);

        public void a(int var1, b var2);

        public void a(e var1);

        public void b();

        public void c();
    }

    public static final class g
    extends Enum<g> {
        public static final /* enum */ g b = new g("TextInputType.text");
        public static final /* enum */ g c = new g("TextInputType.datetime");
        public static final /* enum */ g d = new g("TextInputType.number");
        public static final /* enum */ g e = new g("TextInputType.phone");
        public static final /* enum */ g f = new g("TextInputType.multiline");
        public static final /* enum */ g g = new g("TextInputType.emailAddress");
        public static final /* enum */ g h = new g("TextInputType.url");
        public static final /* enum */ g i = new g("TextInputType.visiblePassword");
        private static final /* synthetic */ g[] j;
        private final String a;

        static {
            g[] arrg = new g[]{b, c, d, e, f, g, h, i};
            j = arrg;
        }

        private g(String string2) {
            this.a = string2;
        }

        static g a(String string) {
            NoSuchFieldException noSuchFieldException;
            for (g g2 : g.values()) {
                if (!g2.a.equals((Object)string)) continue;
                return g2;
            }
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("No such TextInputType: ");
            stringBuilder.append(string);
            noSuchFieldException = new NoSuchFieldException(stringBuilder.toString());
            throw noSuchFieldException;
        }

        public static g valueOf(String string) {
            return (g)Enum.valueOf(g.class, (String)string);
        }

        public static g[] values() {
            return (g[])j.clone();
        }
    }

}


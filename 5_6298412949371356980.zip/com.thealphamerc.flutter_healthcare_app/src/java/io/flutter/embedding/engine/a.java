/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.AssetManager
 *  java.lang.Class
 *  java.lang.Exception
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.reflect.Method
 *  java.util.HashSet
 *  java.util.Iterator
 *  java.util.Set
 */
package io.flutter.embedding.engine;

import android.content.Context;
import android.content.res.AssetManager;
import io.flutter.embedding.engine.FlutterJNI;
import io.flutter.embedding.engine.i.c;
import io.flutter.embedding.engine.i.d;
import io.flutter.embedding.engine.i.e;
import io.flutter.embedding.engine.i.f;
import io.flutter.embedding.engine.i.h;
import io.flutter.embedding.engine.i.i;
import io.flutter.embedding.engine.i.j;
import java.lang.reflect.Method;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class a {
    private final FlutterJNI a;
    private final io.flutter.embedding.engine.h.a b;
    private final io.flutter.embedding.engine.e.a c;
    private final io.flutter.embedding.engine.c d;
    private final io.flutter.embedding.engine.i.a e;
    private final io.flutter.embedding.engine.i.b f;
    private final c g;
    private final d h;
    private final e i;
    private final f j;
    private final h k;
    private final i l;
    private final io.flutter.plugin.platform.i m;
    private final Set<b> n = new HashSet();
    private final b o = new b(){

        @Override
        public void a() {
            b.a.a.c("FlutterEngine", "onPreEngineRestart()");
            Iterator iterator = a.this.n.iterator();
            while (iterator.hasNext()) {
                ((b)iterator.next()).a();
            }
        }
    };

    public a(Context context, io.flutter.embedding.engine.f.a a2, FlutterJNI flutterJNI, String[] arrstring, boolean bl) {
        this.a = flutterJNI;
        a2.a(context);
        a2.a(context, arrstring);
        flutterJNI.addEngineLifecycleListener(this.o);
        this.n();
        this.c = new io.flutter.embedding.engine.e.a(flutterJNI, context.getAssets());
        this.c.c();
        this.b = new io.flutter.embedding.engine.h.a(flutterJNI);
        this.e = new io.flutter.embedding.engine.i.a(this.c, flutterJNI);
        this.f = new io.flutter.embedding.engine.i.b(this.c);
        this.g = new c(this.c);
        this.h = new d(this.c);
        this.i = new e(this.c);
        this.j = new f(this.c);
        this.k = new h(this.c);
        this.l = new i(this.c);
        new j(this.c);
        this.m = new io.flutter.plugin.platform.i();
        this.d = new io.flutter.embedding.engine.c(context.getApplicationContext(), this, a2);
        if (bl) {
            this.p();
        }
    }

    public a(Context context, String[] arrstring) {
        this(context, io.flutter.embedding.engine.f.a.b(), new FlutterJNI(), arrstring, true);
    }

    private void n() {
        b.a.a.c("FlutterEngine", "Attaching to JNI.");
        this.a.attachToNative(false);
        if (this.o()) {
            return;
        }
        throw new RuntimeException("FlutterEngine failed to attach to its native Object reference.");
    }

    private boolean o() {
        return this.a.isAttached();
    }

    private void p() {
        try {
            Class.forName((String)"io.flutter.plugins.GeneratedPluginRegistrant").getDeclaredMethod("registerWith", new Class[]{a.class}).invoke(null, new Object[]{this});
            return;
        }
        catch (Exception exception) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Tried to automatically register plugins with FlutterEngine (");
            stringBuilder.append((Object)this);
            stringBuilder.append(") but could not find and invoke the GeneratedPluginRegistrant.");
            b.a.a.d("FlutterEngine", stringBuilder.toString());
            return;
        }
    }

    public void a() {
        b.a.a.a("FlutterEngine", "Destroying.");
        this.d.d();
        this.c.d();
        this.a.removeEngineLifecycleListener(this.o);
        this.a.detachFromNativeAndReleaseResources();
    }

    public io.flutter.embedding.engine.i.a b() {
        return this.e;
    }

    public io.flutter.embedding.engine.g.c.b c() {
        return this.d;
    }

    public io.flutter.embedding.engine.e.a d() {
        return this.c;
    }

    public io.flutter.embedding.engine.i.b e() {
        return this.f;
    }

    public c f() {
        return this.g;
    }

    public d g() {
        return this.h;
    }

    public e h() {
        return this.i;
    }

    public f i() {
        return this.j;
    }

    public io.flutter.plugin.platform.i j() {
        return this.m;
    }

    public io.flutter.embedding.engine.h.a k() {
        return this.b;
    }

    public h l() {
        return this.k;
    }

    public i m() {
        return this.l;
    }

    public static interface b {
        public void a();
    }

}


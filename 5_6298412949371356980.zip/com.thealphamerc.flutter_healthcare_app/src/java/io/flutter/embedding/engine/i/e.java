/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 */
package io.flutter.embedding.engine.i;

import b.a.a;
import b.a.c.a.b;
import b.a.c.a.i;
import b.a.c.a.j;

public class e {
    public final i a;

    public e(io.flutter.embedding.engine.e.a a2) {
        this.a = new i(a2, "flutter/navigation", b.a.c.a.e.a);
    }

    public void a() {
        a.c("NavigationChannel", "Sending message to pop route.");
        this.a.a("popRoute", null);
    }

    public void a(String string) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Sending message to set initial route to '");
        stringBuilder.append(string);
        stringBuilder.append("'");
        a.c("NavigationChannel", stringBuilder.toString());
        this.a.a("setInitialRoute", string);
    }
}


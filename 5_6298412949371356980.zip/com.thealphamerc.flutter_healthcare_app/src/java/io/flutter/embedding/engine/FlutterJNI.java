/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.content.Context
 *  android.content.res.AssetManager
 *  android.graphics.Bitmap
 *  android.graphics.SurfaceTexture
 *  android.os.Looper
 *  android.view.Surface
 *  androidx.annotation.Keep
 *  java.lang.IllegalStateException
 *  java.lang.Long
 *  java.lang.Object
 *  java.lang.RuntimeException
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.lang.Thread
 *  java.nio.ByteBuffer
 *  java.util.Iterator
 *  java.util.Set
 *  java.util.concurrent.CopyOnWriteArraySet
 */
package io.flutter.embedding.engine;

import android.content.Context;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.SurfaceTexture;
import android.os.Looper;
import android.view.Surface;
import androidx.annotation.Keep;
import b.a.c.a.o;
import io.flutter.embedding.engine.a;
import io.flutter.embedding.engine.e.c;
import io.flutter.view.FlutterCallbackInformation;
import io.flutter.view.c;
import java.nio.ByteBuffer;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArraySet;

@Keep
public class FlutterJNI {
    private static final String TAG = "FlutterJNI";
    private static b asyncWaitForVsyncDelegate;
    private static String observatoryUri;
    private static float refreshRateFPS;
    private a accessibilityDelegate;
    private final Set<a.b> engineLifecycleListeners = new CopyOnWriteArraySet();
    private final Set<io.flutter.embedding.engine.h.b> flutterUiDisplayListeners = new CopyOnWriteArraySet();
    private final Looper mainLooper = Looper.getMainLooper();
    private Long nativePlatformViewId;
    private c platformMessageHandler;

    private static void asyncWaitForVsync(long l2) {
        b b2 = asyncWaitForVsyncDelegate;
        if (b2 != null) {
            b2.a(l2);
            return;
        }
        throw new IllegalStateException("An AsyncWaitForVsyncDelegate must be registered with FlutterJNI before asyncWaitForVsync() is invoked.");
    }

    private void ensureAttachedToNative() {
        if (this.nativePlatformViewId != null) {
            return;
        }
        throw new RuntimeException("Cannot execute operation because FlutterJNI is not attached to native.");
    }

    private void ensureNotAttachedToNative() {
        if (this.nativePlatformViewId == null) {
            return;
        }
        throw new RuntimeException("Cannot execute operation because FlutterJNI is attached to native.");
    }

    private void ensureRunningOnMainThread() {
        if (Looper.myLooper() == this.mainLooper) {
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Methods marked with @UiThread must be executed on the main thread. Current thread: ");
        stringBuilder.append(Thread.currentThread().getName());
        throw new RuntimeException(stringBuilder.toString());
    }

    public static String getObservatoryUri() {
        return observatoryUri;
    }

    private void handlePlatformMessage(String string, byte[] arrby, int n2) {
        c c2 = this.platformMessageHandler;
        if (c2 != null) {
            c2.a(string, arrby, n2);
        }
    }

    private void handlePlatformMessageResponse(int n2, byte[] arrby) {
        c c2 = this.platformMessageHandler;
        if (c2 != null) {
            c2.a(n2, arrby);
        }
    }

    private native long nativeAttach(FlutterJNI var1, boolean var2);

    private native void nativeDestroy(long var1);

    private native void nativeDispatchEmptyPlatformMessage(long var1, String var3, int var4);

    private native void nativeDispatchPlatformMessage(long var1, String var3, ByteBuffer var4, int var5, int var6);

    private native void nativeDispatchPointerDataPacket(long var1, ByteBuffer var3, int var4);

    private native void nativeDispatchSemanticsAction(long var1, int var3, int var4, ByteBuffer var5, int var6);

    private native Bitmap nativeGetBitmap(long var1);

    public static native void nativeInit(Context var0, String[] var1, String var2, String var3, String var4);

    private native void nativeInvokePlatformMessageEmptyResponseCallback(long var1, int var3);

    private native void nativeInvokePlatformMessageResponseCallback(long var1, int var3, ByteBuffer var4, int var5);

    public static native FlutterCallbackInformation nativeLookupCallbackInformation(long var0);

    private native void nativeMarkTextureFrameAvailable(long var1, long var3);

    public static native void nativeOnVsync(long var0, long var2, long var4);

    public static native void nativeRecordStartTimestamp(long var0);

    private native void nativeRegisterTexture(long var1, long var3, SurfaceTexture var5);

    private native void nativeRunBundleAndSnapshotFromLibrary(long var1, String var3, String var4, String var5, AssetManager var6);

    private native void nativeSetAccessibilityFeatures(long var1, int var3);

    private native void nativeSetSemanticsEnabled(long var1, boolean var3);

    private native void nativeSetViewportMetrics(long var1, float var3, int var4, int var5, int var6, int var7, int var8, int var9, int var10, int var11, int var12, int var13, int var14, int var15, int var16, int var17);

    private native void nativeSurfaceChanged(long var1, int var3, int var4);

    private native void nativeSurfaceCreated(long var1, Surface var3);

    private native void nativeSurfaceDestroyed(long var1);

    private native void nativeUnregisterTexture(long var1, long var3);

    private void onPreEngineRestart() {
        Iterator iterator = this.engineLifecycleListeners.iterator();
        while (iterator.hasNext()) {
            ((a.b)iterator.next()).a();
        }
    }

    public static void setAsyncWaitForVsyncDelegate(b b2) {
        asyncWaitForVsyncDelegate = b2;
    }

    public static void setRefreshRateFPS(float f2) {
        refreshRateFPS = f2;
    }

    private void updateCustomAccessibilityActions(ByteBuffer byteBuffer, String[] arrstring) {
        this.ensureRunningOnMainThread();
        a a2 = this.accessibilityDelegate;
        if (a2 != null) {
            a2.a(byteBuffer, arrstring);
        }
    }

    private void updateSemantics(ByteBuffer byteBuffer, String[] arrstring) {
        this.ensureRunningOnMainThread();
        a a2 = this.accessibilityDelegate;
        if (a2 != null) {
            a2.b(byteBuffer, arrstring);
        }
    }

    public void addEngineLifecycleListener(a.b b2) {
        this.ensureRunningOnMainThread();
        this.engineLifecycleListeners.add((Object)b2);
    }

    public void addIsDisplayingFlutterUiListener(io.flutter.embedding.engine.h.b b2) {
        this.ensureRunningOnMainThread();
        this.flutterUiDisplayListeners.add((Object)b2);
    }

    public void attachToNative(boolean bl) {
        this.ensureRunningOnMainThread();
        this.ensureNotAttachedToNative();
        this.nativePlatformViewId = this.nativeAttach(this, bl);
    }

    public void detachFromNativeAndReleaseResources() {
        this.ensureRunningOnMainThread();
        this.ensureAttachedToNative();
        this.nativeDestroy(this.nativePlatformViewId);
        this.nativePlatformViewId = null;
    }

    public void dispatchEmptyPlatformMessage(String string, int n2) {
        this.ensureRunningOnMainThread();
        if (this.isAttached()) {
            this.nativeDispatchEmptyPlatformMessage(this.nativePlatformViewId, string, n2);
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Tried to send a platform message to Flutter, but FlutterJNI was detached from native C++. Could not send. Channel: ");
        stringBuilder.append(string);
        stringBuilder.append(". Response ID: ");
        stringBuilder.append(n2);
        b.a.a.d("FlutterJNI", stringBuilder.toString());
    }

    public void dispatchPlatformMessage(String string, ByteBuffer byteBuffer, int n2, int n3) {
        this.ensureRunningOnMainThread();
        if (this.isAttached()) {
            this.nativeDispatchPlatformMessage(this.nativePlatformViewId, string, byteBuffer, n2, n3);
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Tried to send a platform message to Flutter, but FlutterJNI was detached from native C++. Could not send. Channel: ");
        stringBuilder.append(string);
        stringBuilder.append(". Response ID: ");
        stringBuilder.append(n3);
        b.a.a.d("FlutterJNI", stringBuilder.toString());
    }

    public void dispatchPointerDataPacket(ByteBuffer byteBuffer, int n2) {
        this.ensureRunningOnMainThread();
        this.ensureAttachedToNative();
        this.nativeDispatchPointerDataPacket(this.nativePlatformViewId, byteBuffer, n2);
    }

    public void dispatchSemanticsAction(int n2, int n3, ByteBuffer byteBuffer, int n4) {
        this.ensureRunningOnMainThread();
        this.ensureAttachedToNative();
        this.nativeDispatchSemanticsAction(this.nativePlatformViewId, n2, n3, byteBuffer, n4);
    }

    public void dispatchSemanticsAction(int n2, c.f f2) {
        this.dispatchSemanticsAction(n2, f2, null);
    }

    public void dispatchSemanticsAction(int n2, c.f f2, Object object) {
        ByteBuffer byteBuffer;
        int n3;
        this.ensureAttachedToNative();
        if (object != null) {
            byteBuffer = o.a.a(object);
            n3 = byteBuffer.position();
        } else {
            byteBuffer = null;
            n3 = 0;
        }
        this.dispatchSemanticsAction(n2, f2.a, byteBuffer, n3);
    }

    public Bitmap getBitmap() {
        this.ensureRunningOnMainThread();
        this.ensureAttachedToNative();
        return this.nativeGetBitmap(this.nativePlatformViewId);
    }

    public void invokePlatformMessageEmptyResponseCallback(int n2) {
        this.ensureRunningOnMainThread();
        if (this.isAttached()) {
            this.nativeInvokePlatformMessageEmptyResponseCallback(this.nativePlatformViewId, n2);
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Tried to send a platform message response, but FlutterJNI was detached from native C++. Could not send. Response ID: ");
        stringBuilder.append(n2);
        b.a.a.d("FlutterJNI", stringBuilder.toString());
    }

    public void invokePlatformMessageResponseCallback(int n2, ByteBuffer byteBuffer, int n3) {
        this.ensureRunningOnMainThread();
        if (this.isAttached()) {
            this.nativeInvokePlatformMessageResponseCallback(this.nativePlatformViewId, n2, byteBuffer, n3);
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Tried to send a platform message response, but FlutterJNI was detached from native C++. Could not send. Response ID: ");
        stringBuilder.append(n2);
        b.a.a.d("FlutterJNI", stringBuilder.toString());
    }

    public boolean isAttached() {
        return this.nativePlatformViewId != null;
    }

    public void markTextureFrameAvailable(long l2) {
        this.ensureRunningOnMainThread();
        this.ensureAttachedToNative();
        this.nativeMarkTextureFrameAvailable(this.nativePlatformViewId, l2);
    }

    public native boolean nativeGetIsSoftwareRenderingEnabled();

    void onFirstFrame() {
        this.ensureRunningOnMainThread();
        Iterator iterator = this.flutterUiDisplayListeners.iterator();
        while (iterator.hasNext()) {
            ((io.flutter.embedding.engine.h.b)iterator.next()).a();
        }
    }

    void onRenderingStopped() {
        this.ensureRunningOnMainThread();
        Iterator iterator = this.flutterUiDisplayListeners.iterator();
        while (iterator.hasNext()) {
            ((io.flutter.embedding.engine.h.b)iterator.next()).b();
        }
    }

    public void onSurfaceChanged(int n2, int n3) {
        this.ensureRunningOnMainThread();
        this.ensureAttachedToNative();
        this.nativeSurfaceChanged(this.nativePlatformViewId, n2, n3);
    }

    public void onSurfaceCreated(Surface surface) {
        this.ensureRunningOnMainThread();
        this.ensureAttachedToNative();
        this.nativeSurfaceCreated(this.nativePlatformViewId, surface);
    }

    public void onSurfaceDestroyed() {
        this.ensureRunningOnMainThread();
        this.ensureAttachedToNative();
        this.onRenderingStopped();
        this.nativeSurfaceDestroyed(this.nativePlatformViewId);
    }

    public void registerTexture(long l2, SurfaceTexture surfaceTexture) {
        this.ensureRunningOnMainThread();
        this.ensureAttachedToNative();
        this.nativeRegisterTexture(this.nativePlatformViewId, l2, surfaceTexture);
    }

    public void removeEngineLifecycleListener(a.b b2) {
        this.ensureRunningOnMainThread();
        this.engineLifecycleListeners.remove((Object)b2);
    }

    public void removeIsDisplayingFlutterUiListener(io.flutter.embedding.engine.h.b b2) {
        this.ensureRunningOnMainThread();
        this.flutterUiDisplayListeners.remove((Object)b2);
    }

    public void runBundleAndSnapshotFromLibrary(String string, String string2, String string3, AssetManager assetManager) {
        this.ensureRunningOnMainThread();
        this.ensureAttachedToNative();
        this.nativeRunBundleAndSnapshotFromLibrary(this.nativePlatformViewId, string, string2, string3, assetManager);
    }

    public void setAccessibilityDelegate(a a2) {
        this.ensureRunningOnMainThread();
        this.accessibilityDelegate = a2;
    }

    public void setAccessibilityFeatures(int n2) {
        this.ensureRunningOnMainThread();
        this.ensureAttachedToNative();
        this.nativeSetAccessibilityFeatures(this.nativePlatformViewId, n2);
    }

    public void setPlatformMessageHandler(c c2) {
        this.ensureRunningOnMainThread();
        this.platformMessageHandler = c2;
    }

    public void setSemanticsEnabled(boolean bl) {
        this.ensureRunningOnMainThread();
        this.ensureAttachedToNative();
        this.nativeSetSemanticsEnabled(this.nativePlatformViewId, bl);
    }

    public void setViewportMetrics(float f2, int n2, int n3, int n4, int n5, int n6, int n7, int n8, int n9, int n10, int n11, int n12, int n13, int n14, int n15) {
        this.ensureRunningOnMainThread();
        this.ensureAttachedToNative();
        this.nativeSetViewportMetrics(this.nativePlatformViewId, f2, n2, n3, n4, n5, n6, n7, n8, n9, n10, n11, n12, n13, n14, n15);
    }

    public void unregisterTexture(long l2) {
        this.ensureRunningOnMainThread();
        this.ensureAttachedToNative();
        this.nativeUnregisterTexture(this.nativePlatformViewId, l2);
    }

    public static interface a {
        public void a(ByteBuffer var1, String[] var2);

        public void b(ByteBuffer var1, String[] var2);
    }

    public static interface b {
        public void a(long var1);
    }

}


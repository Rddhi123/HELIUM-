/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 *  java.lang.String
 *  java.util.HashMap
 *  java.util.Map
 */
package io.flutter.embedding.engine;

import io.flutter.embedding.engine.a;
import java.util.HashMap;
import java.util.Map;

public class b {
    private static b b;
    private final Map<String, a> a = new HashMap();

    b() {
    }

    public static b a() {
        if (b == null) {
            b = new b();
        }
        return b;
    }

    public a a(String string) {
        return (a)this.a.get((Object)string);
    }

    public void a(String string, a a2) {
        if (a2 != null) {
            this.a.put((Object)string, (Object)a2);
            return;
        }
        this.a.remove((Object)string);
    }

    public void b(String string) {
        this.a(string, null);
    }
}


/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Enum
 *  java.lang.Float
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.util.HashMap
 *  java.util.Map
 */
package io.flutter.embedding.engine.i;

import b.a.c.a.d;
import b.a.c.a.g;
import java.util.HashMap;
import java.util.Map;

public class h {
    public final b.a.c.a.a<Object> a;

    public h(io.flutter.embedding.engine.e.a a2) {
        this.a = new b.a.c.a.a<Object>(a2, "flutter/settings", d.a);
    }

    public a a() {
        return new a(this.a);
    }

    public static class a {
        private final b.a.c.a.a<Object> a;
        private Map<String, Object> b = new HashMap();

        a(b.a.c.a.a<Object> a2) {
            this.a = a2;
        }

        public a a(float f2) {
            this.b.put((Object)"textScaleFactor", (Object)Float.valueOf((float)f2));
            return this;
        }

        public a a(b b2) {
            this.b.put((Object)"platformBrightness", (Object)b2.a);
            return this;
        }

        public a a(boolean bl) {
            this.b.put((Object)"alwaysUse24HourFormat", (Object)bl);
            return this;
        }

        public void a() {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Sending message: \ntextScaleFactor: ");
            stringBuilder.append(this.b.get((Object)"textScaleFactor"));
            stringBuilder.append("\nalwaysUse24HourFormat: ");
            stringBuilder.append(this.b.get((Object)"alwaysUse24HourFormat"));
            stringBuilder.append("\nplatformBrightness: ");
            stringBuilder.append(this.b.get((Object)"platformBrightness"));
            b.a.a.c("SettingsChannel", stringBuilder.toString());
            this.a.a(this.b);
        }
    }

    public static final class b
    extends Enum<b> {
        public static final /* enum */ b b = new b("light");
        public static final /* enum */ b c = new b("dark");
        private static final /* synthetic */ b[] d;
        public String a;

        static {
            b[] arrb = new b[]{b, c};
            d = arrb;
        }

        private b(String string2) {
            this.a = string2;
        }

        public static b valueOf(String string) {
            return (b)Enum.valueOf(b.class, (String)string);
        }

        public static b[] values() {
            return (b[])d.clone();
        }
    }

}


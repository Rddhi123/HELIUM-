/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Exception
 *  java.lang.IllegalStateException
 *  java.lang.Integer
 *  java.lang.Object
 *  java.lang.String
 *  java.lang.StringBuilder
 *  java.nio.ByteBuffer
 *  java.util.HashMap
 *  java.util.Map
 *  java.util.concurrent.atomic.AtomicBoolean
 */
package io.flutter.embedding.engine.e;

import b.a.c.a.b;
import io.flutter.embedding.engine.FlutterJNI;
import io.flutter.embedding.engine.e.c;
import java.nio.ByteBuffer;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

class b
implements b.a.c.a.b,
c {
    private final FlutterJNI a;
    private final Map<String, b.a> b;
    private final Map<Integer, b.b> c;
    private int d = 1;

    b(FlutterJNI flutterJNI) {
        this.a = flutterJNI;
        this.b = new HashMap();
        this.c = new HashMap();
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void a(int n2, byte[] arrby) {
        b.a.a.c("DartMessenger", "Received message reply from Dart.");
        b.b b2 = (b.b)this.c.remove((Object)n2);
        if (b2 != null) {
            try {
                b.a.a.c("DartMessenger", "Invoking registered callback for reply from Dart.");
                ByteBuffer byteBuffer = arrby == null ? null : ByteBuffer.wrap((byte[])arrby);
                b2.a(byteBuffer);
                return;
            }
            catch (Exception exception) {
                b.a.a.a("DartMessenger", "Uncaught exception in binary message reply handler", exception);
            }
        }
    }

    @Override
    public void a(String string, b.a a2) {
        if (a2 == null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Removing handler for channel '");
            stringBuilder.append(string);
            stringBuilder.append("'");
            b.a.a.c("DartMessenger", stringBuilder.toString());
            this.b.remove((Object)string);
            return;
        }
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Setting handler for channel '");
        stringBuilder.append(string);
        stringBuilder.append("'");
        b.a.a.c("DartMessenger", stringBuilder.toString());
        this.b.put((Object)string, (Object)a2);
    }

    @Override
    public void a(String string, ByteBuffer byteBuffer, b.b b2) {
        int n2;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Sending message with callback over channel '");
        stringBuilder.append(string);
        stringBuilder.append("'");
        b.a.a.c("DartMessenger", stringBuilder.toString());
        if (b2 != null) {
            n2 = this.d;
            this.d = n2 + 1;
            this.c.put((Object)n2, (Object)b2);
        } else {
            n2 = 0;
        }
        if (byteBuffer == null) {
            this.a.dispatchEmptyPlatformMessage(string, n2);
            return;
        }
        this.a.dispatchPlatformMessage(string, byteBuffer, byteBuffer.position(), n2);
    }

    /*
     * Enabled aggressive block sorting
     * Enabled unnecessary exception pruning
     * Enabled aggressive exception aggregation
     */
    @Override
    public void a(String string, byte[] arrby, int n2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Received message from Dart over channel '");
        stringBuilder.append(string);
        stringBuilder.append("'");
        b.a.a.c("DartMessenger", stringBuilder.toString());
        b.a a2 = (b.a)this.b.get((Object)string);
        if (a2 != null) {
            try {
                b.a.a.c("DartMessenger", "Deferring to registered handler to process message.");
                ByteBuffer byteBuffer = arrby == null ? null : ByteBuffer.wrap((byte[])arrby);
                a2.a(byteBuffer, new a(this.a, n2));
                return;
            }
            catch (Exception exception) {
                b.a.a.a("DartMessenger", "Uncaught exception in binary message listener", exception);
            }
        } else {
            b.a.a.c("DartMessenger", "No registered handler for message. Responding to Dart with empty reply message.");
        }
        this.a.invokePlatformMessageEmptyResponseCallback(n2);
    }

    private static class a
    implements b.b {
        private final FlutterJNI a;
        private final int b;
        private final AtomicBoolean c = new AtomicBoolean(false);

        a(FlutterJNI flutterJNI, int n2) {
            this.a = flutterJNI;
            this.b = n2;
        }

        @Override
        public void a(ByteBuffer byteBuffer) {
            if (!this.c.getAndSet(true)) {
                if (byteBuffer == null) {
                    this.a.invokePlatformMessageEmptyResponseCallback(this.b);
                    return;
                }
                this.a.invokePlatformMessageResponseCallback(this.b, byteBuffer, byteBuffer.position());
                return;
            }
            throw new IllegalStateException("Reply already submitted");
        }
    }

}

